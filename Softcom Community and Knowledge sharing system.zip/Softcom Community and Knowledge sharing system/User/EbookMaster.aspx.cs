﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data.SqlClient;

public partial class User_EbookMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
             BindDdlEbookMaster();
            BindGrid();
           

        }

    }
    void BindGrid()
    {
        string str = "SELECT EbookMaster.Ebook_ID, EbookMaster.Ebook_Name, EbookMaster.Ebook_Author_name,'~/Uploaded Ebooks/'+ Ebook_file  as Ebook_file,('~/Uploaded Ebooks/'+ Ebook_file)  as Ebook_fl FROM EbookCatMaster INNER JOIN  EbookMaster ON EbookCatMaster.Ebook_Cat_ID = EbookMaster.Ebook_Cat_ID where EbookMaster.Ebook_Cat_ID='" + ViewState["catid"] + "' and EbookMaster.Delete_flag='True' and EbookMaster.User_ID='" + Session["USER_ID"] + "'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdEbookMaster.DataSource = ds;
            grdEbookMaster.DataBind();
        }
        else
        {
            grdEbookMaster.DataSource = null;
            grdEbookMaster.DataBind();
        }
    }
    void BindDdlEbookMaster()
    {
        string str = "Select * from EbookCatMaster";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DdlEbookCatName.DataSource = ds;
            DdlEbookCatName.DataTextField = "Ebook_Cat_name";
            DdlEbookCatName.DataValueField = "Ebook_Cat_ID";
            DdlEbookCatName.DataBind();
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["Ebook_ID"] != null)
        {
            string str = "Select * from EbookMaster where Ebook_ID=" + ViewState["Ebook_ID"];
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(str, con);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (File.Exists(Server.MapPath("~/Uploaded Ebooks/" + ds.Tables[0].Rows[0]["Ebook_file"].ToString())))
                {
                    File.Delete(Server.MapPath("~/Uploaded Ebooks/" + ds.Tables[0].Rows[0]["Ebook_file"].ToString()));
                }
            }
            string str1 = "Delete from EbookMaster where Ebook_ID=" + ViewState["Ebook_ID"];
            cmd = new SqlCommand(str1, con);
            cmd.ExecuteNonQuery();
            ViewState.Clear();
            btnsave_Click(sender, e);
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Updated";

        }
        else
        {
            string str = ("Insert into EbookMaster(Ebook_Cat_ID,User_ID,Ebook_name,Ebook_Author_name,Ebook_file,Delete_flag)values('" + DdlEbookCatName.SelectedValue + "','"+Session["USER_ID"]+"','" + txtebookauthor.Text + "','" + txtebookname.Text + "','" + fpebookfile.FileName + "','False')");
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            if (fpebookfile.HasFile)
            {
                fpebookfile.SaveAs(Server.MapPath("~/Uploaded Ebooks/" + fpebookfile.FileName));

            }
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Inserted";
        }
        BindGrid();
    }
    protected void lbkedit_Click(object sender, EventArgs e)
    {
       

            LinkButton lbk = (LinkButton)sender;
            string str = "select * from EbookMaster where Ebook_ID=" + lbk.CommandArgument;
            da = new SqlDataAdapter(str, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ViewState["Ebook_ID"] = lbk.CommandArgument;
                DdlEbookCatName.SelectedValue = ds.Tables[0].Rows[0]["Ebook_Cat_ID"].ToString();
                txtebookauthor.Text = ds.Tables[0].Rows[0]["Ebook_Author_name"].ToString();
                txtebookname.Text = ds.Tables[0].Rows[0]["Ebook_name"].ToString();
            }
          
        
       
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        DdlEbookCatName.SelectedIndex = 0;
        txtebookname.Text = "";
        txtebookauthor.Text = "";
    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str1 = "Delete from EbookMaster where Ebook_ID=" + lbk.CommandArgument;
        string str = "Select * from EbookMaster where Ebook_ID=" + lbk.CommandArgument;
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(str, con);
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            if (File.Exists(Server.MapPath("~/Uploaded Ebooks/" + ds.Tables[0].Rows[0]["Ebook_file"].ToString())))
            {
                File.Delete(Server.MapPath("~/Uploaded Ebooks/" + ds.Tables[0].Rows[0]["Ebook_file"].ToString()));
            }
        }

        cmd = new SqlCommand(str1, con);
        cmd.ExecuteNonQuery();

        lblmsg.Text = "Record Deleted";
        BindGrid();
    }
    protected void DdlEbookCatName_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewState["catid"] = DdlEbookCatName.SelectedValue;
        BindGrid();
    }
    protected void grdEbookMaster_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
