﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Forgott_Password : System.Web.UI.Page
{
    SqlConnection con;
    //SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtmyowner.Visible = false;
        }
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
            {
        if (txtmyowner.Visible == false)
        {
            string str = "select * from LoginMaster where Email_ID='" + txtemail.Text + "'";
            da = new SqlDataAdapter(str, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {

                ViewState["Pass"] = ds.Tables[0].Rows[0]["Password"].ToString();
                ViewState["Email"] = ds.Tables[0].Rows[0]["Email_ID"].ToString();
                ViewState["security"] = ds.Tables[0].Rows[0]["Security_Question"].ToString();
                ViewState["Ans"] = ds.Tables[0].Rows[0]["Answer"].ToString();
                ViewState["User"] = ds.Tables[0].Rows[0]["User_Type"].ToString();
                if (rbluser_type.SelectedItem.Text == Convert.ToString(ViewState["User"]))
                {

                    if (Convert.ToString(drlquestion.SelectedItem.Text) == Convert.ToString(ViewState["security"]) && Convert.ToString(txtanswer.Text) == Convert.ToString(ViewState["Ans"]))
                    {
                        Label1.Visible = false;
                        Label2.Visible = false;
                        Label3.Visible = false;
                        Label4.Visible = false;
                        txtemail.Visible = false;
                        drlquestion.Visible = false;
                        txtanswer.Visible = false;
                        btnsubmit.Visible = false;
                        btncancel.Visible = false;
                        rbluser_type.Visible = false;
                        Label6.Visible = false;
                        btncancel_Click(sender, e);
                        lblwarn.Text = "Your Password is    " + ViewState["Pass"];
                    }
                    else
                    {
                        lblmsg.Text = "Sorry But You are not eligible for Password Retrive";
                    }
                }
                else
                {
                    lblmsg.Text = "There is no email Id which you entered";
                }
            }
            else
            {
                lblmsg.Text = "There is no emal id In which you entered here";
            }
        }
        else
        {
            string str = "select * from LoginMaster where Email_ID='" + txtemail.Text + "'";
            da = new SqlDataAdapter(str, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {

                ViewState["Pass"] = ds.Tables[0].Rows[0]["Password"].ToString();
                ViewState["Email"] = ds.Tables[0].Rows[0]["Email_ID"].ToString();
                ViewState["security"] = ds.Tables[0].Rows[0]["Security_Question"].ToString();
                ViewState["Ans"] = ds.Tables[0].Rows[0]["Answer"].ToString();
                ViewState["User"] = ds.Tables[0].Rows[0]["User_Type"].ToString();
                if (rbluser_type.SelectedItem.Text == Convert.ToString(ViewState["User"]))
                {

                    if (Convert.ToString(txtmyowner.Text) == Convert.ToString(ViewState["security"]) && Convert.ToString(txtanswer.Text) == Convert.ToString(ViewState["Ans"]))
                    {
                        Label1.Visible = false;
                        Label2.Visible = false;
                        Label3.Visible = false;
                        Label4.Visible = false;
                        txtemail.Visible = false;
                        drlquestion.Visible = false;
                        txtanswer.Visible = false;
                        btnsubmit.Visible = false;
                     //   btncancel.Visible = false;
                        txtmyowner.Visible = false;
                        rbluser_type.Visible = false;
                        Label6.Visible = false;
                        btncancel_Click(sender, e);
                        lblwarn.Text = "Your Password is    " + ViewState["Pass"];
                    }
                    else
                    {
                        lblmsg.Text = "Sorry But You are not eligible for Password Retrive";
                    }
                }
                else
                {
                    lblmsg.Text = "There is no email Id which you entered";
                }
            }
            else 
            {
                lblmsg.Text = "There is no emal id In which you entered here";
            }
        
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtemail.Text = "";
        txtanswer.Text = "";

        lblmsg.Text = "";
        }
    protected void drlquestion_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drlquestion.SelectedItem.Text == "Choose My Own Question")
        {
            txtmyowner.Visible = true;
            txtmyowner.Focus();
            RequiredFieldValidator8.ValidationGroup = "1";

            //        drlquestion.Visible = false;
        }
        else
        {
            txtmyowner.Visible =false;
            RequiredFieldValidator8.ValidationGroup = "0";

        }
            }
}
