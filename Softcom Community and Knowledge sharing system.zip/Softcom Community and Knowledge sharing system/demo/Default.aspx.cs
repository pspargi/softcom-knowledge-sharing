﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class demo_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String str = "parin";
        String[] str1 = new String[4];
        string[] str2 = new string[4];
       
      
        char splitter = (' ');
        str1 = str.Split(splitter);
        for (int i = 0; i < 4; i++)
        {
            if (str1.Length > i)
            {
                str2[i] = str1[i];
            }
            else
            {
                str2[i] = "0";
            
            }
            Response.Write(str2[i]);

        }

    }
}
