﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_Videoaproval : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    SqlCommand cmd;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    void BindGrid()
    {
        string str = "select Video_ID,User_ID,('~/Uploaded Videos/'+ Video_file)  as Video_fl,'~/Uploaded Videos/'+ Video_file  as Video_file from VideoMaster where Delete_flag='False' and User_ID='" + Session["user_id"] + "'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdvideoapproval.DataSource = ds;
            grdvideoapproval.DataBind();
        }
        else
        {
            grdvideoapproval.DataSource = null;
            grdvideoapproval.DataBind();
        }
    }
    protected void btnaprove_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < grdvideoapproval.Rows.Count; i++)
        {
            if (((CheckBox)grdvideoapproval.Rows[i].FindControl("ckbvideofile")).Checked == true)
            {
                String str = "Update VideoMaster set Delete_flag='True' where Video_ID='" + Convert.ToInt32(((Label)grdvideoapproval.Rows[i].FindControl("lblvidoid")).Text) + "'";
                cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                lblmsg.Text = "Updated Successfully";

            }
            else
            {
                String str1 = "Delete from VideoMaster where Video_ID='" + Convert.ToInt32(((Label)grdvideoapproval.Rows[i].FindControl("lblvidoid")).Text) + "'";
                string str = "Select * from VideoMaster where Video_ID=" + Convert.ToInt32(((Label)grdvideoapproval.Rows[i].FindControl("lblvidoid")).Text);
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(str, con);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (File.Exists(Server.MapPath("~/Uploaded Videos/" + ds.Tables[0].Rows[0]["Video_file"].ToString())))
                    {
                        File.Delete(Server.MapPath("~/Uploaded Videos/" + ds.Tables[0].Rows[0]["Video_file"].ToString()));
                    }
                }

                cmd = new SqlCommand(str1, con);
                cmd.ExecuteNonQuery();
            }
                  
          
        }
        lblmsg.Text = "Updated Success Fully";
        BindGrid();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < grdvideoapproval.Rows.Count; i++)
        {
            ((CheckBox)grdvideoapproval.Rows[i].FindControl("ckbvideofile")).Checked = false;
        }
        
    }
}
