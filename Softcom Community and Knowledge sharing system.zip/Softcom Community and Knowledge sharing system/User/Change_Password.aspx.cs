﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class User_Change_Password : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        string str = "select * from LoginMaster where Email_ID='" +txtemailid.Text+ "'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {

            ViewState["Pass"] = ds.Tables[0].Rows[0]["Password"].ToString();
            ViewState["User"] = ds.Tables[0].Rows[0]["User_Type"].ToString();
            if(rbluser_type.SelectedItem.Text==Convert.ToString(ViewState["User"]))
            {
            if (Convert.ToString(txtpassword.Text) == Convert.ToString(ViewState["Pass"]))
            {
                if (txtnewpassword.Text == txtrenewpassword.Text)
                {
                    cmd = new SqlCommand("Update LoginMaster Set Password='" + txtnewpassword.Text + "' where Email_ID='" + txtemailid.Text + "' ", con);
                    cmd.ExecuteNonQuery();
                    btncancel_Click(sender, e);
                    txtemailid.Visible = false;
                    txtnewpassword.Visible = false;
                    txtrenewpassword.Visible = false;
                    txtpassword.Visible = false;
                    Label1.Visible = false;
                    Label2.Visible = false;
                    Label3.Visible = false;
                    Label4.Visible = false;
                    Label5.Visible = false;
                       btnSave.Visible = false;
                    btncancel.Visible = false;
                    rbluser_type.Visible = false;
                    Label6.Visible = false;
                    lblmsg.Text = "Your Password is being changed";
                    lblwrn.Text = "";
                    
                }
                else 
                {
                    lblwrn.Text = "Please Entered same password";
                }
            
           }
        }
        else
        {
            ViewState["Pass"] = "";
            lblmsg.Text = "Sorry But You are not eligible for Change Password ";
        }
        }
        else
        {
            lblmsg.Text = "Sorry But You are not eligible for Change Password ";
        }
        
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtemailid.Text = "";
        txtpassword.Text = "";
        txtnewpassword.Text = "";
        txtrenewpassword.Text = "";
        lblmsg.Text = "";
        lblwrn.Text = "";
        Response.Redirect ("Profile_HomePage.aspx");
       }
}
