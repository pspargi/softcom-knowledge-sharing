﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="CountryMaster.aspx.cs" Inherits="Admin_Default" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 23px;
            text-align: left;
        }
        .style3
        {
            height: 44px;
        }
        .style4
        {
            height: 23px;
            text-align: right;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td class="style3" colspan="2" style="text-align: center">
                <h3>
                    Country Master</h3>
            </td>
        </tr>
        <tr>
            <td class="style4">
                Country Name :</td>
            <td class="style2">
                
                <asp:TextBox ID="txtcountryname" runat="server" ></asp:TextBox>
                
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Country Description :</td>
            <td style="text-align: left">
                
                <asp:TextBox ID="txtcountydescription" runat="server" TextMode="MultiLine"></asp:TextBox>
                
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" 
                    Width="59px" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                    Text="Cancel" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdcountrymaster" runat="server" AutoGenerateColumns="False" 
                    style="margin-right: 1px" AllowPaging="True" 
                    onselectedindexchanging="grdcountrymaster_SelectedIndexChanging" 
                    PageSize="5" CellPadding="4" ForeColor="#333333" GridLines="None"
                   >
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate> 
                                
                                              
                                
                                                <asp:LinkButton ID="lbkedit" runat="server" 
                                                    CommandArgument='<%# Eval("Country_ID") %>' onclick="lbkedit_Click">Edit</asp:LinkButton>
                                
                                              
                                
                                                </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                               <asp:LinkButton ID="lnkdelete" runat="server" 
                                    CommandArgument='<%# Eval("Country_ID") %>' onclick="lnkdelete_Click">Delete</asp:LinkButton> 
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Country_name" HeaderText="Country Name" />
                        <asp:BoundField DataField="Country_descr" HeaderText="Country Des" />
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

