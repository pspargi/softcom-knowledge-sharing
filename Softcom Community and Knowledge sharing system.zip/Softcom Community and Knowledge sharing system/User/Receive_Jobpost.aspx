﻿<%@ Page Language="C#"  MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Receive_Jobpost.aspx.cs" Inherits="User_Receive_Jobpost" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
   <style type="text/css">
        .style1
        {
            width: 97%;
            height: 165px;
        }
        .style2
        {
            text-align: center;
        }
 p.MsoNormal
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:0in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	}
        .style3
        {
            text-align: right;
            width: 192px;
        }
        .style5
        {
            text-align: left;
        }
        .style6
        {
            text-align: right;
        }
    </style>
</asp:Content>
    <asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">

    <asp:GridView ID="dgvjobpost" runat="server" AutoGenerateColumns="False" 
        style="margin-right: 0px" CellPadding="4" ForeColor="#333333" GridLines="None">
        <RowStyle BackColor="#E3EAEB" />
        <Columns>
            <asp:TemplateField HeaderText="Sender Email Id">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td>
                                <asp:Label ID="lblsenderemail" runat="server" Text='<%# Eval("sender") %>'></asp:Label>
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
            <asp:TemplateField HeaderText="Job Post">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td class="style3">
                                Company Name :-</td>
                            <td style="text-align: left">
                                <asp:TextBox ID="txtcompanyname" runat="server" Height="22px" ReadOnly="True" 
                                    Text='<%# Eval("Company_name") %>' Width="188px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style3">
                                <p class="MsoNormal">
                                    Requirement :-</p>
                            </td>
                            <td class="style5">
                                <asp:TextBox ID="txtrequirement" runat="server" Height="23px" ReadOnly="True" 
                                    Text='<%# Eval("Requirement") %>' Width="181px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style3">
                                Designation :-</td>
                            <td>
                                <asp:TextBox ID="txtdesignation" runat="server" Height="19px" ReadOnly="True" 
                                    Text='<%# Eval("Designation") %>' Width="187px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style3">
                                &nbsp;</td>
                            <td class="style6">
                                <asp:Label ID="lblstatus" runat="server" Text='<%# Eval("Status") %>' 
                                    Font-Bold="True" ForeColor="Red"></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style3">
                                &nbsp;</td>
                            <td class="style6">
                                <asp:Label ID="lbldate" runat="server" Text='<%# Eval("Date_Time") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style2" colspan="2">
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btnforward" runat="server" 
                                    CommandArgument='<%# Eval("Job_post_id") %>' Height="26px" Text="Forward" 
                                    Width="70px" onclick="btnforward_Click" BackColor="#999966" />
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btnDelete" runat="server" 
                                    CommandArgument='<%# Eval("Job_post_id") %>' Height="26px" 
                                    onclick="btndelete_click" Text="Delete" Width="70px" BackColor="#999966" />
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#7C6F57" />
        <AlternatingRowStyle BackColor="White" />
    </asp:GridView>
    <asp:Label ID="lbluserid" runat="server" Visible="False"></asp:Label>
    <asp:Label ID="lblemaild" runat="server" Visible="False"></asp:Label>
  </asp:Content>