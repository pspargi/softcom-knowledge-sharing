﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="statemaster.aspx.cs" Inherits="Admin_statemaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 23px;
            text-align: center;
        }
        .style3
        {
            height: 28px;
            text-align: left;
        }
        .style4
        {
            height: 26px;
            text-align: left;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <h2>
                    State Master</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: right" class="style4">
                Coutry Name:</td>
            <td class="style4">
                <asp:DropDownList ID="ddlcoutry" runat="server" AutoPostBack="True" 
                    onselectedindexchanged="ddlcoutry_SelectedIndexChanged">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td style="text-align: right" class="style3">
                State Name:</td>
            <td class="style3">
                <asp:TextBox ID="txtstatename" runat="server" 
                    ontextchanged="txtstatename_TextChanged"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: center" colspan="2">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
                :</td>
        </tr>
        <tr>
            <td class="style2" colspan="2">
                <asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" />
                <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                    Text="Cancel" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdstatemaster" runat="server" AutoGenerateColumns="False" 
                    AllowPaging="True" 
                    onselectedindexchanging="grdstatemaster_SelectedIndexChanging" 
                    PageSize="5" CellPadding="4" ForeColor="#333333" GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkedit" runat="server" 
                                    CommandArgument='<%# Eval("State_ID") %>' onclick="lbkedit_Click">Edit</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkdelete" runat="server" 
                                    CommandArgument='<%# Eval("State_ID") %>' onclick="lbkdelete_Click">Delete</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="State_ID" HeaderText="State ID" />
                        <asp:BoundField DataField="State_name" HeaderText="State Name" />
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

