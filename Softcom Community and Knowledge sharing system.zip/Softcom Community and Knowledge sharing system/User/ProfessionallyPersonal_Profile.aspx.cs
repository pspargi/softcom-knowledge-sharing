﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Professionally_Profile : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        lblmsg.Text = Convert.ToString(Session["USER_ID"]);
        if (!IsPostBack)
        {
            ViewState["i"] = 2;
            if (Session["edit"] == "Professional")
            {
                ppersonal.Visible = false;
                pprofessinal.Visible = true;
            }
            else if (Session["edit"] == "Personal")
            {
                ppersonal.Visible = true;
                pprofessinal.Visible = false;
            
            }
            Session["edit"] = "";
            Bindgrid();
        }
           
    }
    void Bindgrid() 
    {   
    da = new SqlDataAdapter("Select * from professionalProfile where User_ID='"+lblmsg.Text +"'", con);
    ds = new DataSet();
    da.Fill(ds);
    if (ds.Tables[0].Rows.Count > 0)
    {
        ddleducation.SelectedItem.Text = ds.Tables[0].Rows[0]["Education"].ToString();
        txtcompany_name.Text = ds.Tables[0].Rows[0]["Company_Name"].ToString();
        txtprimaryshoolname.Text = ds.Tables[0].Rows[0]["Primary_school"].ToString();
        txthighersecondoryschool.Text = ds.Tables[0].Rows[0]["Higher_school"].ToString();
        txtcollege.Text = ds.Tables[0].Rows[0]["College_Univercity"].ToString();
        txtcollege1.Text = ds.Tables[0].Rows[0]["College_univercity_1"].ToString();
        }
        da=new SqlDataAdapter("Select * from personalDetails where User_ID='"+lblmsg.Text+"'",con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddleyecolor.SelectedItem.Text = ds.Tables[0].Rows[0]["Eye_color"].ToString();
            ddlhaircolor.SelectedItem.Text = ds.Tables[0].Rows[0]["Hair_color"].ToString();
            ddlbuild.SelectedItem.Text = ds.Tables[0].Rows[0]["Build"].ToString();
            ddlLooks.SelectedItem.Text = ds.Tables[0].Rows[0]["Looks"].ToString();
        }
    
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
      //  Label4.Text = Convert.ToString(ViewState["i"]);
        if (Convert.ToInt32(ViewState["i"])% 2 == 0)
        {
            Label7.Visible = true;
            txtcollege1.Visible = true;
        }
        else
        {
            Label7.Visible = false;
            txtcollege1.Visible = false;
        
        }
        ViewState["i"] = Convert.ToInt32(ViewState["i"]) + 1;
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Profile_HomePage.aspx");
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("Update professionalProfile Set Education='" + ddleducation.SelectedItem.Text + "',Company_Name='" + txtcompany_name.Text + "',Primary_school='" + txtprimaryshoolname.Text + "',Higher_school='" + txthighersecondoryschool.Text + "',College_Univercity='" + txtcollege.Text + "',College_univercity_1='" + txtcollege1.Text + "' where User_ID='"+lblmsg.Text+"'", con);
        cmd.ExecuteNonQuery();
      }
    protected void btnsave0_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("Update personalDetails Set Eye_color='" + ddleyecolor.SelectedItem.Text + "',Hair_color='" + ddlhaircolor.SelectedItem.Text + "',Build='" + ddlbuild.SelectedItem.Text + "',Looks='"+ddlLooks.SelectedItem.Text+"'", con);
        cmd.ExecuteNonQuery();
     }
    protected void btncancel0_Click(object sender, EventArgs e)
    {
        Response.Redirect("Profile_HomePage.aspx");
    }
}
