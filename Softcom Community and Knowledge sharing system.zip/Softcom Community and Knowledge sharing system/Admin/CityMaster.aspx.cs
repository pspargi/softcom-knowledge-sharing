﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_CityMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindDdlCountry();
            BindDldState();
            
            BindGrid();
        }

    }
    void BindGrid()
    {
        string str = "SELECT CityMaster.City_ID, CityMaster.City_name FROM CountryMaster INNER JOIN StateMaster ON CountryMaster.Country_ID = StateMaster.Country_ID INNER JOIN CityMaster ON StateMaster.State_ID = CityMaster.State_ID";
        ds = new DataSet();
        da = new SqlDataAdapter(str, con);
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count>0)
        {
            grdcitymaster.DataSource = ds;
            grdcitymaster.DataBind();
        }
        else
        {
            grdcitymaster.DataSource = null;
            grdcitymaster.DataBind();
        }

    }
    void BindDdlCountry()
    {
        String str = "Select * from CountryMaster";
        ds = new DataSet();
        da = new SqlDataAdapter(str, con);
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlcountryname.DataSource = ds;
            ddlcountryname.DataTextField = "Country_name";
            ddlcountryname.DataValueField = "Country_ID";
            ddlcountryname.DataBind();

        }
     
       
    }
    void BindDldState()
    {
        string str = "SELECT * FROM StateMaster where Country_ID="+ddlcountryname.SelectedValue;
        ds = new DataSet();
        da = new SqlDataAdapter(str, con);
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlstatename.DataSource = ds;
            
            ddlstatename.DataTextField = "State_name"; 
            ddlstatename.DataValueField = "State_ID";
            ddlstatename.DataBind();
        }
        
        
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["City_ID"] != null)
        {
            String str = "update CityMaster set Country_ID='" +ddlcountryname.SelectedValue + "',State_ID='" + ddlstatename.SelectedValue + "',City_name='" + txtcityname.Text + "' where City_ID='" + ViewState["City_ID"].ToString() + "'";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Updated";

        }
        else
        {
            string str = "Insert into CityMaster(Country_ID,State_ID,City_name)  values ('" + ddlcountryname.SelectedValue + "','" + ddlstatename.SelectedValue + "','" + txtcityname.Text + "')";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            lblmsg.Text = "Record Inserted";
        }
        BindGrid();
    }
    protected void ddlcountryname_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindDldState();
        
    }
    protected void lbkEdit_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        String str = "Select * from CityMaster where City_ID=" + lbk.CommandArgument;
        da = new SqlDataAdapter(str,con);
        ds = new DataSet();
        da.Fill(ds);
        if(ds.Tables[0].Rows.Count>0)
        {
            txtcityname.Text=ds.Tables[0].Rows[0]["City_name"].ToString();
            ViewState["City_ID"]=ds.Tables[0].Rows[0]["City_ID"].ToString();
            ddlcountryname.SelectedValue=ds.Tables[0].Rows[0]["Country_ID"].ToString();
            BindDldState();
            ddlstatename.SelectedValue = ds.Tables[0].Rows[0]["State_ID"].ToString();
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtcityname.Text = "";
        ddlcountryname.SelectedIndex = 0;
        ddlstatename.SelectedIndex = 0;
        ViewState.Clear();
    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "Delete from CityMaster where City_ID="+lbk.CommandArgument.ToString();
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        
        btncancel_Click(sender, e);
        lblmsg.Text = "Record Deleted";
        BindGrid();
    }
}
