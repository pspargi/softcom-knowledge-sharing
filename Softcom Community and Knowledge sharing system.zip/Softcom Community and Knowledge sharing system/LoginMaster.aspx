﻿<%@ Page Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="LoginMaster.aspx.cs" Inherits="LoginMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 2px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <h2>
                    Login Master</h2>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center" class="style2">
                <asp:RadioButtonList ID="rblusertype" runat="server" 
                    RepeatDirection="Horizontal">
                    <asp:ListItem>Admin</asp:ListItem>
                    <asp:ListItem>User</asp:ListItem>
                </asp:RadioButtonList>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Email ID:&nbsp;&nbsp;
            </td>
            <td style="text-align: left">
                <asp:TextBox ID="txtemailid" runat="server" 
                    style="text-align: left; margin-left: 0px;" Width="181px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Password:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtpassword" runat="server" Width="181px" TextMode="Password"></asp:TextBox>
                &nbsp;&nbsp;&nbsp;
            </td>
        </tr>
        <tr>
            <td style="text-align: center" colspan="2">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <asp:Button ID="btnsignin" runat="server" onclick="btnsignin_Click" 
                    Text="Sign In"/>
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <asp:LinkButton ID="lnkforgottpassword" runat="server" 
                    onclick="lnkforgottpassword_Click">Are You forgott Your Password????</asp:LinkButton>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:LinkButton ID="LinkButton1" runat="server" Font-Bold="True" 
                    Font-Size="Medium" Font-Underline="True" ForeColor="Blue" 
                    onclick="LinkButton1_Click">Register Your Account....</asp:LinkButton>
            </td>
        </tr>
        </table>
</asp:Content>

