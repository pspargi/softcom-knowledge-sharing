﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_EbookCategoryMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            bindgrid();

        }
    }
         void bindgrid()
    {
        string str = "select * from EbookCatMaster where User_ID='"+Session["USER_ID"]+"'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdEbookCatMaster.DataSource= ds;
            grdEbookCatMaster.DataBind();
        }
        else
        {
            grdEbookCatMaster.DataSource = null;
            grdEbookCatMaster.DataBind();
        }

    }

         protected void btnsave_Click(object sender, EventArgs e)
         {
             if (ViewState["Ebook_Cat_ID"] != null)
             {
                 String str = "update EbookCatMaster set Ebook_Cat_name='" + txtEbookCatname.Text + "',Ebook_Cat_Description='" + txtebookCatDesc.Text + "'where Ebook_Cat_ID='" + ViewState["Ebook_Cat_ID"].ToString() + "'";
                 cmd = new SqlCommand(str, con);
                 cmd.ExecuteNonQuery();
                 btncancel_Click(sender, e);
                 lblmsg.Text = "Record Updated";
                 btnSave.Text = "Save";
             }
             else
             {
                 string str = "Insert into EbookCatMaster(User_ID,Ebook_Cat_name,Ebook_Cat_Description)values('"+Session["USER_ID"]+"','" + txtEbookCatname.Text + "','" + txtebookCatDesc.Text + "')";
                 cmd = new SqlCommand(str, con);
                 cmd.ExecuteNonQuery();
                 btncancel_Click(sender, e);
                 lblmsg.Text = "Record Inserted";
             }
             bindgrid();
         }
         protected void btncancel_Click(object sender, EventArgs e)
         {
             txtEbookCatname.Text = "";
             txtebookCatDesc.Text = "";
             lblmsg.Text = "";
             ViewState.Clear();
         }
         protected void lbkedit_Click(object sender, EventArgs e)
         {
             LinkButton lbk = (LinkButton)sender;
             string str = "select * from EbookCatMaster where Ebook_Cat_ID=" + lbk.CommandArgument.ToString();
             da = new SqlDataAdapter(str, con);
             ds = new DataSet();
             da.Fill(ds);
             if (ds.Tables[0].Rows.Count > 0)
             {
                 ViewState["Ebook_Cat_ID"] = lbk.CommandArgument.ToString();
                 txtEbookCatname.Text = ds.Tables[0].Rows[0]["Ebook_Cat_name"].ToString();
                 txtebookCatDesc.Text = ds.Tables[0].Rows[0]["Ebook_Cat_Description"].ToString();
             }
             btnSave.Text = "Update";
         }
         protected void lbkdelete_Click(object sender, EventArgs e)
         {
             LinkButton lbk = (LinkButton)sender;
             string str = "Delete from EbookCatMaster where Ebook_Cat_ID=" + lbk.CommandArgument.ToString();
             cmd = new SqlCommand(str, con);
             cmd.ExecuteNonQuery();
             btncancel_Click(sender, e);
             lblmsg.Text = "Record Deleted";
             bindgrid();
         }
}
