﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_ActivityMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            bindgrid();
            BindDdlActivityGroup();

        }

    }
    void bindgrid()
    {
        string str = "SELECT ActivityMaster.Activity_ID,'~/Uploaded Images/'+ ads_pic_file  as ads_pic_file, ActivityMaster.Activity_name FROM ActivityGroupMaster INNER JOIN ActivityMaster ON ActivityGroupMaster.Activity_Group_ID = ActivityMaster.Activity_Group_ID";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdactivitymaster.DataSource = ds;
            grdactivitymaster.DataBind();
        }
        else
        {
            grdactivitymaster.DataSource = null;
            grdactivitymaster.DataBind();
        }

    }
    void BindDdlActivityGroup()
    {
        String str = "Select * from ActivityGroupMaster";
        ds = new DataSet();
        da = new SqlDataAdapter(str, con);
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlActivgroupname.DataSource = ds;
            ddlActivgroupname.DataTextField = "Activity_Group_name";
            ddlActivgroupname.DataValueField = "Activity_Group_ID";
            ddlActivgroupname.DataBind();
            ddlActivgroupname.Items.Insert(0, "--Select--");
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
         string str = "Insert into ActivityMaster(Activity_Group_ID,Activity_name)  values ('" + ddlActivgroupname.SelectedValue + "','" + txtactivityname.Text + "')";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Inserted";
            DataBind();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtactivityname.Text = "";
       // ViewState.Clear();
        lblmsg.Text = "";
        ddlActivgroupname.SelectedIndex = 0;
    }

    protected void lbedit_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "select * from ActivityGroupMaster where Activity_Group_ID=" + lbk.CommandArgument.ToString();
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ViewState["Activity_Group_ID"] = lbk.CommandArgument.ToString();
           txtactivityname.Text = ds.Tables[0].Rows[0]["Activity_Group_name"].ToString();
            txtactivityname.Text = ds.Tables[0].Rows[0]["Activity_Group_Description"].ToString();
        }
        btnSave.Text = "Update";
    }
    protected void lbdelete_Click(object sender, EventArgs e)
    {
         LinkButton lbk = (LinkButton)sender;
        string str = "Delete from ActivityGroupMaster where Activity_Group_ID='" + lbk.CommandArgument+"'";
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        btncancel_Click(sender, e);
        lblmsg.Text = "Record Deleted";
        bindgrid();
    }
    protected void ddlActivgroupname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlActivgroupname.SelectedItem.Text == "Advertisment")
        {
            fp_advertisement.Visible = true;
            txtactivityname.Visible = false;
        }
        else if(ddlActivgroupname.SelectedItem.Text == "Event")
        {
            fp_advertisement.Visible = false;
            txtactivityname.Visible = true;
        }
        else
        {
        }     
    }
}
