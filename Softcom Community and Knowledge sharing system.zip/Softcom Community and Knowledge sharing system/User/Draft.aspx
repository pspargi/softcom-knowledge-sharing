﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Draft.aspx.cs" Inherits="User_Draft" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 86%;
            margin-left: 1px;
        }
        .style5
        {
            text-align: center;
            font-weight: bold;
        }
        .style6
        {
            text-align: center;
            font-weight: bold;
            width: 116px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
      <asp:GridView ID="dgvdraft" runat="server" AutoGenerateColumns="False" 
        style="margin-right: 0px; margin-top: 0px;" CellPadding="4" 
          ForeColor="#333333" GridLines="None">
          <RowStyle BackColor="#E3EAEB" />
        <Columns>
            <asp:TemplateField HeaderText="Send to">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td>
                                <asp:Label ID="lblsender" runat="server" Text='<%# Eval("Receiver") %>'></asp:Label>
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
            <asp:TemplateField HeaderText="Scrabs">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td class="style6">
                                Subject :-</td>
                            <td>
                                <asp:TextBox ID="TextBox1" runat="server" Height="22px" ReadOnly="True" 
                                    Text='<%# Eval("Subject") %>' Width="148px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style6">
                                Message :-</td>
                            <td>
                                <asp:TextBox ID="txtmessage" runat="server" Height="48px" ReadOnly="True" 
                                    Text='<%# Eval("Message") %>' TextMode="MultiLine" Width="153px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style6">
                                &nbsp;</td>
                            <td style="text-align: right">
                                <asp:Label ID="lblstatus" runat="server" Font-Bold="True" ForeColor="Red" 
                                    Text='<%# Eval("Status") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style6">
                                &nbsp;</td>
                            <td style="text-align: right">
                                <asp:Label ID="lbldate" runat="server" Text='<%# Eval("Date_Time") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style5" colspan="2">
                                <asp:Button ID="btnsend" runat="server" Text="Send" 
                                    CommandArgument='<%# Eval("draft_no") %>' Height="26px" onclick="btnsend_Click" 
                                    Width="62px" BackColor="#999966" />
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btndelete" runat="server" 
                                    CommandArgument='<%# Eval("draft_no") %>' Height="29px" 
                                    onclick="btndelete_Click" Text="Delete" Width="69px" BackColor="#999966" />
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
          <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
          <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
          <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
          <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
          <EditRowStyle BackColor="#7C6F57" />
          <AlternatingRowStyle BackColor="White" />
    </asp:GridView>
    <asp:Label ID="lblemailidd" runat="server" Visible="False"></asp:Label>
    <asp:Label ID="lbluserid" runat="server" Visible="False"></asp:Label>
      </asp:Content>