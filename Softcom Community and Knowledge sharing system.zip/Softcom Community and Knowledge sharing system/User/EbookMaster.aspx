﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="EbookMaster.aspx.cs" Inherits="User_EbookMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <h2>
                    Ebook Master</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Ebook Category Name:</td>
            <td style="text-align: left">
                <asp:DropDownList ID="DdlEbookCatName" runat="server" AutoPostBack="True" 
                    onselectedindexchanged="DdlEbookCatName_SelectedIndexChanged">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Ebook Name :</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtebookname" runat="server"></asp:TextBox>
                        </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Ebook Author:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtebookauthor" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Ebook file:</td>
            <td style="text-align: left">
                <asp:FileUpload ID="fpebookfile" runat="server" BackColor="White" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Button ID="btnSave" runat="server" Text="Save" onclick="btnsave_Click" />
                <asp:Button ID="btncancel" runat="server" Text="Cancel" 
                    onclick="btncancel_Click" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdEbookMaster" runat="server" AutoGenerateColumns="False" 
                    CellPadding="4" ForeColor="#333333" GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkedit" runat="server" 
                                    CommandArgument='<%# Eval("Ebook_ID") %>' onclick="lbkedit_Click">Edit</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkdelete" runat="server" 
                                    CommandArgument='<%# Eval("Ebook_ID") %>' onclick="lbkdelete_Click">Delete</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Ebook_name" HeaderText="Ebook Name" />
                        <asp:BoundField DataField="Ebook_Author_name" HeaderText="Ebook Author Name" />
                        <asp:BoundField DataField="Ebook_file" HeaderText="Ebook File " />
                        <asp:TemplateField HeaderText="Download">
                            <ItemTemplate>
                                <asp:HyperLink ID="hpldownload" runat="server" 
                                    NavigateUrl='<%# Eval("Ebook_fl") %>'>Download</asp:HyperLink>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

