﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Social_Profile : System.Web.UI.Page
{
    SqlCommand cmd;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        lblmsg.Text = Convert.ToString(Session["USER_ID"]);
        if (!IsPostBack)
        {
            Bindgrid();    
        }
    }
    void Bindgrid()
    {
        da = new SqlDataAdapter("Select * from SocialProfileMaster where User_ID='" + lblmsg.Text + "' ", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            
            ddlrelationship_status.SelectedItem.Text= ds.Tables[0].Rows[0]["Relation_ship_Status"].ToString();
            ddlethinicity.SelectedItem.Text = ds.Tables[0].Rows[0]["Ethnicity"].ToString();
            ddlreligion.SelectedItem.Text = ds.Tables[0].Rows[0]["Religion"].ToString();
            txthometown.Text = ds.Tables[0].Rows[0]["Home_Town"].ToString();
            txtpassion.Text = ds.Tables[0].Rows[0]["Passion"].ToString();
            txtsports.Text = ds.Tables[0].Rows[0]["Sports"].ToString();
            txtbooks.Text = ds.Tables[0].Rows[0]["Books"].ToString();
            txtmusic.Text = ds.Tables[0].Rows[0]["Music"].ToString();
            txttvshows.Text = ds.Tables[0].Rows[0]["tvshows"].ToString();
            txtmovies.Text = ds.Tables[0].Rows[0]["Movies"].ToString();
            txtcuisine.Text = ds.Tables[0].Rows[0]["Cuisine"].ToString();
            ddlsmoking.SelectedItem.Text = ds.Tables[0].Rows[0]["Smoking"].ToString();
            ddldrinking.SelectedItem.Text = ds.Tables[0].Rows[0]["Drinking"].ToString();
   //         txtmusic.Text = ds.Tables[0].Rows[0]["Music"].ToString();
  
        }
    }
    protected void ddldrinking_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("Update SocialProfileMaster Set Relation_ship_Status='" + ddlrelationship_status.SelectedItem.Text + "',Ethnicity='" + ddlethinicity.SelectedItem.Text + "',Religion='" + ddlreligion.SelectedItem.Text + "',Home_Town='" + txthometown.Text + "',Passion='" + txtpassion.Text + "', Sports='" + txtsports.Text + "',Books='" + txtbooks.Text + "',Music='" + txtmusic.Text + "',tvshows='" + txttvshows.Text + "',Movies='" + txtmovies.Text + "',Cuisine='" + txtcuisine.Text + "',Smoking='" + ddlsmoking.SelectedItem.Text + "',Drinking='" + ddldrinking.SelectedItem.Text + "' where User_ID='"+lblmsg.Text+"'", con);
        cmd.ExecuteNonQuery();
        //lblmsg0.Text = "success";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Profile_HomePage.aspx");
    }
}
