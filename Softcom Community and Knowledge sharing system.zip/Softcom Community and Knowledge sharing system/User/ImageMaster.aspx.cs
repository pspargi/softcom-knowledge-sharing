﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class User_ImageMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    static int[] abc;
    static int cnt;
    static int cnt1;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindDdlImageCatMaster();
            BindList();
            Panel1.Visible = true;
            Panel2.Visible = false;
                    
        }
        


    }
    void BindList()
    {
        string str = ("SELECT ImageMaster.Image_ID,ImageCatMaster.Image_Cat_name, '~/Uploaded Images/'+ Image_file  as Image_file, ImageMaster.Image_name FROM ImageCatMaster INNER JOIN ImageMaster ON ImageCatMaster.Image_Cat_ID = ImageMaster.Image_Cat_ID where ImageMaster.Delete_flag='True' and ImageMaster.User_ID="+Session["USER_ID"]);
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
           DSImagemaster.DataSource = ds;
           DSImagemaster.DataBind();

        }
        else
        {
            DSImagemaster.DataSource = null;
            DSImagemaster.DataBind();
        }
        ViewState["IMAGE_CAT_ID"] = ddlimagecatname.SelectedValue;
        string str1 = "SELECT Image_ID,'~/Uploaded Images/'+ Image_file  as Image_file, Image_name FROM ImageMaster  where ImageMaster.Delete_flag='True' and ImageMaster.User_ID='"+Session["USER_ID"]+"' and Image_CAT_ID='" + ViewState["IMAGE_CAT_ID"]+"'";
        da = new SqlDataAdapter(str1, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DSImagemaster.DataSource = ds;
            DSImagemaster.DataBind();
            abc = new int[ds.Tables[0].Rows.Count];
            for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
            {
                abc[j] = Convert.ToInt32(ds.Tables[0].Rows[j]["Image_ID"].ToString());

            }

        }
        else
        {
            DSImagemaster.DataSource = null;
            DSImagemaster.DataBind(); 
        }
    }
    void Bindgird1()
    {
        object obj = new object();
        if (ViewState["imageid"] != null)
        {
            obj = ViewState["imageid"].ToString();
            for (int k = 0; k < abc.GetLength(0); k++)
            {
                if (abc[k] ==Convert.ToInt32 (ViewState["imageid"].ToString()))
                {
                    ViewState["pid"] = k;
                }
            }
        }
        else
        {
            obj = ViewState["nextid"].ToString();
        }

        String str = "(Select Image_ID,Image_name,'~/Uploaded Images/'+ Image_file  as Image_file from ImageMaster where Image_ID='"+obj+"')";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdFullImage.DataSource = ds;
            grdFullImage.DataBind();
        }
        else
        {
            grdFullImage.DataSource = null;
            grdFullImage.DataBind();
        }
        if (ViewState["pid"] != null)
        {
            cnt = Convert.ToInt32(ViewState["pid"].ToString());
        }
        if (ViewState["lid"] != null)
        {
            cnt1 = Convert.ToInt32(ViewState["lid"].ToString());
        }
        
            ViewState["pid"] = null;
            ViewState["lid"] = null;
    }
    void BindDdlImageCatMaster()
    {
        string str = "Select * from ImageCatMaster";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlimagecatname.DataSource = ds;
            ddlimagecatname.DataTextField = "Image_Cat_name";
           ddlimagecatname.DataValueField = "Image_Cat_ID";
            ddlimagecatname.DataBind();
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["Image_ID"] != null)
        {
            string str = "Select * from ImageMaster where Image_ID=" + ViewState["Image_ID"];
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(str, con);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (File.Exists(Server.MapPath("~/Uploaded Images/" + ds.Tables[0].Rows[0]["Image_file"].ToString())))
                {
                    File.Delete(Server.MapPath("~/Uploaded Images/" + ds.Tables[0].Rows[0]["Image_file"].ToString()));
                }
            }
            string str1 = "Delete from ImageMaster where Image_ID=" + ViewState["Image_ID"];
            cmd = new SqlCommand(str1, con);
            cmd.ExecuteNonQuery();
            ViewState["Image_ID"]=null;
            btnsave_Click(sender, e);
            lblmsg.Text = "Record Updated";
        }
        else
        {
            
          
            if (FileUpload1.HasFile)
            {
               // string FileName = Server.HtmlEncode(FileUpload1.FileName);
               // string extension = Path.GetExtension(FileName);
               // if ((extension == ".JPEG") || (extension == ".GIF") || (extension == ".PNG") || (extension == ".JFIF")||(extension==".Bitmap File"))
                {
                    string str = ("Insert into ImageMaster(Image_Cat_ID,User_ID,Image_name,Image_file,Delete_flag)values('" + ddlimagecatname.SelectedValue + "','"+Session["USER_ID"]+"','" + txtimagename.Text + "','" + FileUpload1.FileName + "','False')");
                   cmd = new SqlCommand(str, con);
                    cmd.ExecuteNonQuery();
                    FileUpload1.SaveAs(Server.MapPath("~/Uploaded Images/" + FileUpload1.FileName));
                    lblmsg.Text = "Record will send for confirm";
                }
               // else
         //       {
          //          lblmsg.Text = "Image is not in Real format";
           //     }
            }
           
        }
        BindList();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        ddlimagecatname.SelectedIndex = 0;
        txtimagename.Text = "";
        lblmsg.Text = "";
        
        
    }
    
   
   
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str1 = "Delete from ImageMaster where Image_ID=" + lbk.CommandArgument;
        string str = "Select * from ImageMaster where Image_ID=" + lbk.CommandArgument;
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(str, con);
        da.Fill(ds); 
        if (ds.Tables[0].Rows.Count > 0)
	    {
            if (File.Exists(Server.MapPath("~/Uploaded Images/"+ ds.Tables[0].Rows[0]["Image_file"].ToString())))
            {
                File.Delete(Server.MapPath("~/Uploaded Images/" + ds.Tables[0].Rows[0]["Image_file"].ToString()));
            }
	    }
       
        cmd = new SqlCommand(str1,con);
        cmd.ExecuteNonQuery();
      
        lblmsg.Text = "Record Deleted";
        BindList();
  
    }

    
    protected void lbkedit_Click1(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "Select * from ImageMaster where Image_ID= " + lbk.CommandArgument.ToString();
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {

            ViewState["Image_ID"] = lbk.CommandArgument.ToString();
            ddlimagecatname.SelectedValue = ds.Tables[0].Rows[0]["Image_Cat_ID"].ToString();
            txtimagename.Text = ds.Tables[0].Rows[0]["Image_name"].ToString();
        }
    }

    protected void ddlimagecatname_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindList();
        ViewState["ChangeID"] = ddlimagecatname.SelectedValue;
       
    }
   
    protected void lbkclosefullfscrn_Click(object sender, EventArgs e)
    {
         
        Panel2.Visible = false;
        Panel1.Visible = true;
     
  
    }
    protected void Imbtnimage_Click(object sender, ImageClickEventArgs e)
    {
        ViewState["imageid"] = null;
        ImageButton imgb = (ImageButton)sender;
        ViewState["imageid"] = imgb.CommandArgument;
        Panel1.Visible = false;
        Bindgird1();
        Panel2.Visible = true;
               
       
    }
    
    protected void lbknext_Click1(object sender, EventArgs e)
    {
        ViewState["imageid"] = null;
        ViewState["nextid"] = null;
        Preview.Visible = true;
       


        if (abc.GetLength(0) > cnt)
        {
            if (abc.GetLength(0) - 1 > cnt)
            {
                ViewState["nextid"] = abc[cnt];
                ViewState["lid"] = cnt;
                cnt++;
                Bindgird1();
               
              }
            else
            {
                lbknext.Visible = false;
                ViewState["nextid"] = abc[cnt];
                ViewState["lid"] = cnt;
                cnt++;
                Bindgird1();

            }
        }  
       
        }

    protected void Preview_Click(object sender, EventArgs e)
    {
        ViewState["imageid"] = null;
        ViewState["nextid"] = null;
        lbknext.Visible = true;

        
        if (0 <= cnt1)
        {
            if (1 <= cnt1)
            {
                ViewState["nextid"] = abc[cnt1];
                ViewState["pid"] = cnt1;
                cnt1--;
                Bindgird1();
                
            }
            else
            {
                Preview.Visible = false;
                ViewState["nextid"] = abc[cnt1];
                ViewState["pid"] = cnt1;
                cnt1--;
                Bindgird1();

            }
        }  
    }
    protected void DSImagemaster_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
