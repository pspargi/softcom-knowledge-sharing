﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="FriendsMaster.aspx.cs" Inherits="User_FriendsMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 98%;
        }
        .style4
        {
            height: 23px;
            width: 218px;
        }
        .style6
        {
            height: 13px;
            width: 218px;
        }
        .style8
        {
            width: 87px;
        }
        .style9
        {}
        .style10
        {
            height: 23px;
            width: 97px;
            text-align: right;
        }
        .style11
        {
            height: 13px;
            width: 97px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdimagefriends" runat="server" AllowPaging="True" 
                    AutoGenerateColumns="False" style="margin-left: 0px" CellPadding="4" 
                    ForeColor="#333333" GridLines="None"> 
                    
                    <RowStyle BackColor="#E3EAEB" />
                    
                    <Columns>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <table class="style1">
                                    <tr>
                                        <td class="style8" rowspan="2">
                                            <asp:Image ID="Image1" runat="server" ImageUrl='<%# Eval("Photo_file") %>' 
                                                Height="90px" Width="70px" />
                                        </td>
                                        <td class="style10">
                                            Name::</td>
                                        <td class="style4" style="text-align: left">
                                            <asp:Label ID="lblfirstname" runat="server" Text='<%# Eval("First_name") %>'></asp:Label>
                                            <asp:Label ID="lblmidlename" runat="server" Text='<%# Eval("Midle_name") %>'></asp:Label>
                                            <asp:Label ID="lblimagelastname" runat="server" Text='<%# Eval("Last_name") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style11" style="text-align: right">
                                            Email ID::&nbsp;
                                        </td>
                                        <td class="style6" style="text-align: left">
                                            <asp:Label ID="lblemailid" runat="server" Text='<%# Eval("Email_Id") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style9" colspan="3">
                                            &nbsp; City::<asp:Label ID="lblcity" runat="server" Text='<%# Eval("City_name") %>'></asp:Label>
                                            &nbsp;&nbsp; State::<asp:Label ID="lblstate" runat="server" 
                                                Text='<%# Eval("State_name") %>'></asp:Label>
                                            &nbsp;&nbsp;&nbsp; Country::<asp:Label ID="lblcountry" runat="server" 
                                                Text='<%# Eval("Country_name") %>'></asp:Label>
                                        </td>
                                    </tr>
                                </table>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <asp:Button ID="btnRemove" runat="server" 
                                    CommandArgument='<%# Eval("User_ID") %>' Text="Remove" 
                                    BackColor="#999966" />
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <asp:Button ID="btnSendmsg" runat="server" Text="Send Message" 
                                    BackColor="#999966" />
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
    </table>
</asp:Content>

