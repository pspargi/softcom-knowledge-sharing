﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;


public partial class Admin_Ebookaproval : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindGrid();
        }

    }
    void BindGrid()
    {
        string str = "select Ebook_ID,User_ID,('~/Uploaded Ebooks/'+ Ebook_file)  as Ebook_fl,'~/Uploaded Ebooks/'+ Ebook_file  as Ebook_file from EbookMaster where Delete_flag='False' and User_ID=3";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdebookapproval.DataSource = ds;
            grdebookapproval.DataBind();
        }
        else
        {
            grdebookapproval.DataSource = null;
            grdebookapproval.DataBind();
        }
    }
    
    protected void btnapprove_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < grdebookapproval.Rows.Count; i++)
        {
            if (((CheckBox)grdebookapproval.Rows[i].FindControl("ckbebookfile")).Checked == true)
            {
                String str = "Update EbookMaster set Delete_flag='True' where Ebook_ID='" + Convert.ToInt32(((Label)grdebookapproval.Rows[i].FindControl("lblebookid")).Text) + "'";
                cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                lblmsg.Text = "Updated Successfully";

            }
            else
            {
                String str1 = "Delete from EbookMaster where Ebook_ID='" + Convert.ToInt32(((Label)grdebookapproval.Rows[i].FindControl("lblebookid")).Text) + "'";
                String str = "Select * from EbookMaster where Ebook_ID=" + Convert.ToInt32(((Label)grdebookapproval.Rows[i].FindControl("lblebookid")).Text);
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(str, con);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (File.Exists(Server.MapPath("~/Uploaded Ebooks/" + ds.Tables[0].Rows[0]["Ebook_file"].ToString())))
                    {
                        File.Delete(Server.MapPath("~/Uploaded Ebooks/" + ds.Tables[0].Rows[0]["Ebook_file"].ToString()));
                    }
                }

                cmd = new SqlCommand(str1, con);
                cmd.ExecuteNonQuery();
            }
                  
          
        }
        lblmsg.Text = "Updated Success Fully";
        BindGrid();
    
    }
}
