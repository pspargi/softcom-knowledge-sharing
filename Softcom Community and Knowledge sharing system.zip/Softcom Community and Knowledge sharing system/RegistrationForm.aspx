﻿<%@ Page Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="RegistrationForm.aspx.cs" Inherits="User_RegistrationForm" %>


<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 86%;
        }
        .style2
        {
            height: 60px;
            font-size: xx-large;
            font-family: Roman;
            font-weight: 700;
            text-align: center;
        }
        .style5
        {
            text-align: right;
            height: 38px;
        }
        .style6
        {
            width: 73px;
        }
        .style10
        {
            text-align: right;
            width: 316px;
            height: 36px;
        }
        .style11
        {
            width: 184px;
            height: 36px;
            text-align: left;
        }
        .style12
        {
            width: 73px;
            height: 36px;
        }
        .style13
        {
            text-align: right;
            width: 316px;
            height: 26px;
        }
        .style14
        {
            width: 184px;
            height: 26px;
            text-align: left;
        }
        .style15
        {
            width: 73px;
            height: 26px;
        }
        .style16
        {
            text-align: center;
            height: 34px;
        }
        .style17
        {
            text-align: right;
            height: 27px;
            width: 316px;
        }
        .style18
        {
            width: 184px;
            height: 27px;
            text-align: left;
        }
        .style19
        {
            width: 73px;
            height: 27px;
        }
        .style20
        {
            text-align: right;
            width: 316px;
        }
        .style24
        {
            width: 184px;
            text-align: left;
        }
        .style25
        {
            text-align: right;
            width: 316px;
            height: 21px;
        }
        .style26
        {
            width: 184px;
            height: 21px;
        }
        .style27
        {
            width: 73px;
            height: 21px;
        }
        .style28
        {
            text-align: right;
            width: 316px;
            height: 11px;
        }
        .style29
        {
            width: 184px;
            height: 11px;
            text-align: left;
        }
        .style30
        {
            width: 73px;
            height: 11px;
        }
    </style>
    </asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td class="style2" colspan="3">
                <asp:Label ID="Label11" runat="server" Text="REGISTRATION FORM"></asp:Label>
                <asp:Label ID="lblwarn" runat="server" Font-Bold="True" Font-Size="XX-Large"></asp:Label>
                </td>
        </tr>
        <tr>
            <td class="style20">
                    <asp:Label ID="Label12" runat="server" Text="User_Type"></asp:Label>
                </td>
            <td class="style24">
                <asp:RadioButtonList ID="rbluser_type" runat="server" AutoPostBack="True" 
                    RepeatDirection="Horizontal">
                    <asp:ListItem>User</asp:ListItem>
                    <asp:ListItem>Admin</asp:ListItem>
                </asp:RadioButtonList>
                &nbsp;</td>
            <td class="style6">
                <asp:RequiredFieldValidator ID="RequiredFieldValidator10" runat="server" 
                    ControlToValidate="rbluser_type" ErrorMessage="*" ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
        </tr>
        <tr>
            <td class="style20">
                <asp:Label ID="Label2" runat="server" Text="Employeer Id:"></asp:Label>
                -</td>
            <td class="style24">
                <asp:TextBox ID="txtempid" runat="server" Width="145px"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                    ControlToValidate="txtempid" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style20">
                <asp:Label ID="Label3" runat="server" Text="First Name:-"></asp:Label>
            </td>
            <td class="style24">
                <asp:TextBox ID="txtfname" runat="server" Width="143px" 
                    style="text-align: left"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                    ControlToValidate="txtfname" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style20">
                <asp:Label ID="Label4" runat="server" Text="Middle Name:-"></asp:Label>
            </td>
            <td class="style24">
                <asp:TextBox ID="txtmname" runat="server" Width="145px"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                    ControlToValidate="txtmname" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style20">
                <asp:Label ID="Label5" runat="server" Text="Last Name:-"></asp:Label>
            </td>
            <td class="style24">
                <asp:TextBox ID="txtlname" runat="server" Width="144px" 
                    style="text-align: left"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" 
                    ControlToValidate="txtlname" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style17">
                <asp:Label ID="Label6" runat="server" Text="&nbsp;Email Address :-"></asp:Label>
            </td>
            <td class="style18">
                <asp:TextBox ID="txtemail" runat="server" Width="144px"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" 
                    ControlToValidate="txtemail" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
            <td class="style19">
                <asp:Label ID="lblerroremail" runat="server" ForeColor="#CC0000"></asp:Label>
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                    ControlToValidate="txtemail" ErrorMessage="Enter Valid Email Address" 
                    SetFocusOnError="True" 
                    ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" 
                    ValidationGroup="1"></asp:RegularExpressionValidator>
                </td>
        </tr>
        <tr>
            <td class="style13">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Label ID="Label7" runat="server" Text="Password :-"></asp:Label>
            </td>
            <td class="style14">
                <asp:TextBox ID="txtpassword" runat="server" Height="22px" 
                    onprerender="txtremail_PreRender" Width="146px" TextMode="Password"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" 
                    ControlToValidate="txtpassword" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
            <td class="style15">
                <asp:CompareValidator ID="CompareValidator1" runat="server" 
                    ControlToCompare="txtpassword" ControlToValidate="txtrepassword" 
                    ErrorMessage="Enter Same Password In Both field" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:CompareValidator>
            </td>
        </tr>
        <tr>
            <td class="style10">
                <asp:Label ID="Label8" runat="server" Text="      Renter Password :-"></asp:Label>
            </td>
            <td class="style11">
                <asp:TextBox ID="txtrepassword" runat="server" TextMode="Password" 
                    Width="147px"></asp:TextBox>
                &nbsp;<asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" 
                    ControlToValidate="txtrepassword" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
                &nbsp;&nbsp;
            </td>
            <td class="style12">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style20">
                &nbsp;<asp:Label ID="Label9" runat="server" Text="Security Question"></asp:Label>
                :-</td>
            <td class="style24">
                <asp:DropDownList ID="drlquestion" runat="server" Height="16px" Width="146px" 
                    onselectedindexchanged="drlquestion_SelectedIndexChanged">
                    <asp:ListItem>What is Your Pat Name?</asp:ListItem>
                    <asp:ListItem>Who is your Best Friend?</asp:ListItem>
                    <asp:ListItem>Choose My Own Question</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style28">
                </td>
            <td class="style29">
                <asp:TextBox ID="txtmyowner" runat="server" Width="147px" Visible="False"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator8" runat="server" 
                    ControlToValidate="txtmyowner" ErrorMessage="*" SetFocusOnError="True"></asp:RequiredFieldValidator>
            </td>
            <td class="style30">
                </td>
        </tr>
        <tr>
            <td class="style25">
                :<asp:Label ID="Label10" runat="server" Text="Answer for It :-"></asp:Label>
            </td>
            <td class="style26" style="margin-left: 40px; text-align: left;">
                &nbsp;<asp:TextBox ID="txtanswer" runat="server" Width="141px"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator9" runat="server" 
                    ControlToValidate="txtanswer" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
                &nbsp;&nbsp;&nbsp;&nbsp;
                </td>
            <td class="style27">
                </td>
            <asp:Label ID="Label1" runat="server" Text="Label"></asp:Label>
        </tr>
        <tr>
            <td class="style20">
                <asp:Label ID="lbb" runat="server" Text="Label" Visible="False"></asp:Label>
            </td>
            <td class="style24">
                &nbsp;</td>
            <td class="style6">
                <asp:Label ID="lblmsg1" runat="server"></asp:Label>
                <asp:Label ID="lblmsg" runat="server"></asp:Label>
                </td>
        </tr>
        <tr>
            <td class="style16" colspan="3">
                <asp:Button ID="btnsingup" runat="server" onclick="btnsingup_Click" 
                    Text="Sing Up" style="height: 26px" ValidationGroup="1" 
                    BackColor="#999966" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btnclearall" runat="server" onclick="btnclearall_Click" 
                    Text="Exit" Width="51px" BackColor="#999966" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btnclearall0" runat="server" onclick="btnBack_click" 
                    Text="Back" Visible="False" Width="68px" />
            </td>
        </tr>
        <tr>
            <td class="style5" colspan="3">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </tr>
    </table>
   </asp:Content>
