﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_MasterPage : System.Web.UI.MasterPage
{
    SqlConnection con;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
    }
    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {
        if (Menu1.SelectedItem.Text == "Log out")
        {
            string str = "Update LoginMaster Set Active_Flag='False' where User_ID='" + Session["USER_ID"] + "'";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            Response.Redirect("~/LoginMaster.aspx");
        }
        if (Menu1.SelectedItem.Text == "Home")
        {
            Session["visitor"] = null;
            Response.Redirect("Profile_HomePage.aspx");
        }
    }


}
