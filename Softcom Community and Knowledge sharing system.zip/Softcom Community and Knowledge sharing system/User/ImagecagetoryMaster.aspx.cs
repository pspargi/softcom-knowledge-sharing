﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_ImagecagetoryMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            bindgrid();

        }

    }
    void bindgrid()
    {
        string str = "select * from ImageCatMaster where User_ID='"+Session["USER_ID"]+"'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdImageCategory.DataSource = ds;
            grdImageCategory.DataBind();
        }
        else
        {
            grdImageCategory.DataSource = null;
            grdImageCategory.DataBind();
        }

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["Image_Cat_ID"] != null)
        {
            String str = "update ImageCatMaster set Image_Cat_name='" + txtImagecatname.Text + "',Image_Cat_Description='" + txtImagecatdescr.Text + "'where Image_Cat_ID='" + ViewState["Image_Cat_ID"].ToString() + "'";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btnCancel_Click(sender, e);
            lblmsg.Text = "Record Updated";
            btnSave.Text = "Save";
        }
        else
        {
            string str = "Insert into ImageCatMaster(User_ID,Image_Cat_name,Image_Cat_description)values('"+Session["User_ID"]+"','" + txtImagecatname.Text + "','" + txtImagecatdescr.Text + "')";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btnCancel_Click(sender, e);
            lblmsg.Text = "Record Inserted";
        }
        bindgrid();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtImagecatname.Text = "";
        txtImagecatdescr.Text = "";
        lblmsg.Text = "";
        ViewState.Clear();
    }
    protected void lbkedit_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "select * from ImageCatMaster where Image_Cat_ID=" + lbk.CommandArgument.ToString();
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ViewState["Image_Cat_ID"] = lbk.CommandArgument.ToString();
            txtImagecatname.Text = ds.Tables[0].Rows[0]["Image_Cat_name"].ToString();
            txtImagecatdescr.Text = ds.Tables[0].Rows[0]["Image_Cat_Description"].ToString();
        }
        btnSave.Text = "Update";

    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "Delete from ImageCatMaster where Image_Cat_ID=" + lbk.CommandArgument.ToString();
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        btnCancel_Click(sender, e);
        lblmsg.Text = "Record Deleted";
        bindgrid();
    }
}