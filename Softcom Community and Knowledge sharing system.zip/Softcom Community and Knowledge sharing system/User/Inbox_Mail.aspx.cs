﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Inbox_Mail : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        lbluserid.Text = Convert.ToString(Session["USER_ID"]);
        if (!IsPostBack)
        {
            da = new SqlDataAdapter("Select Email_Id from LoginMaster where User_ID='" + lbluserid.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblemail_id.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
            }
            bindgrid();
            string str = "Read";
            cmd = new SqlCommand("Update Email_Master set Status='" + str + "' where Receiver='"+lblemail_id.Text+"'", con);
            cmd.ExecuteNonQuery();
        }
    }
    void bindgrid()
    {
        da = new SqlDataAdapter("Select * from Email_Master where Receiver='" + lblemail_id.Text + "' Order by Date_Time desc", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dgvinbox.DataSource = ds;
            dgvinbox.DataBind();
        }
        else
        {
            dgvinbox.DataSource = null;
            dgvinbox.DataBind();
        }
    }

    
    protected void btnReply_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        Session["email_no"] = bt.CommandArgument.ToString();
        Session["email_type"] = "Reply";
        Response.Redirect("Compose_Mail.aspx");
    }
    protected void btnforward_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender; 
        Session["email_no"] = bt.CommandArgument.ToString();
        Session["email_type"] = "Forward"; 
        Response.Redirect("Compose_Mail.aspx");
       
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
      Button bt = (Button)sender;
      cmd = new SqlCommand("Delete from Email_Master where Email_no='"+bt.CommandArgument.ToString()+"'", con);
      cmd.ExecuteNonQuery();
      bindgrid();
    }
}
