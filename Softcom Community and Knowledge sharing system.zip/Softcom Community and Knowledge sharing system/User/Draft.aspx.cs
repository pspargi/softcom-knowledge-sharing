﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Draft : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
          con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        //lbluserid.Text="1";
        lbluserid.Text = Convert.ToString(Session["USER_ID"]);
        if(!IsPostBack)
        {
            da = new SqlDataAdapter("Select Email_Id from LoginMaster where User_ID='" + lbluserid.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblemailidd.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
            }
            bindgrid();
            }    
    }
    void bindgrid()
    {
        da = new SqlDataAdapter("Select * from Draft_message where Sender='" + lblemailidd.Text+ "' Order by Date_Time desc", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dgvdraft.DataSource = ds;
            dgvdraft.DataBind();
        }
    }
    protected void btnsend_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        Session["draft_no"] = bt.CommandArgument.ToString();
        Session["email_type"] = "Draft";
        Response.Redirect("Compose_Mail.aspx");
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        Button bt=(Button)sender;
        cmd = new SqlCommand("Delete from Draft_message where draft_no='"+bt.CommandArgument.ToString()+"'", con);
        cmd.ExecuteNonQuery();
        bindgrid();
      }

    protected void lbcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Profile_HomePage.aspx");
    }
}
