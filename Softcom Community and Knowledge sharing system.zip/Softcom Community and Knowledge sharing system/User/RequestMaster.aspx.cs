﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_RequestMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
      
        
        if(!IsPostBack)
        {
            BindGrid();
        }

    }
    void BindGrid()
    {

        string str = "SELECT     CityMaster.City_name, StateMaster.State_name, CountryMaster.Country_name, ProfileMaster.User_ID, ProfileMaster.First_name,ProfileMaster.Midle_name, ProfileMaster.Last_name, '~/Uploaded Images/'+ Photo_file  as Photo_file, ProfileMaster.Address_line1, ProfileMaster.Address_line2, ProfileMaster.phone_no, ProfileMaster.Email_Id, FriendsMaster.User_ID1, FriendsMaster.User_ID2 FROM StateMaster FULL OUTER JOIN ProfileMaster ON StateMaster.State_ID = ProfileMaster.State_ID FULL OUTER JOIN CountryMaster ON ProfileMaster.Country_ID = CountryMaster.Country_ID FULL OUTER JOIN CityMaster ON ProfileMaster.City_ID = CityMaster.City_ID FULL OUTER JOIN FriendsMaster ON ProfileMaster.User_ID = FriendsMaster.User_ID2 where FriendsMaster.User_ID2='" + Session["USER_ID"] + "' and FriendsMaster.Delete_flag='False' ";
            da = new SqlDataAdapter(str, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                grdRequestMaster.DataSource = ds;
                grdRequestMaster.DataBind();
            }
            else
            {
                grdRequestMaster.DataSource = null;
                grdRequestMaster.DataBind();
            }
        
    
    
    }
    
    protected void btnAccept_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string str = "update FriendsMaster set Delete_flag = 'True' where User_ID1='"+btn.CommandArgument+"'and User_ID2='"+Session["USER_ID"]+"'";
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        BindGrid();
    }
    protected void btnreject_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string str = "Delete from FriendsMaster where User_ID1='" + btn.CommandArgument + "' and User_ID2='" + Session["USER_ID"] + "' and Delete_flag='False'";
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        BindGrid();
    }
}

