﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Send_Jobpost : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
       lbuserid.Text = Convert.ToString(Session["USER_ID"]);
       // lbuserid.Text = "50";
        
        if (!IsPostBack)
        {
            da = new SqlDataAdapter("Select Email_Id from LoginMaster where User_ID='" + lbuserid.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lbemail.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
            }
            if (Session["job_post"] == "Forward")
            {
                da = new SqlDataAdapter("Select * from Jobpost_Inbox where Job_post_id='" + Session["Job_post_id"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtcompany_name.Text = ds.Tables[0].Rows[0]["Company_name"].ToString();
                    txtrequirement.Text = ds.Tables[0].Rows[0]["Requirement"].ToString();
                    txtdeignation.Text = ds.Tables[0].Rows[0]["Designation"].ToString();

                }
            }
            else if (Session["job_post"] == "Resend")
            {
                da = new SqlDataAdapter("Select * from Job_Post_SentIteam where Job_post_id='" + Session["Job_post_id"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtsendto.Text = ds.Tables[0].Rows[0]["Receiver"].ToString();
                    txtcompany_name.Text = ds.Tables[0].Rows[0]["Company_name"].ToString();
                    txtrequirement.Text = ds.Tables[0].Rows[0]["Requirement"].ToString();
                    txtdeignation.Text = ds.Tables[0].Rows[0]["Designation"].ToString();

                }
                Session["job_post"] = "";
                Session["Job_post_id"] = "";
            }
        }             
        
    }
    protected void btnsendjobpost_Click(object sender, EventArgs e)
    {
        string st = "Unread";
        DateTime dt = Convert.ToDateTime(System.DateTime.Now.ToString());
        cmd = new SqlCommand("Insert into Jobpost_Inbox(sender,Receiver,Company_name,Requirement,Designation,Status,Date_Time)values('" + lbemail.Text + "','" + txtsendto.Text + "','" + txtcompany_name.Text + "','" + txtrequirement.Text + "','" + txtdeignation.Text + "','"+st+"','"+dt+"')", con);
        cmd.ExecuteNonQuery();
        da = new SqlDataAdapter("Select MAX(Job_post_id) as maxuser FROM Jobpost_Inbox", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbmaxsent.Text = ds.Tables[0].Rows[0]["maxuser"].ToString();
        }
        cmd = new SqlCommand("Insert Into Job_Post_SentIteam(Job_post_id,sender,Receiver,Company_name,Requirement,Designation,Date_Time) values('"+lbmaxsent.Text+"','"+lbemail.Text+"','"+txtsendto.Text+"','"+txtcompany_name.Text+"','"+txtrequirement.Text+"','"+txtdeignation.Text+"','"+dt+"')", con);
        cmd.ExecuteNonQuery();
        lblmsg.Text = "Job post has been sent";
   }
    protected void txtmoreinfo_TextChanged(object sender, EventArgs e)
    {

    }
}
