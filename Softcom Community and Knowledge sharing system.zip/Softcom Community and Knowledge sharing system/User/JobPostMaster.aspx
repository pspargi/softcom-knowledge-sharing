﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="JobPostMaster.aspx.cs" Inherits="User_JobPostMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <h2>
                    JobPost Master</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Company Name:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtcompanyname" runat="server" style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Company Address:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtcompanyadd" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Qualification:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtqualification" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Post:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtpost" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Date of Interview</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtdateofiterviw" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" />
                <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                    Text="Cancel" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdjobpostmaster" runat="server" AutoGenerateColumns="False">
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkedit" runat="server" 
                                    CommandArgument='<%# Eval("Jobpost_ID") %>' onclick="lbkedit_Click">Edit</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkdelete" runat="server" 
                                    CommandArgument='<%# Eval("Jobpost_ID") %>' onclick="lbkdelete_Click">Delete</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Company_name" HeaderText="Comany Name" />
                        <asp:BoundField DataField="Company_adress" HeaderText="Company Address" />
                        <asp:BoundField DataField="Qualification" HeaderText="Qualification" />
                        <asp:BoundField DataField="Company_post" HeaderText="Company Post" />
                        <asp:BoundField DataField="Date_of_interview" HeaderText="Interview Date" />
                    </Columns>
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

