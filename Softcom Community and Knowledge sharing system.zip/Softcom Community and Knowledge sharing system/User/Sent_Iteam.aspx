﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Sent_Iteam.aspx.cs" Inherits="User_Sent_Iteam" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
  <style type="text/css">
        .style1
        {
            width: 41%;
        }
        .style2
        {
            text-align: center;
        }
        .style3
        {
            width: 239px;
            text-align: right;
            font-weight: bold;
        }
        .style4
        {
            text-align: center;
            width: 239px;
        }
    </style>
</asp:Content>
    <asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:Label ID="lbluserid" runat="server" Visible="False"></asp:Label>
    <asp:GridView ID="dgvsent" runat="server" AutoGenerateColumns="False" 
        Width="514px" CellPadding="4" ForeColor="#333333" GridLines="None">
        <RowStyle BackColor="#E3EAEB" />
        <Columns>
            <asp:TemplateField HeaderText="Scrabs">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td class="style3">
                                Sent to :</td>
                            <td style="text-align: left">
                                <asp:TextBox ID="TextBox2" runat="server" Height="26px" ReadOnly="True" 
                                    Text='<%# Eval("Receiver") %>' Width="209px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style3">
                                Subject :-</td>
                            <td style="text-align: left">
                                <asp:TextBox ID="TextBox1" runat="server" Height="25px" ReadOnly="True" 
                                    Text='<%# Eval("Subject") %>' Width="213px" BackColor="White"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style3">
                                Message :-</td>
                            <td>
                                <asp:TextBox ID="txtmessage" runat="server" Height="50px" ReadOnly="True" 
                                    Text='<%# Eval("Message") %>' TextMode="MultiLine" Width="218px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style4">
                                &nbsp;</td>
                            <td class="style2">
                                <asp:Label ID="lbdate" runat="server" Text='<%# Eval("Date_Time") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style2" colspan="2">
                                <asp:Button ID="btnResent" runat="server" 
                                    CommandArgument='<%# Eval("Email_no") %>' onclick="btnResent_Click" 
                                    Text="Resend" BackColor="#666633" />
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btnDelete" runat="server" 
                                    CommandArgument='<%# Eval("Email_no") %>' Height="26px" 
                                    onclick="btnDelete_Click" Text="Delete" Width="61px" BackColor="#666633" />
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#7C6F57" />
        <AlternatingRowStyle BackColor="White" />
    </asp:GridView>
    <asp:Label ID="lblemailid" runat="server" Text="lblemail_id" Visible="False"></asp:Label>
    </asp:Content>

