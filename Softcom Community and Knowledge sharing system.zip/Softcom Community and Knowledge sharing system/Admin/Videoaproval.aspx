﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="Videoaproval.aspx.cs" Inherits="Admin_Videoaproval" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td>
                <h5 style="text-align: center">
                    Video Approval
                </h5>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                <asp:GridView ID="grdvideoapproval" runat="server" AutoGenerateColumns="False" 
                    style="margin-top: 0px" CellPadding="4" ForeColor="#333333" 
                    GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <asp:CheckBox ID="ckbvideofile" runat="server" />
                                <br />
                                <asp:Label ID="lblvidoid" runat="server" Text='<%# Eval("Video_ID") %>' 
                                    Visible="False"></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Video File name">
                            <ItemTemplate>
                                <asp:Label ID="lblfilename" runat="server" Text='<%# Eval("Video_file") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Download">
                            <ItemTemplate>
                                <asp:HyperLink ID="hpldownload" runat="server" 
                                    NavigateUrl='<%# Eval("Video_fl") %>'>Download</asp:HyperLink>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                <asp:Button ID="btnApprove" runat="server" onclick="btnaprove_Click" 
                    Text="Aprove" />
                <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                    Text="Cancel" />
            </td>
        </tr>
    </table>
</asp:Content>

