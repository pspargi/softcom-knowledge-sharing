﻿<%@ Application Language="C#" %>
<%@ Import Namespace="System.Data"%>
<script runat="server">
    
    System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
    void Application_Start(object sender, EventArgs e) 
    {
        // Code that runs on application startup

    }
    
    void Application_End(object sender, EventArgs e) 
    {
   //     System.Data.SqlClient.SqlConnection   con = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        //  Code that runs on application shutdown
        string str = "update LoginMaster set Active_flag='False' where User_ID='" + Session["USER_ID"] + "'";
        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        Session.Abandon();
           
    }
        
    void Application_Error(object sender, EventArgs e) 
    { 
        // Code that runs when an unhandled error occurs

    }

    void Session_Start(object sender, EventArgs e) 
    {
        // Code that runs when a new session is started

    }

    void Session_End(object sender, EventArgs e) 
    {
        // Code that runs when a session ends. 
        // Note: The Session_End event is raised only when the sessionstate mode
        // is set to InProc in the Web.config file. If session mode is set to StateServer 
        // or SQLServer, the event is not raised.

    }
       
</script>
