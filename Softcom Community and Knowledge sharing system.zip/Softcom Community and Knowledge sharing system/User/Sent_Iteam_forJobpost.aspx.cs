﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Sent_Iteam_forJobpost : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
       lbluserid.Text = Convert.ToString(Session["USER_ID"]);
//        lbluserid.Text = "50";
    
        if (!IsPostBack)
        {
            da = new SqlDataAdapter("Select Email_Id from LoginMaster where User_ID='" + lbluserid.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblemailid.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
            }
            bindgrid();
        }
    }
    void bindgrid()
    {
        da = new SqlDataAdapter("Select * from Job_Post_SentIteam where sender='"+lblemailid.Text+"'", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dgvsentiteam.DataSource = ds;
            dgvsentiteam.DataBind();

        }
        else
        {
            dgvsentiteam.DataSource = ds;
            dgvsentiteam.DataBind();
        }
    }
    protected void btnResend_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        Session["Job_post_id"] = bt.CommandArgument.ToString();
        Session["job_post"] = "Resend";
        Response.Redirect("Send_Jobpost.aspx");
   
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        cmd = new SqlCommand("Delete from Job_Post_SentIteam where Job_post_id='"+bt.CommandArgument.ToString()+"'", con);
        cmd.ExecuteNonQuery();
        bindgrid();
    }
}
