﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_SearchMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
      

    }
    void BindGrid()
    {

        string str = "SELECT CityMaster.City_name, StateMaster.State_name, CountryMaster.Country_name, ProfileMaster.First_name, ProfileMaster.Midle_name,ProfileMaster.Last_name,ProfileMaster.User_ID,'~/Uploaded Images/'+ Photo_file  as Photo_file,ProfileMaster.Phone_no,ProfileMaster.Email_Id, , ProfileMaster.Gender, ProfileMaster.Address_line1, ProfileMaster.Address_line2 FROM CountryMaster FULL OUTER JOIN ProfileMaster ON CountryMaster.Country_ID = ProfileMaster.Country_ID FULL OUTER JOIN StateMaster ON ProfileMaster.State_ID = StateMaster.State_ID FULL OUTER JOIN CityMaster ON ProfileMaster.City_ID = CityMaster.City_ID";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdsearchmaster.DataSource = ds;
            grdsearchmaster.DataBind();
        }
        else
        {
            grdsearchmaster.DataSource = null;
            grdsearchmaster.DataBind();
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (txtsearch.Text == "")
         {
      
         }
          else
         {
            string str3 = txtsearch.Text;
            string[] str1 = new string[10];
            string[] str2 = new string[10];
            char splitter = (' ');
            str1 = str3.Split(splitter);
            for (int i = 0; i < 10; i++)
            {
                if (str1.Length > i)
                {
                    str2[i] = str1[i];
                }
             
            }
            string str = "SELECT CityMaster.City_name, StateMaster.State_name, CountryMaster.Country_name, ProfileMaster.First_name, ProfileMaster.Midle_name,ProfileMaster.Last_name,ProfileMaster.User_ID,ProfileMaster.Phone_no,ProfileMaster.Email_Id, '~/Uploaded Images/'+ Photo_file  as Photo_file, ProfileMaster.Gender, ProfileMaster.Address_line1, ProfileMaster.Address_line2 FROM CountryMaster FULL OUTER JOIN ProfileMaster ON CountryMaster.Country_ID = ProfileMaster.Country_ID FULL OUTER JOIN StateMaster ON ProfileMaster.State_ID = StateMaster.State_ID FULL OUTER JOIN CityMaster ON ProfileMaster.City_ID = CityMaster.City_ID where ((CountryMaster.Country_name like '%" + str2[0] + "%')or(StateMaster.State_name like '%" + str2[0] + "%')or(CityMaster.City_name like '%" + str2[0] + "%') or (ProfileMaster.First_name like '%" + str2[0] + "%') or (ProfileMaster.Midle_name like '%" + str2[0] + "%') or (ProfileMaster.Last_name like '%" + str2[0] + "%') or (ProfileMaster.Address_line1 like '%" + str2[0] + "%') or (ProfileMaster.Address_line2 like '%" + str2[0] + "%') or (ProfileMaster.Email_Id like '" + str2[0] + "'))";
            str += "and ((CountryMaster.Country_name like '%" + str2[1] + "%')or(StateMaster.State_name like '%" + str2[1] + "%')or(CityMaster.City_name like '%" + str2[1] + "%') or (ProfileMaster.First_name like '%" + str2[1] + "%') or (ProfileMaster.Midle_name like '%" + str2[1] + "%') or (ProfileMaster.Last_name like '%" + str2[1] + "%') or (ProfileMaster.Address_line1 like '%" + str2[1] + "%') or (ProfileMaster.Address_line2 like '%" + str2[1] + "%') or (ProfileMaster.Email_Id like '" + str2[1] + "')) and ((CountryMaster.Country_name like '%" + str2[2] + "%')or(StateMaster.State_name like '%" + str2[2] + "%')or(CityMaster.City_name like '%" + str2[2] + "%') or (ProfileMaster.First_name like '%" + str2[2] + "%') or (ProfileMaster.Midle_name like '%" + str2[2] + "%') or (ProfileMaster.Last_name like '%" + str2[2] + "%') or (ProfileMaster.Address_line1 like '%" + str2[2] + "%') or (ProfileMaster.Address_line2 like '%" + str2[2] + "%') or (ProfileMaster.Email_Id like '" + str2[2] + "')) and ((CountryMaster.Country_name like '%" + str2[3] + "%')or(StateMaster.State_name like '%" + str2[3] + "%')or(CityMaster.City_name like '%" + str2[3] + "%') or (ProfileMaster.First_name like '%" + str2[3] + "%') or (ProfileMaster.Midle_name like '%" + str2[3] + "%') or (ProfileMaster.Last_name like '%" + str2[3] + "%') or (ProfileMaster.Address_line1 like '%" + str2[3] + "%') or (ProfileMaster.Address_line2 like '%" + str2[3] + "%') or (ProfileMaster.Email_Id like '" + str2[3] + "')) and ((CountryMaster.Country_name like '%" + str2[4] + "%')or(StateMaster.State_name like '%" + str2[4] + "%')or(CityMaster.City_name like '%" + str2[4] + "%') or (ProfileMaster.First_name like '%" + str2[4] + "%') or (ProfileMaster.Midle_name like '%" + str2[4] + "%') or (ProfileMaster.Last_name like '%" + str2[4] + "%') or (ProfileMaster.Address_line1 like '%" + str2[4] + "%') or (ProfileMaster.Address_line2 like '%" + str2[4] + "%') or (ProfileMaster.Email_Id like '" + str2[4] + "'))";
            str += "and ((CountryMaster.Country_name like '%" + str2[5] + "%')or(StateMaster.State_name like '%" + str2[5] + "%')or(CityMaster.City_name like '%" + str2[5] + "%') or (ProfileMaster.First_name like '%" + str2[5] + "%') or (ProfileMaster.Midle_name like '%" + str2[5] + "%') or (ProfileMaster.Last_name like '%" + str2[5] + "%') or (ProfileMaster.Address_line1 like '%" + str2[5] + "%') or (ProfileMaster.Address_line2 like '%" + str2[5] + "%') or (ProfileMaster.Email_Id like '" + str2[5] + "')) and ((CountryMaster.Country_name like '%" + str2[6] + "%')or(StateMaster.State_name like '%" + str2[6] + "%')or(CityMaster.City_name like '%" + str2[6] + "%') or (ProfileMaster.First_name like '%" + str2[6] + "%') or (ProfileMaster.Midle_name like '%" + str2[6] + "%') or (ProfileMaster.Last_name like '%" + str2[6] + "%') or (ProfileMaster.Address_line1 like '%" + str2[6] + "%') or (ProfileMaster.Address_line2 like '%" + str2[6] + "%') or (ProfileMaster.Email_Id like '" + str2[6] + "')) and ((CountryMaster.Country_name like '%" + str2[7] + "%')or(StateMaster.State_name like '%" + str2[7] + "%')or(CityMaster.City_name like '%" + str2[7] + "%') or (ProfileMaster.First_name like '%" + str2[7] + "%') or (ProfileMaster.Midle_name like '%" + str2[7] + "%') or (ProfileMaster.Last_name like '%" + str2[7] + "%') or (ProfileMaster.Address_line1 like '%" + str2[7] + "%') or (ProfileMaster.Address_line2 like '%" + str2[7] + "%') or (ProfileMaster.Email_Id like '" + str2[7] + "'))";
            str += "and ((CountryMaster.Country_name like '%" + str2[9] + "%')or(StateMaster.State_name like '%" + str2[9] + "%')or(CityMaster.City_name like '%" + str2[9] + "%') or (ProfileMaster.First_name like '%" + str2[9] + "%') or (ProfileMaster.Midle_name like '%" + str2[9] + "%') or (ProfileMaster.Last_name like '%" + str2[9] + "%') or (ProfileMaster.Address_line1 like '%" + str2[9] + "%') or (ProfileMaster.Address_line2 like '%" + str2[9] + "%') or (ProfileMaster.Email_Id like '" + str2[9] + "')) and ((CountryMaster.Country_name like '%" + str2[9] + "%')or(StateMaster.State_name like '%" + str2[9] + "%')or(CityMaster.City_name like '%" + str2[9] + "%') or (ProfileMaster.First_name like '%" + str2[9] + "%') or (ProfileMaster.Midle_name like '%" + str2[9] + "%') or (ProfileMaster.Last_name like '%" + str2[9] + "%') or (ProfileMaster.Address_line1 like '%" + str2[9] + "%') or (ProfileMaster.Address_line2 like '%" + str2[9] + "%') or (ProfileMaster.Email_Id like '" + str2[9] + "'))";
                da = new SqlDataAdapter(str, con);
                ds = new DataSet();
            
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                grdsearchmaster.DataSource = ds;
                grdsearchmaster.DataBind();
                }
                else
                {
                grdsearchmaster.DataSource = null;
                grdsearchmaster.DataBind();

                }
           
        }
    }
    protected void btnjoinwith_Click(object sender, EventArgs e)
    {
        
        Button btn = (Button)sender;
        string str1 = "select * from FriendsMaster where (User_ID1='" + Session["USER_ID"] + "' and User_ID2='" + btn.CommandArgument + "' and Delete_flag='False') or (User_ID1='" + btn.CommandArgument + "' and User_ID2='" + Session["USER_ID"] + "' and Delete_flag='False')";
        da = new SqlDataAdapter(str1, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            string delf = ds.Tables[0].Rows[0]["Delete_flag"].ToString();
            if (delf == "False")
            {
                lblmsg.Text = "You will Already Send Reaquest to this user";
            }
            else if (delf == "True")
            {
                lblmsg.Text = "You are already in friends list";
            }
            else
            {
                string str = "Insert into FriendsMaster (User_ID1,User_ID2,Delete_flag) values ( '" + Session["USER_ID"] + "','" + btn.CommandArgument + "' ,'False')";
                cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                lblmsg.Text = "Your Request will be send";
            }
        }
        else
        {
             string str = "Insert into FriendsMaster (User_ID1,User_ID2,Delete_flag) values ( '" + Session["USER_ID"] + "','" + btn.CommandArgument + "' ,'False')";
                cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                lblmsg.Text = "Your Request will be send";
        }
        
    }


    protected void btnviewinfo_Click(object sender, EventArgs e)
    {
           Button bt = (Button)sender;
        DateTime dt=Convert.ToDateTime(System.DateTime.Now.ToString());
        da = new SqlDataAdapter("Select * from Visitor_Master where vistor_UserId='" + Session["USER_ID"] + "' and User_id='"+bt.CommandArgument.ToString()+"'", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            cmd = new SqlCommand("Update Visitor_Master Set Visit_date='" + dt + "' where vistor_UserId='" + Session["USER_ID"] + "' and User_id='" + bt.CommandArgument.ToString() + "' ", con);
            cmd.ExecuteNonQuery();
            Session["visitor"] = bt.CommandArgument.ToString();
            Response.Redirect("Profile_HomePage.aspx");
        
        }
        else
        {
            cmd = new SqlCommand("Insert into Visitor_Master(User_id,vistor_UserId,Visit_date) values('" + bt.CommandArgument.ToString() + "','" + Session["USER_ID"] + "','" + dt + "')", con);
            cmd.ExecuteNonQuery();
            Session["visitor"] = bt.CommandArgument.ToString();
            Response.Redirect("Profile_HomePage.aspx");
        }
    }
}
