﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_User_Requestaspx : System.Web.UI.Page
{
    SqlCommand cmd;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
          
        if (!IsPostBack)
        {
            dvmoreinfo.Visible = false;
            string str = "False";
            da = new SqlDataAdapter("Select * from LoginMaster where Delete_Flag='" + str + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                grdadminuserrequest.DataSource = ds;
                grdadminuserrequest.DataBind();
            }
        }
    }
    


    protected void btnmoreinfo_Click1(object sender, EventArgs e)
    {
        grdadminuserrequest.Visible = false;
        dvmoreinfo.Visible = true;
        Button btn=(Button)sender;
        da = new SqlDataAdapter("SELECT LoginMaster.*, ProfileMaster.* FROM LoginMaster INNER JOIN ProfileMaster ON LoginMaster.User_ID = ProfileMaster.User_ID where LoginMaster.User_ID='" + btn.CommandArgument.ToString() + "'", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dvmoreinfo.DataSource = ds;
            dvmoreinfo.DataBind();
        }
       // Response.Redirect("~/ApprovedOrNotapproved.aspx");
    }
    protected void btnapproved_Click(object sender, EventArgs e)
    {
        string str = "True";
        Button btn = (Button)sender;
        cmd = new SqlCommand("Update LoginMaster Set Delete_Flag='" + str + "' where User_ID='" + btn.CommandArgument.ToString() + "'", con);
        cmd.ExecuteNonQuery();
     }
    protected void btnnotapproved_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        cmd = new SqlCommand("Delete from LoginMaster where User_ID='" + btn.CommandArgument.ToString() + "'", con);
        cmd.ExecuteNonQuery();
        cmd = new SqlCommand("Delete from ProfileMaster where User_ID='"+btn.CommandArgument.ToString()+"'", con);
        cmd.ExecuteNonQuery();
    }
    protected void dvmoreinfo_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
    {

    }
}

       