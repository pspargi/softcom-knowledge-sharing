﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Registration_Form : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        lbuniq.Text = Convert.ToString(Session["USER_ID"]);
        if (!IsPostBack)
        {
            bindcountry();
            bindState();
            bindCity();
            bindprofile();
        }
        

    }
    void bindcountry()
    {
        da = new SqlDataAdapter("Select * from CountryMaster", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drlcountry.DataSource = ds.Tables[0];
            drlcountry.DataTextField = "Country_name"; //ds.Tables[0].Rows[0]["Country_name"].ToString();
            drlcountry.DataValueField = "Country_ID"; //;ds.Tables[0].Rows[0]["Country_ID"].ToString();
            drlcountry.DataBind();
        }
    }
    void bindState()
    {
        da = new SqlDataAdapter("Select * from StateMaster", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drlstate.DataSource = ds.Tables[0];
            drlstate.DataTextField = "State_name"; //ds.Tables[0].Rows[0]["Country_name"].ToString();
            drlstate.DataValueField = "State_ID"; //;ds.Tables[0].Rows[0]["Country_ID"].ToString();
            drlstate.DataBind();
        }
    }
    void bindprofile()
    {
        //da = new SqlDataAdapter("Select * from ProfileMaster where User_ID='" + lbuniq.Text + "'", con);
        da = new SqlDataAdapter("SELECT     ProfileMaster.*, StateMaster.State_name, CityMaster.City_name, CountryMaster.Country_name FROM  CountryMaster FULL OUTER JOIN ProfileMaster ON CountryMaster.Country_ID = ProfileMaster.Country_ID FULL OUTER JOIN CityMaster ON ProfileMaster.City_ID = CityMaster.City_ID FULL OUTER JOIN StateMaster ON ProfileMaster.State_ID = StateMaster.State_ID where User_ID='" + lbuniq.Text + "'", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            txtfname.Text = ds.Tables[0].Rows[0]["First_name"].ToString();
            txtmname.Text = ds.Tables[0].Rows[0]["Midle_name"].ToString();
            txtlname.Text = ds.Tables[0].Rows[0]["Last_name"].ToString();
            rblgender.SelectedItem.Value = ds.Tables[0].Rows[0]["Gender"].ToString();
            txtaddressline1.Text = ds.Tables[0].Rows[0]["Address_line1"].ToString();
            txtaddressline2.Text = ds.Tables[0].Rows[0]["Address_line2"].ToString();
            txtphoneno.Text = ds.Tables[0].Rows[0]["phone_no"].ToString();
            txtemailid.Text = ds.Tables[0].Rows[0]["Email_Id"].ToString();
            drlcountry.SelectedItem.Value = ds.Tables[0].Rows[0]["Country_ID"].ToString();
            drlstate.SelectedItem.Value = ds.Tables[0].Rows[0]["State_ID"].ToString();
            drlcity.SelectedItem.Value = ds.Tables[0].Rows[0]["City_ID"].ToString();
            txtinterest.Text = ds.Tables[0].Rows[0]["Interest"].ToString();
            txthomepage.Text = ds.Tables[0].Rows[0]["home_page"].ToString();
        }

    }
    void bindCity()
    {
        da = new SqlDataAdapter("Select * from CityMaster", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drlcity.DataSource = ds.Tables[0];
            drlcity.DataTextField = "City_name"; //ds.Tables[0].Rows[0]["Country_name"].ToString();
            drlcity.DataValueField = "City_ID"; //;ds.Tables[0].Rows[0]["Country_ID"].ToString();
            drlcity.DataBind();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        string str = "Update ProfileMaster Set First_name='" + txtfname.Text + "',Midle_name='" + txtmname.Text + "',Last_name='" + txtlname.Text + "',Gender='" + rblgender.SelectedItem.Text + "',Address_line1='" + txtaddressline1.Text + "',Address_line2='" + txtaddressline2.Text + "',phone_no='" + txtphoneno.Text + "',Email_Id='" + txtemailid.Text + "',Country_ID='" + drlcountry.SelectedItem.Value + "',State_ID='" + drlstate.SelectedItem.Value + "',City_ID='" + drlcity.SelectedItem.Value + "',Interest='" + txtinterest.Text + "',home_page='" + txthomepage.Text + "' where User_Id='" + lbuniq.Text + "'";
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        lbmsg.Text = "Your Profile is being Updated";
        
    }


    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Profile_HomePage.aspx");
        // txtfname.Text = "";
        //rblgender.SelectedIndex = -1;
        //txtaddressline1.Text = "";
        //txtphoneno.Text = "";
        //drlcountry.Text = "";
        // txtemailid.Text = "";
        //= "";
        //txtcity.Text = "";
        //txtinterest.Text = "";
        //txthomepage.Text = "";


    }
    protected void drlcountry_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtaddressline1_TextChanged(object sender, EventArgs e)
    {

    }
}
