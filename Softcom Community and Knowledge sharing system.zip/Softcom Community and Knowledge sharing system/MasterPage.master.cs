﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class MasterPage : System.Web.UI.MasterPage
{
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds,ds1;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if(!IsPostBack)
        {
            bindgrid();
            bindlist();
        }
       
    }
    void bindgrid()
    {
        string str = "SELECT ActivityMaster.Activity_name FROM ActivityMaster LEFT OUTER JOIN ActivityGroupMaster ON ActivityMaster.Activity_Group_ID = ActivityGroupMaster.Activity_Group_ID where ActivityMaster.Activity_Group_ID=1";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
             Dsimagemaster.DataSource = ds;
             Dsimagemaster.DataBind();
        }
        else
        {
            Dsimagemaster.DataSource = null;
            Dsimagemaster.DataBind();
        }

    }
    void bindlist()
    {
        string str1 = "Select '~/Uploaded Images/'+ ads_pic_file as ads_pic_file FROM ActivityMaster where Activity_Group_ID=4";
        da = new SqlDataAdapter(str1, con);
        ds1 = new DataSet();
        da.Fill(ds1);
        if (ds1.Tables[0].Rows.Count > 0)
        {
            dsadsimage.DataSource = ds1;
            dsadsimage.DataBind();
        }
        else
        {
            dsadsimage.DataSource = null;
            dsadsimage.DataBind();
        }

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        
    }
    
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
