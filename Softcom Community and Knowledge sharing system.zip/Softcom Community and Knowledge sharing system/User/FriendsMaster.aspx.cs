﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_FriendsMaster : System.Web.UI.Page
{
    SqlConnection con;
    
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindGrid();
          
        }

    }
    void BindGrid()
    {
        string str1 = "Select * from FriendsMaster where (User_ID1='" + Session["USER_ID"] + "' and Delete_flag='True') or (User_ID2= '" + Session["USER_ID"] + "' and Delete_flag='True') ";
        da = new SqlDataAdapter(str1, con);
        ds = new DataSet();
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {

            string str = "SELECT CityMaster.City_name, StateMaster.State_name, CountryMaster.Country_name, ProfileMaster.First_name, ProfileMaster.Midle_name,ProfileMaster.Last_name,ProfileMaster.User_ID,'~/Uploaded Images/'+ Photo_file  as Photo_file,ProfileMaster.Phone_no,ProfileMaster.Email_Id,ProfileMaster.Gender, ProfileMaster.Address_line1, ProfileMaster.Address_line2 FROM CountryMaster FULL OUTER JOIN ProfileMaster ON CountryMaster.Country_ID = ProfileMaster.Country_ID FULL OUTER JOIN StateMaster ON ProfileMaster.State_ID = StateMaster.State_ID FULL OUTER JOIN CityMaster ON ProfileMaster.City_ID = CityMaster.City_ID where ProfileMaster.User_ID='" + ds.Tables[0].Rows[0]["User_ID2"] + "' or  ProfileMaster.User_ID='" + ds.Tables[0].Rows[0]["User_ID1"] + "'";
            da = new SqlDataAdapter(str, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                grdimagefriends.DataSource = ds;
                grdimagefriends.DataBind();

            }
            else
            {
                grdimagefriends.DataSource = null;
                grdimagefriends.DataBind();
            }

        }
        else
        {
            grdimagefriends.DataSource = null;
            grdimagefriends.DataBind();
        }
        
    }
    protected void grdimagefriends_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
