﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;


public partial class User_videoCategoryMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            bindgrid();
        }


    }
    void bindgrid()
    {
        string str = "select * from VideoCatMaster where User_ID='"+Session["USER_ID"]+"'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdvideocategory.DataSource = ds;
            grdvideocategory.DataBind();
        }
        else
        {
            grdvideocategory.DataSource = null;
            grdvideocategory.DataBind();
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["Video_Cat_ID"] != null)
        {
            String str = "update VideoCatMaster set Video_Cat_name='" + txtcategoryname.Text + "',Video_Cat_description='" + txtcategorydescr.Text + "'where Video_Cat_ID='" + ViewState["Video_Cat_ID"].ToString() + "'";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Updated";
            btnSave.Text = "Save";
        }
        else
        {
            string str = "Insert into VideoCatMaster(User_ID,Video_Cat_name,Video_Cat_description)values('"+Session["USER_ID"]+"','" + txtcategoryname.Text + "','" + txtcategorydescr.Text + "')";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Inserted";
        }
        bindgrid();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtcategoryname.Text = "";
        txtcategorydescr.Text = "";
        ViewState.Clear();
        lblmsg.Text = "";
    }
    protected void lbkedit_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "select * from VideoCatMaster where Video_Cat_ID=" + lbk.CommandArgument.ToString();
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ViewState["Video_Cat_ID"] = lbk.CommandArgument.ToString();
            txtcategoryname.Text = ds.Tables[0].Rows[0]["Video_Cat_name"].ToString();
            txtcategorydescr.Text = ds.Tables[0].Rows[0]["Video_Cat_description"].ToString();
        }
        btnSave.Text = "Update";
            
    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "Delete from VideoCatMaster where Video_Cat_ID=" + lbk.CommandArgument.ToString();
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        btncancel_Click(sender, e);
        lblmsg.Text="Record deleted";
        bindgrid();
    }
}
