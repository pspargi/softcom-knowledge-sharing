﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="VideoMaster.aspx.cs" Inherits="User_VideoMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 20px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <h2>
                    Video Master</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Video Category Name:</td>
            <td style="text-align: left">
                <asp:DropDownList ID="DdlVideoCatName" runat="server" 
                    onselectedindexchanged="DdlVideoCatName_SelectedIndexChanged" 
                    AutoPostBack="True">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Video Name:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtvideoname" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Video File Name:</td>
            <td style="text-align: left">
                <asp:FileUpload ID="fpvideofile" runat="server" />
            </td>
        </tr>
        <tr>
            <td class="style2" colspan="2" style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Button ID="btnSave" runat="server" onclick="btnSave_Click" Text="Save" 
                    BackColor="#695F4C" />
                <asp:Button ID="btncancel" runat="server" Text="Cancel" 
                    onclick="btncancel_Click" BackColor="#695F4C" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdvideomaster" runat="server" AutoGenerateColumns="False" 
                    CellPadding="4" ForeColor="#333333" GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkedit" runat="server" 
                                    CommandArgument='<%# Eval("Video_ID") %>' onclick="lbkedit_Click">Edit</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkdelete" runat="server" 
                                    CommandArgument='<%# Eval("Video_ID") %>' onclick="lbkdelete_Click">Delete</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Video_Cat_name" HeaderText="Video Category" />
                        <asp:BoundField DataField="Video_name" HeaderText="Video Name" />
                        <asp:BoundField DataField="Video_file" HeaderText="Video File Name" />
                        <asp:TemplateField HeaderText="download">
                            <ItemTemplate>
                                <asp:HyperLink ID="hpldownload" runat="server" 
                                    NavigateUrl='<%# Eval("Video1") %>'>Download</asp:HyperLink>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

