﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_GroupMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindGrid();
        }


    }
    void BindGrid()
    {
        string str = "Select * from GroupMaster where User_ID='"+Session["USER_ID"]+"' ";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdGroupMaster.DataSource = ds;
            grdGroupMaster.DataBind();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["Group_ID"] != null)
        {
            cmd = new SqlCommand("Update GroupMaster set Group_Name ='" + txtgroupmaster.Text + "',Group_Description='" +txtgroupdescr.Text + "'where Group_ID= " + ViewState["Group_ID"], con);
            cmd.ExecuteNonQuery();
            BindGrid();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Updated successfully";

        }
        else
        {
            string str = "Insert into GroupMaster(User_ID,Group_Name,Group_Description) Values ('" + Session["USER_ID"] + "','" + txtgroupmaster.Text + "','" + txtgroupdescr.Text + "')";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Inserted Successfully";
        }
        BindGrid();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {

        txtgroupmaster.Text = "";
        txtgroupdescr.Text = "";
        lblmsg.Text = "";
        txtgroupmaster.Focus();          
        ViewState.Clear();
    }
    protected void lbkEdit_Click(object sender, EventArgs e)
    {
        LinkButton lnk = (LinkButton)sender;

        da = new SqlDataAdapter("Select * from GroupMaster where Group_ID=" + lnk.CommandArgument, con);
        ds = new DataSet();
        da.Fill(ds);


        if (ds.Tables[0].Rows.Count > 0)
        {
            ViewState["Group_ID"] = lnk.CommandArgument;
            txtgroupmaster.Text = ds.Tables[0].Rows[0]["Group_Name"].ToString();
            txtgroupdescr.Text = ds.Tables[0].Rows[0]["Group_Description"].ToString();
        }
    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lnk = (LinkButton)sender;
        cmd = new SqlCommand("delete from GroupMaster where Group_ID=" + lnk.CommandArgument, con);
        cmd.ExecuteNonQuery();
        BindGrid();
        btncancel_Click(sender, e);
        lblmsg.Text = "Record Deleted Sucessfully";
    }
}
