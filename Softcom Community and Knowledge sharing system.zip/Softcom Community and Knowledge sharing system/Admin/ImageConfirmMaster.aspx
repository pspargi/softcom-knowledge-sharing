﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="ImageConfirmMaster.aspx.cs" Inherits="Admin_ImageConfirmMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style4
        {
            width: 65px;
        }
        .style5
        {
            height: 8px;
            width: 65px;
        }
        .style3
        {
            height: 8px;
            text-align: left;
        }
        </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td style="text-align: center">
                <h2>
                    Image Requests</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                    <asp:GridView ID="grdrequestmaster" runat="server" 
    AutoGenerateColumns="False" AllowPaging="True" 
                        onselectedindexchanging="grdrequestmaster_SelectedIndexChanging" 
                        PageSize="5" CellPadding="4" ForeColor="#333333" GridLines="None"> 
                     
    
                        <RowStyle BackColor="#E3EAEB" />
                     
    
                        <Columns>
                            <asp:TemplateField>
                                <ItemTemplate>
                                    <table class="style1">
                                        <tr>
                                            <td rowspan="3">
                                                <asp:Image ID="ImagePhoto" runat="server" Height="100px" 
                                                Width="70px" ImageUrl='<%# Eval("Photo_file") %>' />
                                            </td>
                                            <td style="text-align: right" class="style4">
                                                Name:&nbsp;
                                            </td>
                                            <td style="text-align: left">
                                                <asp:Label ID="lblfirstname" runat="server" 
                                                    Text='<%# Eval("First_name") %>'></asp:Label>
                                                <asp:Label ID="lblmidlename" runat="server" Text='<%# Eval("Midle_name") %>'></asp:Label>
                                                <asp:Label ID="lbllastname" runat="server" Text='<%# Eval("Last_name") %>'></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style4">
                                                Email ID</td>
                                            <td style="text-align: left">
                                                <asp:Label ID="lblemailid" runat="server" Text='<%# Eval("Email_Id") %>'></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style5">
                                                Total Image</td>
                                            <td class="style3">
                                                <asp:Label ID="lbltotalimage" runat="server"></asp:Label>
                                            </td>
                                        </tr>
                                    </table>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField>
                                <ItemTemplate>
                                    <asp:LinkButton ID="lblshowimage" runat="server" 
                                    onclick="lblshowimage_Click" CommandArgument='<%# Eval("User_ID") %>'>Show 
                                    Images</asp:LinkButton>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField>
                                <ItemTemplate>
                                    <asp:LinkButton ID="lblMoreInformation" runat="server" 
                                    CommandArgument='<%# Eval("User_ID") %>'>More Information</asp:LinkButton>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                        <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                        <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                        <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                        <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                        <EditRowStyle BackColor="#7C6F57" />
                        <AlternatingRowStyle BackColor="White" />
                    </asp:GridView>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                &nbsp;</td>
        </tr>
    </table>
</asp:Content>

