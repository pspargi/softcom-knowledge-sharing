﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Change_Password.aspx.cs" Inherits="User_Change_Password" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 46px;
            font-size: xx-large;
            text-align: center;
        }
        .style3
        {
            text-align: center;
        }
        .style4
        {
            width: 275px;
            text-align: left;
        }
        .style5
        {
            text-align: right;
            width: 301px;
        }
        .style6
        {
            text-align: center;
            }
        .style7
        {
            text-align: right;
            width: 301px;
            height: 27px;
        }
        .style8
        {
            width: 275px;
            height: 27px;
            text-align: left;
        }
        .style9
        {
            height: 27px;
        }
        .style10
        {
            text-align: center;
            height: 42px;
        }
    </style>
    </asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
        <table class="style1">
            <tr>
                <td class="style6">
                    &nbsp;</td>
                <td class="style4">
                    &nbsp;</td>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style2" colspan="3">
                    <asp:Label ID="Label5" runat="server" Text="Change Your Password Here...."></asp:Label>
                </td>
            </tr>
            <tr>
                <td class="style5">
                    <asp:Label ID="Label6" runat="server" Text="User_Type"></asp:Label>
                </td>
                <td class="style4">
                    <asp:RadioButtonList ID="rbluser_type" runat="server" AutoPostBack="True" 
                        RepeatDirection="Horizontal">
                        <asp:ListItem>User</asp:ListItem>
                        <asp:ListItem>Admin</asp:ListItem>
                    </asp:RadioButtonList>
                </td>
                <td>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator10" runat="server" 
                        ControlToValidate="rbluser_type" ErrorMessage="*" ValidationGroup="1"></asp:RequiredFieldValidator>
                </td>
            </tr>
            <tr>
                <td class="style5">
                    <asp:Label ID="Label1" runat="server" Text="Email Id :-"></asp:Label>
                </td>
                <td class="style4">
                    <asp:TextBox ID="txtemailid" runat="server" Width="214px"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                        ControlToValidate="txtemailid" ErrorMessage="*" SetFocusOnError="True" 
                        ValidationGroup="1"></asp:RequiredFieldValidator>
                </td>
                <td>
                    <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                        ControlToValidate="txtemailid" ErrorMessage="Enter Valid Email Address" 
                        SetFocusOnError="True" 
                        ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" 
                        ValidationGroup="1"></asp:RegularExpressionValidator>
                </td>
            </tr>
            <tr>
                <td class="style5">
                    <asp:Label ID="Label2" runat="server" Text="Password :-"></asp:Label>
                </td>
                <td class="style4">
                    <asp:TextBox ID="txtpassword" runat="server" Width="211px"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                        ControlToValidate="txtpassword" ErrorMessage="*" SetFocusOnError="True" 
                        ValidationGroup="1"></asp:RequiredFieldValidator>
                </td>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style5">
                    <asp:Label ID="Label3" runat="server" Text="New Password :-"></asp:Label>
                </td>
                <td class="style4">
                    <asp:TextBox ID="txtnewpassword" runat="server" Width="208px" 
                        TextMode="Password"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                        ControlToValidate="txtnewpassword" ErrorMessage="*" SetFocusOnError="True" 
                        ValidationGroup="1"></asp:RequiredFieldValidator>
                </td>
                <td>
                    <asp:CompareValidator ID="CompareValidator1" runat="server" 
                        ControlToCompare="txtnewpassword" ControlToValidate="txtrenewpassword" 
                        ErrorMessage="Enter Same Password In Both field" SetFocusOnError="True" 
                        ValidationGroup="1"></asp:CompareValidator>
                </td>
            </tr>
            <tr>
                <td class="style7">
                    &nbsp;<asp:Label ID="Label4" runat="server" Text="Renter Password :-"></asp:Label>
                </td>
                <td class="style8">
                    <asp:TextBox ID="txtrenewpassword" runat="server" Width="208px" 
                        TextMode="Password"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" 
                        ControlToValidate="txtrenewpassword" ErrorMessage="*" SetFocusOnError="True" 
                        ValidationGroup="1"></asp:RequiredFieldValidator>
                </td>
                <td class="style9">
                </td>
            </tr>
            <tr>
                <td class="style5">
                    &nbsp;</td>
                <td class="style4">
                    &nbsp;</td>
                <td>
                    &nbsp;</td>
            </tr>
            <tr>
                <td class="style3" colspan="3">
                    <asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" 
                        Width="52px" ValidationGroup="1" />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                        Text="Cancel" />
                </td>
            </tr>
            <tr>
                <td class="style10" colspan="3">
                    <asp:Label ID="lblwrn" runat="server" Font-Size="XX-Large" ForeColor="Red"></asp:Label>
                    <asp:Label ID="lblmsg" runat="server" Font-Size="XX-Large" ForeColor="Red"></asp:Label>
                </td>
            </tr>
            <tr>
                <td class="style6">
                    &nbsp;</td>
                <td class="style4">
                    &nbsp;</td>
                <td>
                    &nbsp;</td>
            </tr>
        </table>
      
    
</asp:Content>

