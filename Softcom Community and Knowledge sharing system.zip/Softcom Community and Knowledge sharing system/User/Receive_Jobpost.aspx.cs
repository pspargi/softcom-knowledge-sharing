﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Receive_Jobpost : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        lbluserid.Text = Convert.ToString(Session["USER_ID"]);
    //    lbluserid.Text = "3";
    
        if (!IsPostBack)
        {
            da = new SqlDataAdapter("Select Email_Id from LoginMaster where User_ID='" + lbluserid.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblemaild.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
            }
            bindgrid();
            string str = "Read";
            cmd = new SqlCommand("Update Jobpost_Inbox set Status='" + str + "' where Receiver='" + lblemaild.Text + "'", con);
            cmd.ExecuteNonQuery();
            }
    }
    void bindgrid()
    {
        da = new SqlDataAdapter("Select * from Jobpost_Inbox where Receiver='" + lblemaild.Text + "' Order by Date_Time desc", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dgvjobpost.DataSource = ds;
            dgvjobpost.DataBind();
        }
        else
        {
            dgvjobpost.DataSource = null;
            dgvjobpost.DataBind();
        
        }
    }
    protected void btnforward_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        Session["Job_post_id"] = bt.CommandArgument.ToString();
        Session["job_post"] = "Forward";
        Response.Redirect("Send_Jobpost.aspx");
    }
    protected void btndelete_click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        cmd = new SqlCommand("Delete from Jobpost_Inbox where Job_post_id='"+bt.CommandArgument.ToString()+"'", con);
        cmd.ExecuteNonQuery();
        bindgrid();
    }
   
}
