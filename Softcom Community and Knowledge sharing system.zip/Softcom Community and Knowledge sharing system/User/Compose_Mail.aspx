﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Compose_Mail.aspx.cs" Inherits="User_Compose_Mail" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
  <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 48px;
            text-align: center;
        }
        .style3
        {
            font-size: xx-large;
        }
        .style4
        {
          width: 140px;
          text-align: right;
      }
        .style5
        {
            width: 140px;
            text-align: right;
            height: 105px;
        }
        .style6
        {
            height: 105px;
        }
        .style7
        {
          width: 206px;
          text-align: left;
      }
        .style8
        {
            height: 105px;
            width: 206px;
          text-align: left;
      }
        .style9
        {
            text-align: center;
            height: 40px;
        }
        .style10
        {
            text-align: center;
            height: 32px;
        }
    </style>
</asp:Content>
  <asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
 
     <table class="style1">
        <tr>
            <td class="style2" colspan="3">
                <span class="style3">Compose Mail</span>
            </td>
        </tr>
        <tr>
            <td class="style4">
                Email_Address :-</td>
            <td class="style7">
                <asp:TextBox ID="txtemail_Address" runat="server" Width="204px"></asp:TextBox>
            </td>
            <td>
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                    ControlToValidate="txtemail_Address" ErrorMessage="Email Address is not valid" 
                    ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" 
                    ValidationGroup="1"></asp:RegularExpressionValidator>
            </td>
        </tr>
        <tr>
            <td class="style4">
                Subject :-</td>
            <td class="style7">
                <asp:TextBox ID="txtsubject" runat="server" Width="202px" ValidationGroup="1"></asp:TextBox>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style5">
                Message :-</td>
            <td class="style8">
                <asp:TextBox ID="txtmessagebox" runat="server" Height="87px" TextMode="MultiLine" 
                    Width="207px"></asp:TextBox>
            </td>
            <td class="style6">
            </td>
        </tr>
        <tr>
            <td class="style10" colspan="3">
                <asp:Button ID="btnsend" runat="server" Text="Send" onclick="btnsend_Click" 
                    Width="60px" ValidationGroup="1" BackColor="#695F4C" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                <asp:Button ID="btncancel" runat="server" Text="Cancel" Width="65px" 
                    onclick="btncancel_Click" BackColor="#695F4C" />
            </td>
        </tr>
        <tr>
            <td class="style2" colspan="3">
                <asp:Label ID="lbuserid" runat="server" Visible="False"></asp:Label>
                <asp:Label ID="lbemail_Id" runat="server" Visible="False"></asp:Label>
                <asp:Label ID="lbdate" runat="server" Visible="False"></asp:Label>
                <asp:Label ID="lbsent" runat="server" Visible="False"></asp:Label>
            </td>
        </tr>
        <tr>
            <td class="style9" colspan="3">
                <asp:Label ID="lbmsg" runat="server" Font-Bold="True" Font-Size="X-Large" 
                    ForeColor="Red"></asp:Label>
            </td>
        </tr>
    </table>

</asp:Content>
