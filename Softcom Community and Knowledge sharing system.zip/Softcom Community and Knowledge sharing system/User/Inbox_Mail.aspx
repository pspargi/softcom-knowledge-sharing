﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Inbox_Mail.aspx.cs" Inherits="User_Inbox_Mail" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <title>Untitled Page</title>
    <style type="text/css">
        .style1
        {
            width: 88%;
            height: 135px;
        }
        .style3
        {
            text-align: center;
            }
        .style4
        {
            text-align: right;
            width: 167px;
        }
        .style5
        {
            text-align: center;
            width: 167px;
            font-weight: bold;
        }
        .style6
        {
            width: 100%;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style6">
        <tr>
            <td style="text-align: center">
    
    <asp:GridView ID="dgvinbox" runat="server" Width="200px" 
            AutoGenerateColumns="False" CellPadding="4" ForeColor="#333333" GridLines="None">
        <RowStyle BackColor="#E3EAEB" />
        <Columns>
            <asp:TemplateField HeaderText="Sender">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td class="style5">
                                <asp:Label ID="lblsender" runat="server" Text='<%# Eval("Sender") %>'></asp:Label>
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
            <asp:TemplateField HeaderText="Scrabs">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td class="style5">
                                Subject :-</td>
                            <td class="style2">
                                <asp:TextBox ID="TextBox1" runat="server" Height="23px" ReadOnly="True" 
                                    Text='<%# Eval("Subject") %>' Width="207px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style5">
                                Message :-</td>
                            <td class="style2">
                                <asp:TextBox ID="txtmessage" runat="server" Height="50px" ReadOnly="True" 
                                    Text='<%# Eval("Message") %>' TextMode="MultiLine" Width="203px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style4">
                                &nbsp;</td>
                            <td class="style2" style="text-align: right">
                                <asp:Label ID="lblstatus" runat="server" ForeColor="#CC0000" 
                                    style="font-size: large" Text='<%# Eval("Status") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style4">
                                &nbsp;</td>
                            <td class="style2" style="text-align: right">
                                <asp:Label ID="lbldate_Time" runat="server" Text='<%# Eval("Date_Time") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style3" colspan="2">
                                <asp:Button ID="btnforward" runat="server" 
                                    CommandArgument='<%# Eval("Email_no") %>' Height="25px" 
                                    onclick="btnforward_Click" Text="Forward" Width="69px" 
                                    BackColor="#999966" />
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btnReply" runat="server" 
                                    CommandArgument='<%# Eval("Email_no") %>' Height="25px" 
                                    onclick="btnReply_Click" Text="Reply" Width="76px" BackColor="#999966" />
                                &nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btnDelete" runat="server" 
                                    CommandArgument='<%# Eval("Email_no") %>' Height="26px" 
                                    onclick="btnDelete_Click" Text="Delete" Width="73px" BackColor="#999966" />
                            </td>
                        </tr>
                        <tr>
                            <td class="style3" colspan="2">
                                &nbsp;</td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#7C6F57" />
        <AlternatingRowStyle BackColor="White" />
    </asp:GridView>
    
            </td>
        </tr>
        <tr>
            <td>
    <asp:Label ID="lbluserid" runat="server" Visible="False"></asp:Label>
    <asp:Label ID="lblemail_id" runat="server" Visible="False"></asp:Label>
            </td>
        </tr>
    </table>
    </asp:Content>
