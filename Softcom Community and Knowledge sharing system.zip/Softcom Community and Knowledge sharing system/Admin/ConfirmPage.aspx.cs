﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_ConfirmPage : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    void BindGrid()
    {
        string str = "select Image_name,Image_ID,User_ID,'~/Uploaded Images/'+ Image_file  as Image_file from ImageMaster where Delete_flag='False' and User_ID='"+Session["user_id"]+"'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdimage.DataSource = ds;
            grdimage.DataBind();
        }
        else
        {
            grdimage.DataSource = null;
            grdimage.DataBind();
        }

    }
    protected void btnApprove_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < grdimage.Rows.Count; i++)
        {
            if (((CheckBox)grdimage.Rows[i].FindControl("ckbimage")).Checked == true)
            {
                String str = "Update ImageMaster set Delete_flag='True' where Image_ID='" + Convert.ToInt32(((Label)grdimage.Rows[i].FindControl("lblimageid")).Text) + "'";
                cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();

            }
            else
            {
                String str1 = "Delete from ImageMaster where Image_ID='" + Convert.ToInt32(((Label)grdimage.Rows[i].FindControl("lblimageid")).Text) + "'";         
                string str = "Select * from ImageMaster where Image_ID=" + Convert.ToInt32(((Label)grdimage.Rows[i].FindControl("lblimageid")).Text);
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(str, con);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (File.Exists(Server.MapPath("~/Uploaded Images/" + ds.Tables[0].Rows[0]["Image_file"].ToString())))
                    {
                        File.Delete(Server.MapPath("~/Uploaded Images/" + ds.Tables[0].Rows[0]["Image_file"].ToString()));
                    }
                }

                cmd = new SqlCommand(str1, con);
                cmd.ExecuteNonQuery();
            }
            lblmsg.Text = "Updated Success Fully";
            BindGrid();
        }
    }
}
