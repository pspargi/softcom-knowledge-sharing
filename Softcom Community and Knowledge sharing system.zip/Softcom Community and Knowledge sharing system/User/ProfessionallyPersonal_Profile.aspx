﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="ProfessionallyPersonal_Profile.aspx.cs" Inherits="User_Professionally_Profile" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
            height: 80px;
        }
        .style2
        {
            height: 234px;
            text-align: center;
        }
        .style11
        {
            text-align: center;
            height: 42px;
        }
        .style14
        {
            height: 42px;
        }
        .style15
        {
            height: 48px;
        }
    </style>
</asp:Content>
   <asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
     <table class="style1">
        <tr>
            <td>
                    <asp:Panel ID="ppersonal" runat="server" Height="206px">
                        <table class="style1">
                            <tr>
                                <td class="style14" colspan="3">
                                    <asp:Label ID="lblmsg" runat="server" Visible="False"></asp:Label>
                                    <asp:Label ID="Label13" runat="server" Font-Size="X-Large" 
                                        Text="Personal Details"></asp:Label>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label9" runat="server" Text="Eye Color :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:DropDownList ID="ddleyecolor" runat="server" Height="20px" Width="142px">
                                        <asp:ListItem></asp:ListItem>
                                        <asp:ListItem>No Answer</asp:ListItem>
                                        <asp:ListItem>Black</asp:ListItem>
                                        <asp:ListItem>Blue</asp:ListItem>
                                        <asp:ListItem>Brown</asp:ListItem>
                                        <asp:ListItem>Gray</asp:ListItem>
                                        <asp:ListItem>Green</asp:ListItem>
                                        <asp:ListItem>Hazer</asp:ListItem>
                                    </asp:DropDownList>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label10" runat="server" Text="Hair Color :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:DropDownList ID="ddlhaircolor" runat="server" Height="20px" Width="142px">
                                        <asp:ListItem></asp:ListItem>
                                        <asp:ListItem>No answer</asp:ListItem>
                                        <asp:ListItem>Auburn</asp:ListItem>
                                        <asp:ListItem>Black</asp:ListItem>
                                        <asp:ListItem>Blonde</asp:ListItem>
                                        <asp:ListItem>Light Brown</asp:ListItem>
                                        <asp:ListItem>Dark Brown</asp:ListItem>
                                        <asp:ListItem>Red</asp:ListItem>
                                        <asp:ListItem>Gray</asp:ListItem>
                                        <asp:ListItem>Salt and Pepper</asp:ListItem>
                                        <asp:ListItem>Chanyes peper</asp:ListItem>
                                        <asp:ListItem>Other</asp:ListItem>
                                    </asp:DropDownList>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label11" runat="server" Text="Build :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:DropDownList ID="ddlbuild" runat="server" Height="20px" Width="142px">
                                        <asp:ListItem></asp:ListItem>
                                        <asp:ListItem>No Answer</asp:ListItem>
                                        <asp:ListItem>Athetic</asp:ListItem>
                                        <asp:ListItem>Above Average</asp:ListItem>
                                        <asp:ListItem>Few Extra pounds</asp:ListItem>
                                        <asp:ListItem>Large</asp:ListItem>
                                    </asp:DropDownList>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label12" runat="server" Text="Looks :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:DropDownList ID="ddlLooks" runat="server" Height="20px" Width="142px">
                                        <asp:ListItem></asp:ListItem>
                                        <asp:ListItem>No answer</asp:ListItem>
                                        <asp:ListItem>Beauty contest winner</asp:ListItem>
                                        <asp:ListItem>Very Attractive</asp:ListItem>
                                        <asp:ListItem>Attractive</asp:ListItem>
                                        <asp:ListItem>Mirror-Cracking</asp:ListItem>
                                    </asp:DropDownList>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td class="style15" colspan="2">
                                    <asp:Button ID="btnsave0" runat="server" onclick="btnsave0_Click" Text="Save" 
                                        Width="76px" BackColor="#695F4C" />
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <asp:Button ID="btncancel0" runat="server" Text="Cancel" Width="82px" 
                                        onclick="btncancel0_Click" BackColor="#695F4C" />
                                </td>
                                <td class="style15">
                                    &nbsp;</td>
                            </tr>
                        </table>
                    </asp:Panel>
                </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td>
                    <asp:Panel ID="pprofessinal" runat="server" Height="221px">
                        <table class="style1">
                            <tr>
                                <td colspan="3">
                                    <asp:Label ID="Label1" runat="server" Font-Size="X-Large" 
                                        Text="Professional Profile"></asp:Label>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label2" runat="server" Text="Education :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:DropDownList ID="ddleducation" runat="server" Height="27px" Width="169px">
                                        <asp:ListItem>No Answer</asp:ListItem>
                                        <asp:ListItem>Elementry</asp:ListItem>
                                        <asp:ListItem>High School</asp:ListItem>
                                        <asp:ListItem>College</asp:ListItem>
                                        <asp:ListItem>Associated Degree</asp:ListItem>
                                        <asp:ListItem>Bachelor Degree</asp:ListItem>
                                        <asp:ListItem>Master Degree</asp:ListItem>
                                        <asp:ListItem>Ph.D</asp:ListItem>
                                        <asp:ListItem>Post Doctoral</asp:ListItem>
                                    </asp:DropDownList>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label3" runat="server" Text="Company Name :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:TextBox ID="txtcompany_name" runat="server" Height="20px" Width="172px"></asp:TextBox>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label4" runat="server" Text="Primary Scholl Name :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:TextBox ID="txtprimaryshoolname" runat="server" Height="19px" 
                                        Width="172px"></asp:TextBox>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label5" runat="server" Text="Higher school name:-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:TextBox ID="txthighersecondoryschool" runat="server" Height="22px" 
                                        Width="172px"></asp:TextBox>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label6" runat="server" Text="College/Univercity :-"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:TextBox ID="txtcollege" runat="server" Height="23px" Width="169px"></asp:TextBox>
                                </td>
                                <td>
                                    <asp:Button ID="btnaddcolege" runat="server" Height="20px" 
                                        onclick="Button1_Click" Text="Add More College" Width="145px" 
                                        BackColor="#666633" />
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: right">
                                    <asp:Label ID="Label7" runat="server" Text="Coollege/Univercity 1:-" 
                                        Visible="False"></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:TextBox ID="txtcollege1" runat="server" Height="23px" Visible="False" 
                                        Width="169px"></asp:TextBox>
                                </td>
                                <td>
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align: center">
                                    <asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" 
                                        Width="69px" BackColor="#695F4C" />
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                                        Text="Cancel" Width="74px" BackColor="#695F4C" />
                                </td>
                            </tr>
                        </table>
                    </asp:Panel>
                </td>
            <td>
                &nbsp;</td>
        </tr>
    </table>
 </asp:Content>