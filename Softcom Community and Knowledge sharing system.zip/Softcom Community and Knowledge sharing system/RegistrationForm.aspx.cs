﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_RegistrationForm : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    int max;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        Label1.Visible = false;
        if (!IsPostBack)
        {
            

        }
    }
    protected void txtremail_PreRender(object sender, EventArgs e)
    {

    }
    protected void drlmonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void drlmonth_TextChanged(object sender, EventArgs e)
    {
        
 


    }
    protected void drlyear_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void btnsingup_Click(object sender, EventArgs e)
    {
        //if (txtempid.Text == "" || txtfname.Text == "" || txtlname.Text == "" || txtmname.Text == "" || txtpassword.Text == "" || txtrepassword.Text == "" || txtemail.Text == "" || txtanswer.Text == "")
        //{
        //    lblmsg1.Text = "Pleas Fill all the Data Propelry Invalid Data Error occur";   
        //}
        //else
        //{
        //    if (txtpassword.Text == txtrepassword.Text)
        {
            da = new SqlDataAdapter("Select Email_ID from LoginMaster where Email_ID='"+txtemail.Text+"'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblerroremail.Text = "This email Id is alerady Registered";
            }
            else
            {

                string s = txtfname.Text + " " + txtmname.Text + " " + txtlname.Text;
                // try
                //{
                if (txtmyowner.Visible == false)
                {
                    Label1.Text = s;
                    Label1.Visible = false;
                    string str = "False";
                    cmd = new SqlCommand("Insert into LoginMaster (Emp_Id,User_Type,Email_ID,Password,Security_Question,Answer,Active_Flag,Delete_Flag) values ('" + txtempid.Text + "','" + rbluser_type.SelectedItem.Text + "','" + txtemail.Text + "','" + txtpassword.Text + "','" + drlquestion.Text + "','" + txtanswer.Text + "','" + str + "','" + str + "')", con);
                    cmd.ExecuteNonQuery();
                    registration();
                    lblmsg1.Text = "";
                    lblmsg.Text = "";
                    btnclearall_Click(sender, e);
                    btnBack_click(sender, e);
                    lblwarn.Text = "Hellow, Mr/Miss/Mrs  " + Label1.Text + "    Your account has been Successfully Added Pleas Wait Till Approved";
                }
                else
                {
                    Label1.Text = s;
                    Label1.Visible = false;
                    string str = "False";
                    cmd = new SqlCommand("Insert into LoginMaster (Emp_ID,User_Type,Email_ID,Password,Security_Question,Answer,Active_Flag,Delete_Flag) values ('" + txtempid.Text + "','" + rbluser_type.SelectedItem.Text + "','" + txtemail.Text + "','" + txtpassword.Text + "','" + txtmyowner.Text + "','" + txtanswer.Text + "','" + str + "','" + str + "')", con);
                    cmd.ExecuteNonQuery();
                    registration();
                    lblmsg1.Text = "";
                    lblmsg.Text = "";
                    txtmyowner.Visible = false;
                    btnclearall_Click(sender, e);
                    btnBack_click(sender, e);
                    lblwarn.Text = "Hellow, Mr/Miss/Mrs  " + Label1.Text + "    Your account has been Successfully Added Pleas Wait Till Approved";
                }
            }
     
        }
    }
    void registration()
    {
       da = new SqlDataAdapter("Select MAX(User_ID) as maxuser FROM LoginMaster", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbb.Text = ds.Tables[0].Rows[0]["maxuser"].ToString();
        }
        cmd = new SqlCommand("Insert into ProfileMaster(User_ID,First_name,Midle_name,Last_name) values('" + Convert.ToInt32(lbb.Text) + "','" + txtfname.Text + "','" + txtmname.Text + "','" + txtlname.Text + "')", con);
        cmd.ExecuteNonQuery();
        cmd = new SqlCommand("Insert into SocialProfileMaster(User_ID) values('" + Convert.ToInt32(lbb.Text) + "')",con);
        cmd.ExecuteNonQuery();
        cmd = new SqlCommand("Insert into personalDetails(User_ID) values('"+Convert.ToInt32(lbb.Text)+"')", con);
        cmd.ExecuteNonQuery();
        cmd = new SqlCommand("Insert into professionalProfile(User_ID) values('"+Convert.ToInt32(lbb.Text)+"')", con);
        cmd.ExecuteNonQuery();
    }
    protected void drlday_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnclearall_Click(object sender, EventArgs e)
    {
        txtempid.Text = "";
        txtfname.Text = "";
        txtlname.Text = "";
        txtemail.Text = "";
        txtmname.Text = "";
        txtanswer.Text = "";
        txtpassword.Text = "";
        txtrepassword.Text="";
        lblwarn.Text = "";
        lblmsg1.Text = "";
        lblmsg.Text = "";
               }
    protected void drlgender_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnBacv(object sender, EventArgs e)
    {

    }
    protected void btnBack_click(object sender, EventArgs e)
    {
        if (txtempid.Visible == false && txtfname.Visible == false)
        {
            txtempid.Visible = true;
            txtfname.Visible = true;
            txtlname.Visible = true;
            txtmname.Visible = true;
            txtemail.Visible = true;
            txtpassword.Visible = true;
            txtrepassword.Visible = true;
            txtanswer.Visible = true;
            drlquestion.Visible = true;
            Label1.Visible = true;
            Label2.Visible = true;
            Label3.Visible = true;
            Label4.Visible = true;
            Label5.Visible = true;
            Label6.Visible = true;
            Label7.Visible = true;
            Label8.Visible = true;
            Label9.Visible = true;
            Label10.Visible = true;
            Label11.Visible = true;
            btnsingup.Visible = true;
            btnclearall.Visible = true;
            rbluser_type.Visible = true; ;
            Label12.Visible = true;
            

        }
        txtempid.Visible = false;
        txtfname.Visible = false;
        txtlname.Visible = false;
        txtmname.Visible = false;
        txtemail.Visible = false;
        txtpassword.Visible = false;
        txtrepassword.Visible = false;
        txtanswer.Visible = false;
        drlquestion.Visible = false;
        Label1.Visible = false;
        Label2.Visible = false;
        Label3.Visible = false;
        Label4.Visible = false;
        Label5.Visible = false;
        Label6.Visible = false;
        Label7.Visible = false;
        Label8.Visible = false;
        Label9.Visible = false;
        Label10.Visible = false;
        Label11.Visible = false;
        btnsingup.Visible = false;
        btnclearall.Visible = false;
        rbluser_type.Visible = false;
        Label12.Visible = false;
        lblerroremail.Visible = false;
       }
    protected void drlquestion_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drlquestion.SelectedItem.Text == "Choose My Own Question")
        {
            txtmyowner.Visible = true;
            txtmyowner.Focus();
            RequiredFieldValidator8.ValidationGroup = "1";

            //        drlquestion.Visible = false;
        }
        else
        {
            txtmyowner.Visible = false;
              RequiredFieldValidator8.ValidationGroup = "0";

        }
    }
}
