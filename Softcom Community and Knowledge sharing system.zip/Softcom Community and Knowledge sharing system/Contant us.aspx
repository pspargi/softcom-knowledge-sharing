﻿<%@ Page Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="Contant us.aspx.cs" Inherits="Contant_us" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 96%;
        }
        .style2
        {
            text-align: justify;
        }
    .style3
    {
        font-family: Verdana;
    }
    .style4
    {
        font-family: Verdana;
        font-size: medium;
    }
    .style5
    {
        font-size: medium;
    }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td style="text-align: center">
                <h3>
                    Contact Us</h3>
            </td>
        </tr>
        <tr>
            <td class="style2">
                <p class="style2">
                    <span style="font-size:14.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;color:black">
                    S</span><span style="color:black" class="style4">oftCom Technologies<span style="mso-tab-count:2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </span></span>
                    <b style="mso-bidi-font-weight:
normal"><o:p></o:p></b>
                </p>
                <p class="style2">
                    <span style="color:black" class="style5">
                    <span style="mso-spacerun:yes" class="style3">&nbsp;</span></span><span 
                        style="color:black" class="style4">707/08/09, Time Square C-Building,<o:p></o:p></span></p>
                <p class="style2">
                    <span style="color:black" class="style4">
                    Near Fatehgunj petrol pump,</span><b 
                        style="mso-bidi-font-weight:normal"><o:p></o:p></b></p>
                <div class="style2">
                    <span style="mso-fareast-font-family:
&quot;Times New Roman&quot;;color:black;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:EN-US" class="style4">Fatehgunj, Vadodara.</span><span style="font-size:14.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;mso-fareast-font-family:
&quot;Times New Roman&quot;;color:black;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:EN-US"><b style="mso-bidi-font-weight:
normal">
                    <br />
                    <br />
                    <span style="font-size:14.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
mso-fareast-font-family:&quot;Times New Roman&quot;;color:black;mso-ansi-language:EN-US;
mso-fareast-language:EN-US;mso-bidi-language:EN-US">Name:&nbsp; Mr. Mehul Joshi<br />
                    Contant no: 9879021944 </span></b></span>
                </div>
            </td>
        </tr>
    </table>
</asp:Content>

