﻿<%@ Page Language="C#"  MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="ProfileMaster_Form.aspx.cs" Inherits="User_Registration_Form" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 64%;
        }
        .style2
        {
            height: 57px;
            text-align: center;
            font-weight: 700;
            font-family: "Kristen ITC";
            font-size: xx-large;
        }
        .style63
        {
            width: 152px;
        }
        .style64
        {
            width: 146px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td class="style2">
                Profile&nbsp;Form</td>
        </tr>
        </table>
    <table class="style1">
        <tr>
            <td class="style63">
                First Name :-</td>
            <td class="style64" style="text-align: left">
                <asp:TextBox ID="txtfname" runat="server" Width="129px" 
                    style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Middle Name:-</td>
            <td class="style64" style="text-align: left">
                <asp:TextBox ID="txtmname" runat="server" Width="130px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Last Name:-</td>
            <td class="style64">
                <asp:TextBox ID="txtlname" runat="server" Width="131px" 
                    style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Gender:-</td>
            <td class="style64">
                <asp:RadioButtonList ID="rblgender" runat="server" RepeatDirection="Horizontal" 
                    Width="128px">
                    <asp:ListItem Selected="True">Male</asp:ListItem>
                    <asp:ListItem>Female</asp:ListItem>
                </asp:RadioButtonList>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Address Line 1:-</td>
            <td class="style64">
                <asp:TextBox ID="txtaddressline1" runat="server" Height="20px" 
                    Width="129px" ontextchanged="txtaddressline1_TextChanged" 
                    style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Address Line 2:-</td>
            <td class="style64">
                <asp:TextBox ID="txtaddressline2" runat="server" Height="22px" 
                    Width="129px" style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Phone No :-</td>
            <td class="style64">
                <asp:TextBox ID="txtphoneno" runat="server" Width="129px" 
                    style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Alternative Email Id :-</td>
            <td class="style64">
                <asp:TextBox ID="txtemailid" runat="server" Width="129px" 
                    style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                State :-</td>
            <td class="style64">
                <asp:DropDownList ID="drlstate" runat="server" Height="22px" Width="129px">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Country :-</td>
            <td class="style64">
                <asp:DropDownList ID="drlcountry" runat="server" Height="21px" 
                    onselectedindexchanged="drlcountry_SelectedIndexChanged" Width="129px">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td class="style63">
                City :</td>
            <td class="style64">
                <asp:DropDownList ID="drlcity" runat="server" Height="22px" Width="129px">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Interest :-</td>
            <td class="style64">
                <asp:TextBox ID="txtinterest" runat="server" Width="129px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                Home Page(Optional):-</td>
            <td class="style64">
                <asp:TextBox ID="txthomepage" runat="server" Width="129px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style63">
                &nbsp;</td>
            <td class="style64">
                <asp:Label ID="lbmsg" runat="server" Visible="False"></asp:Label>
                <asp:Label ID="lbuniq" runat="server" Visible="False"></asp:Label>
                <asp:Label ID="lblwarn" runat="server" Visible="False"></asp:Label>
            </td>
        </tr>
    </table>
    <p align="center">
        &nbsp;<asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" 
                    Width="80px" ValidationGroup="1" style="top: 0px; left: 359px" 
            BackColor="#695F4C" />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                    style="height: 26px" Text="Cancel" Width="80px" 
            BackColor="#695F4C" />
            </p>
</asp:Content>

