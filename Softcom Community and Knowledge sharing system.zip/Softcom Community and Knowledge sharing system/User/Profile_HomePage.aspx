﻿<%@ Page Language="C#"MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Profile_HomePage.aspx.cs" Inherits="User_Profile_HomePage" %>


  <asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">

    <style type="text/css">
        .style1
        {
            width: 100%;
            height: 72px;
        }
        .style5
        {            text-align: center;
        }
        #E
        {
            text-align: left;
        }
        .style6
        {
            height: 5px;
        }
        .style7
        {
            width: 129px;
        }
        .style8
        {
            height: 5px;
            width: 129px;
        }
        .style9
        {
            width: 119px;
        }
        .style10
        {
            width: 133px;
        }
        .style11
        {
            height: 25px;
        }
        .style12
        {
            height: 27px;
        }
        .style13
        {
            height: 29px;
        }
        .style14
        {
            height: 27px;
            width: 131px;
        }
        .style15
        {
            height: 25px;
            width: 131px;
        }
        .style16
        {
            height: 29px;
            width: 131px;
        }
        .style17
        {
            width: 131px;
        }
    .style18
    {
        height: 17px;
    }
        .style20
        {
            height: 27px;
            width: 69px;
            text-align: right;
        }
    </style>
    </asp:Content>
    <asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    
    <div>
    
        <table class="style1">
            <tr>
                <td class="style20" >
                    <asp:Label ID="Label37" runat="server" Text="Resently_visitors:-"></asp:Label>
                </td>
                <td style="text-align: right" width=100px class="style12">
                    <asp:DataList ID="dlresent" runat="server" RepeatColumns="10" 
                        RepeatDirection="Horizontal" style="text-align: left" ForeColor="#FFCC00">
                        <ItemTemplate>
                            <asp:LinkButton ID="lbresent" runat="server" Text='<%# Eval("First_name") %>' 
                                CommandArgument='<%# Eval("User_ID") %>' onclick="lbresent_Click" 
                                ToolTip='<%# Eval("Visit_date") %>'></asp:LinkButton>
                        </ItemTemplate>
                    </asp:DataList>
                </td>
            </tr>
            <tr>
                <td style="text-align: right" colspan="2">
                    Edit Your Profile From Here:-
                    <asp:LinkButton ID="LinkButton1" runat="server" onclick="LinkButton1_Click">Edit</asp:LinkButton>
                </td>
            </tr>
            <tr>
                <td style="text-align: center" colspan="2">
                        <asp:Button ID="btnprofileMaster" runat="server" Text="General" Height="21px" 
                            onclick="btnprofileMaster_Click" Width="72px" BorderWidth="0px" 
                            CssClass="BtnSelect" BackColor="#666633" />
                        <asp:Button ID="btnsocial" runat="server" Height="20px" 
                            onclick="btnsocial_Click" Text="Social" Width="72px" BorderWidth="0px" 
                            CssClass="BtnNormal" BackColor="#666633" />
                        <asp:Button ID="btnpersonal" runat="server" Height="20px" 
                            onclick="btnpersonal_Click" Text="Personal" Width="72px" BorderWidth="0px" 
                            CssClass="BtnNormal" BackColor="#666633" />
                        <asp:Button ID="btnprofessional" runat="server" Height="21px" 
                            onclick="btnprofessional_Click" Text="Professional" Width="72px" 
                            CssClass="BtnNormal" BackColor="#666633" BorderWidth="0px" />
                </td>
            </tr>
            <tr>
                <td style="text-align: right" class="style18" colspan="2">
                    <asp:LinkButton ID="lbedit" runat="server" 
                        onclick="lbedit_Click" style="text-align: right" Visible="False">Edit</asp:LinkButton>
                </td>
            </tr>
            <tr>
                <td style="text-align: center" colspan="2">
                    
                        <asp:GridView ID="grvgeneral" runat="server" 
    AutoGenerateColumns="False" Height="309px" style="text-align: center; margin-right: 1px;" 
                            CellPadding="4" ForeColor="#333333" GridLines="None" 
                            onselectedindexchanged="grvgeneral_SelectedIndexChanged">
                            <RowStyle BackColor="#E3EAEB" />
                            <Columns>
                                <asp:TemplateField HeaderText="General Information">
                                    <ItemTemplate>
                                        <table class="style1">
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    First Name&nbsp; :</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label1" runat="server" 
                                Text='<%# Eval("First_name") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Middle Name:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label2" runat="server" 
                                Text='<%# Eval("Midle_name") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Last Name:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label3" runat="server" 
                                Text='<%# Eval("Last_name") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Gender:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label4" runat="server" 
                                Text='<%# Eval("Gender") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Address Line1:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label5" runat="server" 
                                Text='<%# Eval("Address_line1") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Address Line2:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label6" runat="server" 
                                Text='<%# Eval("Address_line2") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Phone No:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label7" runat="server" 
                                Text='<%# Eval("phone_no") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Email Id:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label8" runat="server" 
                                Text='<%# Eval("Email_Id") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Country Name:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label9" runat="server" 
                                Text='<%# Eval("Country_name") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    State Name:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label10" runat="server" 
                                Text='<%# Eval("State_name") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    City Name:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label11" runat="server" 
                                Text='<%# Eval("City_name") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="style9" style="text-align: right">
                                                    Interest</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label14" runat="server" Text='<%# Eval("Interest") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style9">
                                                    Hopage:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label13" runat="server" 
                                Text='<%# Eval("home_page") %>'></asp:Label>
                                                </td>
                                            </tr>
                                        </table>
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                            <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                            <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                            <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <EditRowStyle BackColor="#7C6F57" />
                            <AlternatingRowStyle BackColor="White" />
                        </asp:GridView>
                    
                </td>
            </tr>
            <tr>
                <td style="text-align: center" colspan="2">
                        <asp:GridView ID="dgvsocialprofile" runat="server" 
    AutoGenerateColumns="False" style="margin-right: 0px" CellPadding="4" ForeColor="#333333" 
                            GridLines="None">
                            <RowStyle BackColor="#E3EAEB" />
                            <Columns>
                                <asp:TemplateField HeaderText="Social Profile">
                                    <ItemTemplate>
                                        <table class="style1">
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Relation ship Status:</td>
                                                <td ID="E">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label14" runat="server" 
                                    Text='<%# Eval("Relation_ship_Status") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Ethnicity:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label15" runat="server" 
                                    Text='<%# Eval("Ethnicity") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Religion:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label16" runat="server" 
                                    Text='<%# Eval("Religion") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style8">
                                                    Home_Town:</td>
                                                <td style="text-align: left" class="style6">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label17" runat="server" 
                                    Text='<%# Eval("Home_Town") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Passion:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label18" runat="server" 
                                    Text='<%# Eval("Passion") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Sports:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label19" runat="server" 
                                    Text='<%# Eval("Sports") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Books:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label20" runat="server" 
                                    Text='<%# Eval("Books") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Music:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label21" runat="server" 
                                    Text='<%# Eval("Music") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Tv Shows :</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label22" runat="server" 
                                    Text='<%# Eval("tvshows") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Movies:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label23" runat="server" 
                                    Text='<%# Eval("Movies") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Cuisine:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label24" runat="server" 
                                    Text='<%# Eval("Cuisine") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Smoking:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label25" runat="server" 
                                    Text='<%# Eval("Smoking") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style7">
                                                    Drinking:</td>
                                                <td style="text-align: left; margin-left: 80px;">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label26" runat="server" 
                                    Text='<%# Eval("Drinking") %>'></asp:Label>
                                                </td>
                                            </tr>
                                        </table>
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                            <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                            <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                            <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <EditRowStyle BackColor="#7C6F57" />
                            <AlternatingRowStyle BackColor="White" />
                        </asp:GridView>
                </td>
            </tr>
            <tr>
                <td style="text-align: center" colspan="2">
                        <asp:GridView ID="dgvprofessionalinfo" runat="server" 
    AutoGenerateColumns="False" CellPadding="4" ForeColor="#333333" GridLines="None">
                            <RowStyle BackColor="#E3EAEB" />
                            <EmptyDataRowStyle BorderStyle="None" />
                            <Columns>
                                <asp:TemplateField HeaderText="Professional Information">
                                    <ItemTemplate>
                                        <table class="style1">
                                            <tr>
                                                <td style="text-align: right" class="style10">
                                                    Education:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label27" runat="server" 
                                Text='<%# Eval("Education") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style10">
                                                    Company Name:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label28" runat="server" 
                                Text='<%# Eval("Company_Name") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style10">
                                                    Primary School:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label29" runat="server" 
                                Text='<%# Eval("Primary_school") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style10">
                                                    Higher school:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label30" runat="server" 
                                Text='<%# Eval("Higher_school") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style10">
                                                    College univercity:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label31" runat="server" 
                                Text='<%# Eval("College_Univercity") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style10">
                                                    College unvercity 1:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label32" runat="server" 
                                Text='<%# Eval("College_univercity_1") %>'></asp:Label>
                                                </td>
                                            </tr>
                                        </table>
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                            <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                            <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                            <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <EditRowStyle BackColor="#7C6F57" />
                            <AlternatingRowStyle BackColor="White" />
                        </asp:GridView>
                </td>
            </tr>
            <tr>
                <td class="style5" colspan="2">
                        <asp:GridView ID="dgvpersonalinfo" runat="server" 
    AutoGenerateColumns="False" CellPadding="4" ForeColor="#333333" GridLines="None">
                            <RowStyle BackColor="#E3EAEB" />
                            <EmptyDataRowStyle BorderStyle="Dashed" />
                            <Columns>
                                <asp:TemplateField HeaderText="Personal Information">
                                    <ItemTemplate>
                                        <table class="style1">
                                            <tr>
                                                <td style="text-align: right" class="style14">
                                                    Eyec color:</td>
                                                <td style="text-align: left" class="style12">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label33" runat="server" 
                                Text='<%# Eval("Eye_color") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style15">
                                                    Hair Color:</td>
                                                <td style="text-align: left" class="style11">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label34" runat="server" 
                                Text='<%# Eval("Hair_color") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style16">
                                                    Build:</td>
                                                <td style="text-align: left" class="style13">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label35" runat="server" 
                                Text='<%# Eval("Build") %>'></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: right" class="style17">
                                                    Looks:</td>
                                                <td style="text-align: left">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label36" runat="server" 
                                Text='<%# Eval("Looks") %>' style="text-align: left"></asp:Label>
                                                </td>
                                            </tr>
                                        </table>
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                            <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                            <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                            <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                            <EditRowStyle BackColor="#7C6F57" />
                            <AlternatingRowStyle BackColor="White" />
                        </asp:GridView>
                    </td>
            </tr>
            </table>
    
    </div>
   </asp:Content>
