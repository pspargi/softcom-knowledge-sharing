﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class User_VideoMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindDdlVideoMaster();
            BindGrid();
        }


    }
    void BindGrid()
    {
        string str = "SELECT VideoMaster.Video_ID,VideoCatMaster.Video_Cat_name, VideoMaster.Video_name,'~/Uploaded Videos/'+ Video_file  as Video_file,('~/Uploaded Videos/'+ Video_file) as video1 FROM VideoMaster INNER JOIN VideoCatMaster ON VideoMaster.Video_Cat_ID = VideoCatMaster.Video_Cat_ID where VideoMaster.Delete_flag='True'and VideoMaster.User_ID='"+Session["USER_ID"]+"' and VideoMaster.Video_Cat_ID='"+ViewState["ChangeID"]+"'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdvideomaster.DataSource = ds;
            grdvideomaster.DataBind();
        }
        else
        {
            grdvideomaster.DataSource = null;
            grdvideomaster.DataBind();
        }

    }
    void BindDdlVideoMaster()
    {
        string str = "select * from VideoCatMaster";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            DdlVideoCatName.DataSource = ds;
            DdlVideoCatName.DataTextField = "Video_Cat_name";
            DdlVideoCatName.DataValueField = "Video_Cat_ID";
            DdlVideoCatName.DataBind();
        }
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (ViewState["Video_ID"] != null)
        {

            string str = "Select * from VideoMaster where Video_ID=" + ViewState["Video_ID"];
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(str, con);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (File.Exists(Server.MapPath("~/Uploaded Videos/" + ds.Tables[0].Rows[0]["Video_file"].ToString())))
                {
                    File.Delete(Server.MapPath("~/Uploaded Videos/" + ds.Tables[0].Rows[0]["Video_file"].ToString()));
                }
            }
            string str1 = "Delete from VideoMaster where Video_ID=" + ViewState["Video_ID"];
            cmd = new SqlCommand(str1, con);
            cmd.ExecuteNonQuery();
            ViewState.Clear();
            btnSave_Click(sender, e);
            lblmsg.Text = "Record Updated";

        }
        else
        {
            if (fpvideofile.HasFile)
            {
                string FileName = Server.HtmlEncode(fpvideofile.FileName);
                string extension = Path.GetExtension(FileName);
                if ((extension == ".avi") || (extension == ".3gp") || (extension == ".amv") || (extension == ".mp4") || (extension == ".3gp2"))
                {
                    string str = "Insert into VideoMaster (Video_Cat_ID,User_ID,Video_name,Video_file,Delete_flag) values('" + DdlVideoCatName.SelectedValue + "','"+ Session["USER_ID"]+ "','" + txtvideoname.Text + "','" + fpvideofile.FileName + "','False') ";
                    cmd = new SqlCommand(str, con);
                    cmd.ExecuteNonQuery();
                    fpvideofile.SaveAs(Server.MapPath("~/Uploaded Videos/" + fpvideofile.FileName));
                    btncancel_Click(sender, e);
                    lblmsg.Text = "Record will be Send for Confirmation";
                }
                else
                {
                    lblmsg.Text = "Your Video File is not in Real Format";
                }

            }
            else
            {
                lblmsg.Text = "pls fill data ";
            }
              BindGrid();
        }
    
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        DdlVideoCatName.SelectedIndex = -1;
        txtvideoname.Text = "";
    }
    protected void lbkedit_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender; ;
        string str = "Select  * from VideoMaster where Video_ID=" + lbk.CommandArgument;
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ViewState["Video_ID"] = lbk.CommandArgument;
            DdlVideoCatName.SelectedValue = ds.Tables[0].Rows[0]["Video_Cat_ID"].ToString();
            txtvideoname.Text = ds.Tables[0].Rows[0]["Video_name"].ToString();
        }
    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str1 = "Delete from VideoMaster where Video_ID=" + lbk.CommandArgument;
        string str = "Select * from VideoMaster where Video_ID=" + lbk.CommandArgument;
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(str, con);
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            if (File.Exists(Server.MapPath("~/Uploaded Videos/" + ds.Tables[0].Rows[0]["Video_file"].ToString())))
            {
                File.Delete(Server.MapPath("~/Uploaded Videos/" + ds.Tables[0].Rows[0]["Video_file"].ToString()));
            }
        }
        cmd = new SqlCommand(str1, con);
        cmd.ExecuteNonQuery();
        lblmsg.Text = "Record Deleted";
        BindGrid();
  
    }
    protected void DdlVideoCatName_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        ViewState["ChangeID"] = DdlVideoCatName.SelectedValue;
        BindGrid();
    }
}

