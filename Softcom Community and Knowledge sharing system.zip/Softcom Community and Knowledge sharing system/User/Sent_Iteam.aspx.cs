﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class User_Sent_Iteam : System.Web.UI.Page
{
    SqlCommand cmd;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
  lbluserid.Text = Convert.ToString(Session["USER_ID"]);
      
        if (!IsPostBack)
        {
            da = new SqlDataAdapter("Select Email_Id from LoginMaster where User_ID='" + lbluserid.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblemailid.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
            }
            else
            {
                lblemailid.Text = "";
            }
            bindgrid();
        }
    }
    void bindgrid()
    {
        da = new SqlDataAdapter("Select * from Sent_email_master where Sender='" + lblemailid.Text + "' Order by Date_Time desc", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dgvsent.DataSource = ds;
            dgvsent.DataBind();

        }
        else 
        {
            dgvsent.DataSource = null;
            dgvsent.DataBind();

        }
    
    }
    protected void btnResent_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        Session["email_no"] = bt.CommandArgument.ToString();
        Session["email_type"] = "Resend";
        Response.Redirect("Compose_Mail.aspx");
       
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        Button bt = (Button)sender;
        cmd = new SqlCommand("Delete from Sent_email_master where Email_no='"+bt.CommandArgument.ToString()+"'", con);
        cmd.ExecuteNonQuery();
        bindgrid();
    }
}
