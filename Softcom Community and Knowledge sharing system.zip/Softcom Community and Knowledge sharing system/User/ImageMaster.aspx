﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="ImageMaster.aspx.cs" Inherits="User_ImageMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style8
        {
            width: 100%;
        }
        .style9
        {
            text-align: center;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style8">
        <tr>
            <td>
                <asp:Panel ID="Panel1" runat="server">
                    <table class="style8">
                        <tr>
                            <td colspan="2">
                                <h2>
                                    Image Master</h2>
                            </td>
                        </tr>
                        <tr>
                            <td class="style9">
                                Image Category Master:</td>
                            <td style="text-align: left">
                                <asp:DropDownList ID="ddlimagecatname" runat="server" AutoPostBack="True" 
                                    onselectedindexchanged="ddlimagecatname_SelectedIndexChanged">
                                </asp:DropDownList>
                            </td>
                        </tr>
                        <tr>
                            <td class="style9">
                                Image Name:</td>
                            <td style="text-align: left">
                                <asp:TextBox ID="txtimagename" runat="server"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style9">
                                ImageFile</td>
                            <td style="text-align: left">
                                <asp:FileUpload ID="FileUpload1" runat="server" />
                            </td>
                        </tr>
                        <tr>
                            <td class="style9" colspan="2">
                                <asp:Label ID="lblmsg" runat="server" ForeColor="#FF3300"></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style9" colspan="2">
                                <asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" 
                                    BackColor="#695F4C" />
                                <asp:Button ID="btncancel" runat="server" onclick="btncancel_Click" 
                                    Text="Cancel" BackColor="#695F4C" />
                            </td>
                        </tr>
                        <tr>
                            <td class="style9" colspan="2">
                                <asp:DataList ID="DSImagemaster" runat="server" 
                                   RepeatColumns="3" 
                                    RepeatDirection="Horizontal" CellPadding="4" ForeColor="#333333" 
                                    onselectedindexchanged="DSImagemaster_SelectedIndexChanged">
                                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                                    <AlternatingItemStyle BackColor="White" />
                                    <ItemStyle BackColor="#E3EAEB" />
                                    <SelectedItemStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                                    <ItemTemplate>
                                        <table class="style8">
                                            <tr>
                                                <td>
                                                    <asp:LinkButton ID="lbkedit" runat="server" 
                                                        CommandArgument='<%# Eval("Image_ID") %>' onclick="lbkedit_Click1">Edit</asp:LinkButton>
                                                </td>
                                                <td>
                                                    <asp:LinkButton ID="lbkdelete" runat="server" 
                                                        CommandArgument='<%# Eval("Image_ID") %>' onclick="lbkdelete_Click">Delete</asp:LinkButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <asp:ImageButton ID="Imbtnimage" runat="server" 
                                                        CommandArgument='<%# Eval("Image_ID") %>' Height="100px" 
                                                        ImageUrl='<%# Eval("Image_file") %>' onclick="Imbtnimage_Click" Width="100px" />
                                                </td>
                                            </tr>
                                        </table>
                                    </ItemTemplate>
                                </asp:DataList>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
            </td>
        </tr>
        <tr>
            <td>
                <asp:Panel ID="Panel2" runat="server">
                    <table class="style8">
                        <tr>
                            <td>
                                <asp:LinkButton ID="Preview" runat="server" onclick="Preview_Click">&lt;&lt;Preview</asp:LinkButton>
                            </td>
                            <td>
                                <asp:LinkButton ID="lbkclosefullfscrn" runat="server" 
                                    onclick="lbkclosefullfscrn_Click">Close Full Screen</asp:LinkButton>
                            </td>
                            <td>
                                <asp:LinkButton ID="lbknext" runat="server" onclick="lbknext_Click1">Next&gt;&gt;</asp:LinkButton>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <asp:GridView ID="grdFullImage" runat="server" AutoGenerateColumns="False">
                                    <Columns>
                                        <asp:TemplateField>
                                            <ItemTemplate>
                                                <asp:Image ID="Image1" runat="server" Height="300px" 
                                                    ImageUrl='<%# Eval("Image_file") %>' Width="300px" />
                                            </ItemTemplate>
                                        </asp:TemplateField>
                                    </Columns>
                                </asp:GridView>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
            </td>
        </tr>
    </table>
</asp:Content>

