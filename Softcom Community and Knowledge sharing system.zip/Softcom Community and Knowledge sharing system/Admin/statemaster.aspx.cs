﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_statemaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {

            BindDdlCountry();
            BindGrid();
            

        }     
    }
    void BindGrid()
        {
            string str ="SELECT StateMaster.State_ID, StateMaster.State_name FROM CountryMaster INNER JOIN StateMaster ON CountryMaster.Country_ID = StateMaster.Country_ID";
            ds = new DataSet();
            da = new SqlDataAdapter(str,con);
            da.Fill(ds);
         if(ds.Tables[0].Rows.Count>0)
        {
            grdstatemaster.DataSource= ds;
            grdstatemaster.DataBind();
        }
        else
        {
            grdstatemaster.DataSource = null;
            grdstatemaster.DataBind();
        }
         ViewState["Country_ID"] = ddlcoutry.SelectedValue;
         string str1 = "Select * from StateMaster where Country_ID=" + ViewState["Country_ID"];
         da = new SqlDataAdapter(str1, con);
         ds = new DataSet();
         da.Fill(ds);
         if (ds.Tables[0].Rows.Count > 0)
         {
             grdstatemaster.DataSource = ds;
             grdstatemaster.DataBind();
         }
         else
         {
             grdstatemaster.DataSource = ds;
             grdstatemaster.DataBind();
         }

     }
    void BindDdlCountry()
    {
        String str = "Select * from CountryMaster";
        ds = new DataSet();
        da = new SqlDataAdapter(str,con);
        da.Fill(ds);
        if(ds.Tables[0].Rows.Count>0)
        {
            ddlcoutry.DataSource=ds;
            ddlcoutry.DataTextField="Country_name";
            ddlcoutry.DataValueField = "Country_ID";
            ddlcoutry.DataBind();
            //ddlcoutry.Items.Insert(0, "--Select--");
         
        }
    }
   
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["StId"] != null)
        {
            String str = "update StateMaster set Country_ID='" + ddlcoutry.SelectedValue + "',State_name='" + txtstatename.Text + "'where State_ID='" + ViewState["StId"].ToString() +"'";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Updated";
            
        }
        else
        {
              string str1 = "Select * from StateMaster where State_name='" + txtstatename.Text + "'";
               da = new SqlDataAdapter(str1, con);
               ds = new DataSet();
               da.Fill(ds);

               if (ds.Tables[0].Rows.Count == 0)
               {

                   string str = "Insert into StateMaster(Country_ID,State_name)  values ('" + ddlcoutry.SelectedValue + "','" + txtstatename.Text + "')";
                   cmd = new SqlCommand(str, con);
                   cmd.ExecuteNonQuery();
                   btncancel_Click(sender, e);
                   lblmsg.Text = "Record Inserted";
               }
               else
               {
                   lblmsg.Text = "State Name is Already Exist";
               }
        }
        BindGrid();



    }
protected void  btncancel_Click(object sender, EventArgs e)
{
    txtstatename.Text = "";
    ViewState.Clear();
    lblmsg.Text = "";
    //ddlcoutry.SelectedIndex = 0;

}

protected void lbkedit_Click(object sender, EventArgs e)
{
            LinkButton lnk = (LinkButton)sender;
        string str = "Select * from StateMaster where State_ID = " + lnk.CommandArgument;
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(str, con);
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            txtstatename.Text = ds.Tables[0].Rows[0]["State_name"].ToString();
            ViewState["StId"] = ds.Tables[0].Rows[0]["State_ID"].ToString(); 
            ddlcoutry.SelectedValue = ds.Tables[0].Rows[0]["Country_ID"].ToString();

        }
}
protected void lbkdelete_Click(object sender, EventArgs e)
{
    LinkButton lbk = (LinkButton)sender;
    string str = "Delete from StateMaster where State_ID=" + lbk.CommandArgument.ToString();
    cmd = new SqlCommand(str, con);
    cmd.ExecuteNonQuery();
    btncancel_Click(sender, e);
    lblmsg.Text = "Record Deleted";
    BindGrid();
    
}
protected void ddlcoutry_SelectedIndexChanged(object sender, EventArgs e)
{
    BindGrid();   
}
protected void txtstatename_TextChanged(object sender, EventArgs e)
{
   
}
protected void grdstatemaster_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
{
    grdstatemaster.PageIndex = e.NewSelectedIndex;
    BindGrid();
}
}

