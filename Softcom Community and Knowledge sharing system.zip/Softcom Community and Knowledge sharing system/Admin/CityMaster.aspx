﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="CityMaster.aspx.cs" Inherits="Admin_CityMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 26px;
            text-align: left;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2">
                <h3 style="text-align: center">
                    City Master</h3>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Coutnry Name:</td>
                        <td style="text-align: left">
                            <asp:DropDownList ID="ddlcountryname" runat="server" AutoPostBack="True" 
                                onselectedindexchanged="ddlcountryname_SelectedIndexChanged">
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr>
                        <td style="text-align: right" class="style2">
                            State Name:</td>
            <td class="style2">
                <asp:DropDownList ID="ddlstatename" runat="server" Width="76px">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                City Name:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtcityname" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Button ID="btnSave" runat="server" Height="26px" onclick="btnsave_Click" 
                    Text="Save" Width="56px" />
                &nbsp;
                <asp:Button ID="btncancel" runat="server" Text="Cancel" 
                    onclick="btncancel_Click" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdcitymaster" runat="server" AutoGenerateColumns="False" 
                    CellPadding="4" ForeColor="#333333" GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkEdit" runat="server" 
                                    CommandArgument='<%# Eval("City_ID") %>' onclick="lbkEdit_Click">Edit</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkdelete" runat="server" 
                                    CommandArgument='<%# Eval("City_ID") %>' onclick="lbkdelete_Click">Delete</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="City_ID" HeaderText="City ID" />
                        <asp:BoundField DataField="City_name" HeaderText="City Name" />
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
    &nbsp;   
</asp:Content>

