﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="VideoConfirm.aspx.cs" Inherits="Admin_VideoConfirm" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            font-weight: normal;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td style="text-align: center">
                <h2>
                    Video Request Master</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                <asp:GridView ID="grdvideoreqmaster" runat="server" AutoGenerateColumns="False" 
                    CellPadding="4" ForeColor="#333333" GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <table class="style1">
                                    <tr>
                                        <td rowspan="2">
                                            <asp:Image ID="imguser" runat="server" ImageUrl='<%# Eval("Photo_file") %>' 
                                                Height="100px" Width="70px" />
                                        </td>
                                        <td class="style2">
                                            Name:</td>
                                        <td class="style2">
                                            <asp:Label ID="lblfirstnm" runat="server" Text='<%# Eval("First_name") %>'></asp:Label>
                                            <asp:Label ID="lblmidlenm" runat="server" Text='<%# Eval("Midle_name") %>'></asp:Label>
                                            <asp:Label ID="lbllastnm" runat="server" Text='<%# Eval("Last_name") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style2">
                                            Email ID:</td>
                                        <td class="style2">
                                            <asp:Label ID="lblemailid" runat="server" Text='<%# Eval("Email_Id") %>'></asp:Label>
                                        </td>
                                    </tr>
                                </table>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <asp:LinkButton ID="lblshowvideo" runat="server" onclick="lblshowvideo_Click">ShowVideos</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <asp:LinkButton ID="lblmoreinfo" runat="server">More Information</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

