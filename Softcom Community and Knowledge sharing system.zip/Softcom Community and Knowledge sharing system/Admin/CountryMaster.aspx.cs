﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;


public partial class Admin_Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindGrid();
        }
        

    }

   void BindGrid()
    {
        string str = "Select * from countryMaster";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if(ds.Tables[0].Rows.Count>0)
        {
            grdcountrymaster.DataSource=ds;
            grdcountrymaster.DataBind();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
   {
       
           if (ViewState["Country_ID"] != null)
           {
               cmd = new SqlCommand("Update CountryMaster set Country_name ='" + txtcountryname.Text + "',Country_descr='" + txtcountydescription.Text + "'where Country_ID= " + ViewState["Country_ID"], con);
               cmd.ExecuteNonQuery();
               BindGrid();
               btncancel_Click(sender, e);
               lblmsg.Text = "Record Updated successfully";

           }
           else
           {
               string str1 = "Select * from CountryMaster where Country_name='" + txtcountryname.Text + "'";
               da = new SqlDataAdapter(str1, con);
               ds = new DataSet();
               da.Fill(ds);

               if (ds.Tables[0].Rows.Count == 0)
               {
                   string str = "Insert into CountryMaster Values ('" + txtcountryname.Text + "','" + txtcountydescription.Text + "')";
                   cmd = new SqlCommand(str, con);
                   cmd.ExecuteNonQuery();
                   btncancel_Click(sender, e);
                   lblmsg.Text = "Record Inserted Successfully";
                   BindGrid();
               }
               else
                {
                   lblmsg.Text = "Country Name Already Exist";
                }
           }
}
         
    protected void btncancel_Click(object sender, EventArgs e)
    {
        
        txtcountryname.Text = "";
        txtcountydescription.Text = "";
        lblmsg.Text = "";
        txtcountryname.Focus();
        ViewState.Clear();

    }




protected void lnkdelete_Click(object sender, EventArgs e)
{
    LinkButton lnk = (LinkButton)sender;
    cmd = new SqlCommand("delete from CountryMaster where Country_ID="+lnk.CommandArgument, con);
    cmd.ExecuteNonQuery();
    BindGrid();
    btncancel_Click(sender,e);
    lblmsg.Text="Record Deleted Sucessfully";

}



protected void lbkedit_Click(object sender, EventArgs e)
{
    LinkButton lnk = (LinkButton)sender;

    da = new SqlDataAdapter("Select * from CountryMaster where Country_ID=" + lnk.CommandArgument, con);
    ds = new DataSet();
    da.Fill(ds);


    if (ds.Tables[0].Rows.Count > 0)
    {
        ViewState["Country_ID"] = lnk.CommandArgument;
        txtcountryname.Text = ds.Tables[0].Rows[0]["Country_name"].ToString();
        txtcountydescription.Text = ds.Tables[0].Rows[0]["Country_descr"].ToString();
    }
}
protected void grdcountrymaster_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
{
    grdcountrymaster.PageIndex = e.NewSelectedIndex;
    BindGrid();
}
}
