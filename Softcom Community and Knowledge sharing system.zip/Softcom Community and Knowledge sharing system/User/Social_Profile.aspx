﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Social_Profile.aspx.cs" Inherits="User_Social_Profile" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style3
        {
            text-align: right;
        }
        .style4
        {
        }
        .style5
        {
            width: 194px;
        }
        .style6
        {
            text-align: right;
        }
        .style8
        {
            width: 174px;
            text-align: right;
            }
        .style12
        {
            width: 42px;
            height: 58px;
        }
        .style13
        {
            text-align: center;
            height: 58px;
        }
        .style14
        {
            height: 58px;
        }
        .style15
        {
            height: 45px;
            text-align: center;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">

    <table class="style1">
        <tr>
            <td class="style15" colspan="3">
                <asp:Label ID="Label14" runat="server" Font-Size="XX-Large" 
                    Text="Social Profile Master"></asp:Label>
            </td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label1" runat="server" Text="Relation Ship Status:-"></asp:Label>
            </td>
            <td class="style5">
                <asp:DropDownList ID="ddlrelationship_status" runat="server" Height="20px" 
                    Width="156px">
                    <asp:ListItem Enabled="False"></asp:ListItem>
                    <asp:ListItem>No answer</asp:ListItem>
                    <asp:ListItem>Single</asp:ListItem>
                    <asp:ListItem>Married</asp:ListItem>
                    <asp:ListItem>Committed</asp:ListItem>
                    <asp:ListItem>Open Marriage</asp:ListItem>
                    <asp:ListItem>Open Relationship</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label2" runat="server" Text="Ethnicity :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:DropDownList ID="ddlethinicity" runat="server" Height="19px" Width="156px">
                    <asp:ListItem></asp:ListItem>
                    <asp:ListItem>No Answer</asp:ListItem>
                    <asp:ListItem>Asian</asp:ListItem>
                    <asp:ListItem>African American(Black)</asp:ListItem>
                    <asp:ListItem>Causcasin(White)</asp:ListItem>
                    <asp:ListItem>Hispanic/latino</asp:ListItem>
                    <asp:ListItem>Middle estrean</asp:ListItem>
                    <asp:ListItem>Hispanic/Latio</asp:ListItem>
                    <asp:ListItem>Middle estren</asp:ListItem>
                    <asp:ListItem>Native American</asp:ListItem>
                    <asp:ListItem>Marty ethnic</asp:ListItem>
                    <asp:ListItem>Pacific Island</asp:ListItem>
                    <asp:ListItem>Other</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label3" runat="server" Text="Religion :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:DropDownList ID="ddlreligion" runat="server" Height="20px" Width="157px">
                    <asp:ListItem></asp:ListItem>
                    <asp:ListItem>Other</asp:ListItem>
                    <asp:ListItem>No Answer</asp:ListItem>
                    <asp:ListItem>Agonostic</asp:ListItem>
                    <asp:ListItem>Atheist</asp:ListItem>
                    <asp:ListItem>Buddhist</asp:ListItem>
                    <asp:ListItem>Christian/Catholic</asp:ListItem>
                    <asp:ListItem>Christian/Protestant</asp:ListItem>
                    <asp:ListItem>Christian/Other</asp:ListItem>
                    <asp:ListItem>Hindiu</asp:ListItem>
                    <asp:ListItem>Jewish</asp:ListItem>
                    <asp:ListItem>Muslim</asp:ListItem>
                    <asp:ListItem>Sprituam but Religious</asp:ListItem>
                    <asp:ListItem>Religious humanism</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label4" runat="server" Text="Home Town :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txthometown" runat="server" Width="161px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label5" runat="server" Text="Passion :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txtpassion" runat="server" Width="161px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label6" runat="server" Text="Sports :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txtsports" runat="server" Width="161px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label7" runat="server" Text="Books :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txtbooks" runat="server" Width="161px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label8" runat="server" Text="Music :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txtmusic" runat="server" Width="161px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label9" runat="server" Text="T.V Shows"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txttvshows" runat="server" Width="168px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label10" runat="server" Text="Movies"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txtmovies" runat="server" Width="163px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label11" runat="server" Text="Cuisine :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:TextBox ID="txtcuisine" runat="server" Width="165px"></asp:TextBox>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style8">
            </td>
            <td class="style5">
            </td>
            <td class="style6">
            </td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label12" runat="server" Text="Smoking :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:DropDownList ID="ddlsmoking" runat="server" Height="20px" Width="163px">
                    <asp:ListItem></asp:ListItem>
                    <asp:ListItem>No answer</asp:ListItem>
                    <asp:ListItem>No</asp:ListItem>
                    <asp:ListItem>Socially</asp:ListItem>
                    <asp:ListItem>Regularly</asp:ListItem>
                    <asp:ListItem>Heavily</asp:ListItem>
                    <asp:ListItem>Try to quit</asp:ListItem>
                    <asp:ListItem>Quit</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style6">
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style3">
                <asp:Label ID="Label13" runat="server" Text="Drinking :-"></asp:Label>
            </td>
            <td class="style5">
                <asp:DropDownList ID="ddldrinking" runat="server" Height="20px" Width="162px">
                    <asp:ListItem></asp:ListItem>
                    <asp:ListItem>No Answer</asp:ListItem>
                    <asp:ListItem>No</asp:ListItem>
                    <asp:ListItem>Socially</asp:ListItem>
                    <asp:ListItem>Regularly</asp:ListItem>
                    <asp:ListItem>Heavily</asp:ListItem>
                    <asp:ListItem>Try to quit</asp:ListItem>
                    <asp:ListItem>Quit</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td class="style6">
                <asp:Label ID="lblmsg" runat="server" Text="Label" Visible="False"></asp:Label>
            </td>
        </tr>
        <tr>
            <td class="style13" colspan="3">
                <asp:Button ID="btnSave" runat="server" Height="26px" 
                    style="text-align: center" Text="Save" Width="74px" 
                    onclick="Button1_Click" BackColor="#695F4C" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btncancel" runat="server" Height="26px" 
                    style="text-align: center" Text="Cancel" Width="74px" 
                    onclick="Button2_Click" BackColor="#695F4C" />
                <asp:Label ID="lblmsg0" runat="server" Text="Label" Visible="False"></asp:Label>
            </td>
        </tr>
    </table>
</asp:Content>
