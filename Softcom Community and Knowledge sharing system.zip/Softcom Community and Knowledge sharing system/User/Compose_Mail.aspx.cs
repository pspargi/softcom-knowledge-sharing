﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Compose_Mail : System.Web.UI.Page
{
    SqlCommand cmd;
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    string str;
    protected void Page_Load(object sender, EventArgs e)
    {

        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        lbuserid.Text = Convert.ToString(Session["USER_ID"]);
        if(!IsPostBack)
        {
            da = new SqlDataAdapter("Select Email_Id from LoginMaster where User_ID='" + lbuserid.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lbemail_Id.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
            }
            if (Session["email_type"] == "Forward")
            {
                da = new SqlDataAdapter("Select * from Email_Master where Email_no='" + Session["email_no"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtsubject.Text = ds.Tables[0].Rows[0]["Subject"].ToString();
                    txtmessagebox.Text = ds.Tables[0].Rows[0]["Message"].ToString();

                }
            }
            else if(Session["email_type"] == "Reply")
              {
                    da = new SqlDataAdapter("Select * from Email_Master where Email_no='" + Session["email_no"] + "'", con);
                    ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtemail_Address.Text=ds.Tables[0].Rows[0]["Sender"].ToString();
                        txtsubject.Text = ds.Tables[0].Rows[0]["Subject"].ToString();
                 
                    }
                
                }
            else if (Session["email_type"] == "Resend")
            {
                    da = new SqlDataAdapter("Select * from Sent_email_master where Email_no='" + Session["email_no"] + "'", con);
                    ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtemail_Address.Text = ds.Tables[0].Rows[0]["Receiver"].ToString();
                        txtsubject.Text = ds.Tables[0].Rows[0]["Subject"].ToString();
                        txtmessagebox.Text = ds.Tables[0].Rows[0]["Message"].ToString();
                    }
            
            }
            else if (Session["email_type"] == "Draft")
            {
                da = new SqlDataAdapter("Select * from Draft_message where draft_no='" + Session["draft_no"] + "'", con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtemail_Address.Text = ds.Tables[0].Rows[0]["Receiver"].ToString();
                    txtsubject.Text = ds.Tables[0].Rows[0]["Subject"].ToString();
                    txtmessagebox.Text = ds.Tables[0].Rows[0]["Message"].ToString();
                }
            
            
            }
                Session["email_no"]="";
                Session["email_type"] = "";
            
             
          
        }
    }
    protected void btnsend_Click(object sender, EventArgs e)
    {
              
        lbdate.Text= System.DateTime.Now.ToString();
        string s = "UnRead";
        cmd = new SqlCommand("Insert Into Email_Master(Sender,Receiver,Subject,Message,Status,Date_Time) values('" + lbemail_Id.Text + "','" + txtemail_Address.Text + "','" + txtsubject.Text + "','" + txtmessagebox.Text + "','" + s + "','" + lbdate.Text + "')", con);
        cmd.ExecuteNonQuery();
        da = new SqlDataAdapter("Select MAX(Email_no) as maxuser FROM Email_Master", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
         lbsent.Text=ds.Tables[0].Rows[0]["maxuser"].ToString();
        }
        cmd = new SqlCommand("Insert Into Sent_email_master(Email_no,Sender,Receiver,Subject,Message,Status,Date_Time) values('"+lbsent.Text+"','" + lbemail_Id.Text + "','" + txtemail_Address.Text + "','" + txtsubject.Text + "','" + txtmessagebox.Text + "','" + s + "','" + lbdate.Text + "')", con);
        cmd.ExecuteNonQuery();

        lbmsg.Text = "Your message has been sent";
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {

    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        if (lbmsg.Text != "Your message has been sent")
        {
            lbdate.Text = System.DateTime.Now.ToString();
            string str = "";
            cmd = new SqlCommand("Insert into Draft_message(Sender,Receiver,Subject,Message,Status,Date_Time) values('"+lbemail_Id.Text+"','"+txtemail_Address.Text+"','"+txtsubject.Text+"','"+txtmessagebox.Text+"','"+str+"','"+lbdate.Text+"')", con);
            cmd.ExecuteNonQuery();
            Response.Redirect("Profile_HomePage.aspx");
        }
        }
}
