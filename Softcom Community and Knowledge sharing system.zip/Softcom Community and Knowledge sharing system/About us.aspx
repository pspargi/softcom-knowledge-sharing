﻿<%@ Page Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="About us.aspx.cs" Inherits="About_us" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 96%;
        }
        .style2
        {
            height: 17px;
            text-align: center;
            width: 467px;
        }
        .style3
        {
            width: 467px;
        }
        .style4
        {
            text-align: justify;
        }
    .style5
    {
        font-family: Verdana;
    }
    .style8
    {
        font-size: small;
    }
    .style9
    {
        text-align: justify;
        font-size: small;
        color: black;
        font-family: Verdana;
    }
    .style10
    {
        font-family: Verdana;
        font-size: small;
    }
    .style11
    {
        text-align: center;
    }
    .style12
    {
        font-size: large;
    }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td class="style2">
                <h4>
                    About Us</h4>
            </td>
        </tr>
        <tr>
            <td class="style3">
                <p class="style11">
                    <b style="mso-bidi-font-weight:normal"><u>
                    <span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;color:black" 
                        class="style12">Company Profile</span></u></b><span 
                        style="font-size:22.0pt;font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;color:black"><o:p></o:p></span></p>
                <p class="style4">
                    <span style="font-family:&quot;Times New Roman&quot;,&quot;serif&quot;;
color:green"><o:p>&nbsp;</o:p></span><o:p>&nbsp;</o:p><span style="color:black" class="style8"><span 
                        style="mso-tab-count:3" class="style5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </span>
                    </span>
                    <span style="color:black" class="style10">
                    SoftCom Technologies is the one of the fastest growing IT Company in <st1:place w:st="on">
                    Gujarat</st1:place>. Here, thoughts become reality with the use of latest 
                    technologies. We provide best solutions with minimum cost as per client’s need. 
                    In this changing world only those people survive who is ready to accept changes. <o:p></o:p>
                    </span>
                </p>
                <p class="style9">
                    <o:p>
                    &nbsp;</o:p><span style="color:black" class="style8"><span style="mso-tab-count:3" 
                        class="style5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </span></span>
                    <span style="color:black" class="style10">
                    The techno revolution is the main focus of SoftCom Technologies.<span 
                        style="mso-spacerun:yes">&nbsp; </span>Every individual must get the advantage of 
                    latest tools. A clear perception of the growing requirement of the corporate 
                    world in the area of it has enabled SoftCom Technologies to develop programs and 
                    software’s of specific needs of clients. SoftCom Technologies where strategy, 
                    design and production rally together to make solution that is reliable, 
                    efficient and easy access by everyone.<o:p></o:p></span></p>
                <p class="style9">
                    <o:p>
                    &nbsp;</o:p><b style="mso-bidi-font-weight:normal"><span style="color:black" 
                        class="style10"><span style="mso-spacerun:yes">&nbsp;</span></span><u><span 
                        style="color:black" class="style10">Our
<st1:city w:st="on"><st1:place w:st="on">Mission</st1:place></st1:City></span><span style="font-size:14.0pt;font-family:
&quot;Times New Roman&quot;,&quot;serif&quot;;color:black">:<o:p></o:p></span></u></b></p>
                <p class="style4">
                    <b style="mso-bidi-font-weight:normal"><u>
                    <span style="color:black" class="style10"><o:p>
                    <span style="text-decoration:
 none">&nbsp;</span></o:p></span></u></b><span style="mso-spacerun:yes"><span class="style8">&nbsp;</span></span><span 
                        class="style8"><span style="mso-tab-count:3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </span></span><span style="mso-spacerun:yes"><span class="style8">&nbsp;</span></span><span 
                        class="style8">To contribute on the challenges concerned customer to provide 
                    competitive Web based Customized ERP, Web based solutions and services to help 
                    our customer to create maximum values and help them to achieve success by 
                    providing excellent services.</span><o:p></o:p></p>
                <p class="style9">
                    <o:p>
                    &nbsp;</o:p><b style="mso-bidi-font-weight:normal"><span style="color:black" 
                        class="style10"><span style="mso-spacerun:yes">&nbsp;</span><u>Our Vision:<o:p></o:p></u></span></b></p>
                <p class="style9">
                    <o:p>
                    &nbsp;</o:p><span style="mso-spacerun:yes"><span class="style8">&nbsp;</span></span><span style="mso-tab-count:3"><span 
                        class="style8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>
                    </span><span class="style8">To be an outstanding IT company across the globe and 
                    understanding and incorporating the latest technologies in our solution and to 
                    prove a real meaning of “Join the Techno Revolution”</span><o:p></o:p></p>
            </td>
        </tr>
    </table>
</asp:Content>

