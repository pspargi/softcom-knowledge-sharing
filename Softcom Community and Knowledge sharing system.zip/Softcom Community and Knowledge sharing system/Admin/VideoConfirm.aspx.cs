﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_VideoConfirm : System.Web.UI.Page
{
    SqlConnection con;
   
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            BindGrid();
        }
       

    }
    void BindGrid()
    {
        string str = "select ProfileMaster.User_ID, ProfileMaster.First_name,ProfileMaster.Midle_name,ProfileMaster.Last_name,ProfileMaster.Email_Id,'~/Uploaded Images/'+ Photo_file  as Photo_file from ProfileMaster where ProfileMaster.User_ID IN ( select VideoMaster.User_ID from VideoMaster where Delete_flag='False' group by VideoMaster.User_ID)";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grdvideoreqmaster.DataSource = ds;
            grdvideoreqmaster.DataBind();
        }
        else
        {
            grdvideoreqmaster.DataSource = null;
            grdvideoreqmaster.DataBind();
        }
    }
    protected void lblshowvideo_Click(object sender, EventArgs e)
    {
        Response.Redirect("Videoaproval.aspx");
    }
}
