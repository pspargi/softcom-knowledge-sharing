﻿<%@ Page Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="Forgott_Password.aspx.cs" Inherits="User_Forgott_Password" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            height: 30px;
            text-align: center;
            font-size: xx-large;
        }
        .style4
        {
            text-align: right;
            width: 426px;
        }
        .style5
        {
            text-align: center;
        }
        .style9
        {
            text-align: center;
            height: 23px;
        }
        .style10
        {
            text-align: right;
            height: 22px;
            width: 426px;
        }
        .style11
        {
            height: 22px;
        }
        .style12
        {
            width: 341px;
            text-align: left;
        }
        .style13
        {
            height: 22px;
            width: 341px;
            text-align: left;
        }
        .style15
        {
            text-align: center;
            height: 93px;
        }
        .style16
        {
            text-align: right;
            width: 426px;
            height: 23px;
        }
        .style17
        {
            width: 341px;
            text-align: left;
            height: 23px;
        }
        .style18
        {
            height: 23px;
        }
        </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
        <table class="style1">
        <tr>
            <td class="style2" colspan="3">
                <asp:Label ID="Label4" runat="server" Text="Retrive Your Password From Here?"></asp:Label>
                <asp:Label ID="lblwarn" runat="server"></asp:Label>
            </td>
        </tr>
        <tr>
            <td class="style4">
                    <asp:Label ID="Label6" runat="server" Text="User_Type"></asp:Label>
                </td>
            <td class="style12">
                <asp:RadioButtonList ID="rbluser_type" runat="server" AutoPostBack="True" 
                    RepeatDirection="Horizontal">
                    <asp:ListItem>User</asp:ListItem>
                    <asp:ListItem>Admin</asp:ListItem>
                </asp:RadioButtonList>
            </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator10" runat="server" 
                    ControlToValidate="rbluser_type" ErrorMessage="*" ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
        </tr>
        <tr>
            <td class="style16">
                <asp:Label ID="Label1" runat="server" Text="Email Address :-"></asp:Label>
            </td>
            <td class="style17">
                <asp:TextBox ID="txtemail" runat="server" Width="275px"></asp:TextBox>
                &nbsp;
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                    ControlToValidate="txtemail" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
            </td>
            <td class="style18">
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                    ControlToValidate="txtemail" ErrorMessage="Enter Valid Email Address" 
                    SetFocusOnError="True" 
                    ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" 
                    ValidationGroup="1"></asp:RegularExpressionValidator>
            </td>
        </tr>
        <tr>
            <td class="style4">
                <asp:Label ID="Label2" runat="server" Text="Security Question :-"></asp:Label>
            </td>
            <td class="style12">
                <asp:DropDownList ID="drlquestion" runat="server" Height="23px" Width="283px" 
                    AutoPostBack="True" onselectedindexchanged="drlquestion_SelectedIndexChanged" 
                    style="margin-bottom: 1px">
                    <asp:ListItem>What is Your Pat Name?</asp:ListItem>
                    <asp:ListItem>Who is your Best Friend?</asp:ListItem>
                    <asp:ListItem>Choose My Own Question</asp:ListItem>
                </asp:DropDownList>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4">
            </td>
            <td class="style12">
                <asp:TextBox ID="txtmyowner" runat="server" Width="278px"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator8" runat="server" 
                    ControlToValidate="txtmyowner" ErrorMessage="*" SetFocusOnError="True"></asp:RequiredFieldValidator>
                </td>
            <td>
            </td>
        </tr>
        <tr>
            <td class="style10">
                <asp:Label ID="Label3" runat="server" Text="Answer for It :-"></asp:Label>
            </td>
            <td class="style13">
                <asp:TextBox ID="txtanswer" runat="server" Width="278px"></asp:TextBox>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator9" runat="server" 
                    ControlToValidate="txtanswer" ErrorMessage="*" SetFocusOnError="True" 
                    ValidationGroup="1"></asp:RequiredFieldValidator>
                </td>
            <td class="style11">
            </td>
        </tr>
        <tr>
            <td class="style9" colspan="3">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </td>
        </tr>
        <tr>
            <td class="style5" colspan="3">
                <asp:Button ID="btnsubmit" runat="server" onclick="btnsubmit_Click" 
                    style="text-align: center" Text="Submit" ValidationGroup="1" 
                    BackColor="#695F4C" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btncancel" runat="server" style="text-align: center" 
                    Text="Cancel" onclick="btncancel_Click" BackColor="#695F4C" />
            </td>
        </tr>
        <tr>
            <td class="style15" colspan="3">
                <asp:Label ID="lblmsg" runat="server" Font-Size="XX-Large" ForeColor="Red"></asp:Label>
            </td>
        </tr>
    </table>
    
    
</asp:Content>