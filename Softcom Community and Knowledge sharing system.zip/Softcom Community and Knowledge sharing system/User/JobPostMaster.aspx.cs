﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_JobPostMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
           
            BindGrid();
        }

    }
    void BindGrid()
    {
        string str = "select * from JobpostMaster";
        ds = new DataSet();
        da = new SqlDataAdapter(str, con);
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            grdjobpostmaster.DataSource = ds;
            grdjobpostmaster.DataBind();
        }
        else
        {
            grdjobpostmaster.DataSource = null;
            grdjobpostmaster.DataBind();
        }

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["Jobpost_ID"] != null)
        {
            cmd = new SqlCommand("Update JobpostMaster set Company_name ='" + txtcompanyname.Text + "',Company_adress='" + txtcompanyadd.Text + "',Qualification='" + txtqualification.Text + "',Company_post='" + txtpost.Text + "',Date_of_interview='" + txtdateofiterviw.Text + "'where Jobpost_ID= " + ViewState["Jobpost_ID"], con);
            cmd.ExecuteNonQuery();
            BindGrid();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Updated successfully";

        }
        else
        {
            string str = "Insert into JobpostMaster(Company_name,Company_adress,Qualification,Company_post,date_of_interview)  values ('" + txtcompanyname.Text + "','" + txtcompanyadd.Text + "','" + txtqualification.Text + "','" + txtpost.Text + "','" + txtdateofiterviw.Text + "')";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            lblmsg.Text = "Record Inserted";
        }
        BindGrid();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtcompanyname.Text = "";
        txtcompanyadd.Text = "";
        txtqualification.Text = "";
        txtpost.Text = "";
        txtdateofiterviw.Text = "";
        ViewState.Clear();
    }
    protected void lbkedit_Click(object sender, EventArgs e)
    {
         LinkButton lbk = (LinkButton)sender;
        String str = "Select * from JobpostMaster where Jobpost_ID=" + lbk.CommandArgument;
        da = new SqlDataAdapter(str,con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            txtcompanyname.Text = ds.Tables[0].Rows[0]["Company_name"].ToString();
            txtcompanyadd.Text = ds.Tables[0].Rows[0]["Company_adress"].ToString();
            txtqualification.Text = ds.Tables[0].Rows[0]["Qualification"].ToString();
            txtpost.Text = ds.Tables[0].Rows[0]["Company_post"].ToString();
            txtdateofiterviw.Text = ds.Tables[0].Rows[0]["Date_of_interview"].ToString();
            ViewState["Jobpost_ID"] = ds.Tables[0].Rows[0]["Jobpost_ID"].ToString();

        }  
    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lnk = (LinkButton)sender;
        cmd = new SqlCommand("delete from JobpostMaster where Jobpost_ID=" + lnk.CommandArgument, con);
        cmd.ExecuteNonQuery();
        BindGrid();
        btncancel_Click(sender, e);
        lblmsg.Text = "Record Deleted Sucessfully";

    }
}
