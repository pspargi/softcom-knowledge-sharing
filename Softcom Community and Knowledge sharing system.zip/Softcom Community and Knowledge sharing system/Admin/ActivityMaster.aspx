﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="ActivityMaster.aspx.cs" Inherits="Admin_ActivityMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            text-align: center;
        }
        .style3
        {
            text-align: center;
            height: 25px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <h2>
                    Activity Master</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Activity Group Name:</td>
            <td style="text-align: left">
                <asp:DropDownList ID="ddlActivgroupname" runat="server" AutoPostBack="True" 
                     
                    style="text-align: left" 
                    onselectedindexchanged="ddlActivgroupname_SelectedIndexChanged">
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Activity Name:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtactivityname" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Upload Add Image:</td>
            <td style="text-align: left">
                <asp:FileUpload ID="fp_advertisement" runat="server" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td class="style3" colspan="2">
                <asp:Button ID="btnSave" runat="server" Text="save" onclick="btnsave_Click" 
                    Width="53px" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btncancel" runat="server" Text="cancel" 
                    onclick="btncancel_Click" />
            </td>
        </tr>
        <tr>
            <td class="style2" colspan="2">
                <asp:GridView ID="grdactivitymaster" runat="server" AutoGenerateColumns="False" 
                    CellPadding="4" ForeColor="#333333" GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbedit" runat="server" onclick="lbedit_Click" 
                                    CommandArgument='<%# Eval("Activity_ID") %>'>Edit</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbdelete" runat="server" onclick="lbdelete_Click" 
                                    CommandArgument='<%# Eval("Activity_ID") %>'>Delete</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Activity_ID" HeaderText="Activity ID" />
                        <asp:BoundField DataField="Activity_name" HeaderText="Activity Name" />
                        <asp:TemplateField HeaderText="advertisement Image">
                            <ItemTemplate>
                                <asp:HyperLink ID="hpladslink" runat="server" 
                                    Text='<%# Eval("ads_pic_file") %>' 
                                    NavigateUrl='<%# Eval("ads_pic_file") %>'></asp:HyperLink>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

