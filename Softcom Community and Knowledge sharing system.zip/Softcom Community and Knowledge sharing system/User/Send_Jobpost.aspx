﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Send_Jobpost.aspx.cs" Inherits="User_Send_Jobpost" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
  <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style2
        {
            text-align: center;
        }
        .style3
        {
            width: 272px;
        }
 p.MsoNormal
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:0in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	}
        .style4
        {
            text-align: center;
        }
        .style5
        {
            text-align: right;
            width: 293px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">

    <table class="style1">
        <tr>
            <td class="style5">
                &nbsp;</td>
            <td class="style3">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style5">
                Send to (email_address):-</td>
            <td class="style3">
                <asp:TextBox ID="txtsendto" runat="server" Width="275px" ValidationGroup="1"></asp:TextBox>
            </td>
            <td>
                <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                    ControlToValidate="txtsendto" ErrorMessage="Email Address is not valid" 
                    SetFocusOnError="True" 
                    ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" 
                    ValidationGroup="1"></asp:RegularExpressionValidator>
            </td>
        </tr>
        <tr>
            <td class="style5">
                Company Name:-</td>
            <td class="style3">
                <asp:TextBox ID="txtcompany_name" runat="server" Width="274px"></asp:TextBox>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style5">
                <p class="MsoNormal">
                    Requirement:-</p>
            </td>
            <td class="style3">
                <asp:TextBox ID="txtrequirement" runat="server" Width="274px"></asp:TextBox>
            </td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style5">
                Designation:-</td>
            <td class="style3">
                <span style="font-size:11.0pt;line-height:115%;
          <td class="style3">
                <asp:TextBox ID="txtdeignation" runat="server" Width="274px" Height="21px" 
                    ontextchanged="txtmoreinfo_TextChanged"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style5">
                &nbsp;</td>
            <td class="style3">
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style4" colspan="3">
                <asp:Button ID="btnsendjobpost" runat="server" onclick="btnsendjobpost_Click" 
                    Text="Send Jobpost" Width="106px" ValidationGroup="1" 
                    BackColor="#695F4C" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="Button1" runat="server" Text="Cancel" Width="99px" />
            </td>
        </tr>
        <tr>
            <td class="style2" colspan="3">
                &nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Label ID="lblmsg" runat="server" Font-Bold="True" Font-Size="X-Large" 
                    ForeColor="Red"></asp:Label>
                &nbsp;&nbsp;&nbsp;&nbsp;
            </td>
        </tr>
    </table>
    <asp:Label ID="lbuserid" runat="server" Visible="False"></asp:Label>
    <asp:Label ID="lbemail" runat="server" Visible="False"></asp:Label>
    <asp:Label ID="lbmaxsent" runat="server" Visible="False"></asp:Label>
</asp:Content>
