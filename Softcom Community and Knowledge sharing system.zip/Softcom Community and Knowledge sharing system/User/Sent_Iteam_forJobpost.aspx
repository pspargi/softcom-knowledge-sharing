﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="Sent_Iteam_forJobpost.aspx.cs" Inherits="User_Sent_Iteam_forJobpost" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 88%;
        }
        .style2
        {
            text-align: right;
        }
        .style3
        {
            width: 214px;
            text-align: right;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <div>
    
    </div>
    <asp:GridView ID="dgvsentiteam" runat="server" AutoGenerateColumns="False" 
        CellPadding="4" ForeColor="#333333" GridLines="None">
        <RowStyle BackColor="#E3EAEB" />
        <Columns>
            <asp:TemplateField HeaderText="Send to">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td>
                                <asp:Label ID="lblsendto" runat="server" Text='<%# Eval("Receiver") %>'></asp:Label>
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
            <asp:TemplateField HeaderText="Job Post">
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td class="style3">
                                Company Name:-</td>
                            <td>
                                <asp:TextBox ID="txtcompany_Name" runat="server" Height="20px" ReadOnly="True" 
                                    Width="166px" Text='<%# Eval("Company_name") %>'></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style2">
                                Requirement:-</td>
                            <td>
                                <asp:TextBox ID="txtrequirement" runat="server" Height="20px" ReadOnly="True" 
                                    Width="165px" Text='<%# Eval("Requirement") %>'></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style2">
                                Designation:-</td>
                            <td>
                                <asp:TextBox ID="txtdesignation" runat="server" Height="21px" ReadOnly="True" 
                                    Width="164px" Text='<%# Eval("Designation") %>'></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="style2" colspan="2">
                                <asp:Label ID="lbldate" runat="server" Text='<%# Eval("Date_Time") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="style2" colspan="2">
                                <asp:Button ID="btnResend" runat="server" 
                                    CommandArgument='<%# Eval("Job_post_id") %>' onclick="btnResend_Click" 
                                    Text="Resend" BackColor="#666633" />
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btnDelete" runat="server" 
                                    CommandArgument='<%# Eval("Job_post_id") %>' onclick="btnDelete_Click" 
                                    Text="Delete" style="height: 26px" BackColor="#666633" />
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#7C6F57" />
        <AlternatingRowStyle BackColor="White" />
    </asp:GridView>
    <asp:Label ID="lbluserid" runat="server" Visible="False"></asp:Label>
    <asp:Label ID="lblemailid" runat="server" Visible="False"></asp:Label>
</asp:Content>