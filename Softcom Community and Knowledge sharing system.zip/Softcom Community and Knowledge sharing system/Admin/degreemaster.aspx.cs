﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_degreemaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            Bindgrid();
        }
    }
    void Bindgrid()
    {
        string str = "select * from DegreeMaster";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            grddegreemaster.DataSource = ds;
            grddegreemaster.DataBind();
        }
        else
        {
            grddegreemaster.DataSource = null;
            grddegreemaster.DataBind();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ViewState["Degree_ID"] != null)
        {
            string str = "update DegreeMaster set Degree_name='" + txtdegreename.Text + "',Degree_Description='" + txtdegreedescr.Text + "' where Degree_ID=" + ViewState["Degree_ID"];
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Updated";
        }
        else
        {
            string str = "Insert into DegreeMaster(Degree_name,Degree_Description) values ('" + txtdegreename.Text + "','" + txtdegreedescr.Text + "')";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            btncancel_Click(sender, e);
            lblmsg.Text = "Record Inserted";
        }
        Bindgrid();
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtdegreename.Text = "";
        txtdegreedescr.Text = "";
        lblmsg.Text = "";
        ViewState.Clear();
    }
    protected void lbkedit_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "select * from DegreeMaster where Degree_ID=" + lbk.CommandArgument.ToString();
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            ViewState["Degree_ID"] = lbk.CommandArgument.ToString();
            txtdegreename.Text = ds.Tables[0].Rows[0]["Degree_name"].ToString();
            txtdegreedescr.Text = ds.Tables[0].Rows[0]["Degree_Description"].ToString();
            
        }
    }
    protected void lbkdelete_Click(object sender, EventArgs e)
    {
        LinkButton lbk = (LinkButton)sender;
        string str = "Delete from DegreeMaster where Degree_ID=" + lbk.CommandArgument.ToString();
        cmd = new SqlCommand(str, con);
        cmd.ExecuteNonQuery();
        btncancel_Click(sender, e);
        lblmsg.Text = "Record Deleted";
        Bindgrid();
    }
}
