﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class User_Profile_HomePage : System.Web.UI.Page
{
    
    SqlDataAdapter da;
    SqlConnection con;
    SqlCommand cmd;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        da = new SqlDataAdapter("SELECT ProfileMaster.First_name,Visitor_Master.Visit_date,ProfileMaster.User_ID FROM Visitor_Master FULL OUTER JOIN  ProfileMaster ON Visitor_Master.vistor_UserId = ProfileMaster.User_ID where Visitor_Master.User_id='" + Session["USER_ID"] + "' Order By Visit_date desc", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 10)
        {
            dlresent.DataSource = ds;
            dlresent.DataBind();
        }
        else
        {
            dlresent.DataSource = null;
            dlresent.DataBind();
         }
        if (Session["visitor"] == "")
        {
            Label37.Visible = true;
            dlresent.Visible = true;
            LinkButton1.Enabled = true;
            lbedit.Enabled = true;
        }
        else
        {

            Label37.Visible = false ;
            dlresent.Visible = false;
            LinkButton1.Enabled = false;
            lbedit.Enabled = false;
        }

            if (!IsPostBack)
            {
                bindgeneralinfo();
                BindsocialProfile();
                bindprofessional();
                bindpersonal();
                grvgeneral.Visible = true;
                dgvpersonalinfo.Visible = false;
                dgvprofessionalinfo.Visible = false;
                dgvsocialprofile.Visible = false;
                Session["edit"] = "General";

            }
        
        
        }
    void bindpersonal()
    {
        if (Session["visitor"] == "")
        {
            da = new SqlDataAdapter("Select * from personalDetails where User_ID='" + Session["USER_ID"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dgvpersonalinfo.DataSource = ds;
                dgvpersonalinfo.DataBind();
            }
            else
            {
                dgvpersonalinfo.DataSource = null;
                dgvpersonalinfo.DataBind();


            }
        }
        else
        {
            da = new SqlDataAdapter("Select * from personalDetails where User_ID='" + Session["visitor"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dgvpersonalinfo.DataSource = ds;
                dgvpersonalinfo.DataBind();
            }
            else
            {
                dgvpersonalinfo.DataSource = null;
                dgvpersonalinfo.DataBind();
            }
        }
    }
    void bindgeneralinfo()
    {
        if (Session["visitor"] == "")
        {
            da = new SqlDataAdapter("SELECT     ProfileMaster.*, StateMaster.State_name, CityMaster.City_name, CountryMaster.Country_name FROM  CountryMaster FULL OUTER JOIN ProfileMaster ON CountryMaster.Country_ID = ProfileMaster.Country_ID FULL OUTER JOIN CityMaster ON ProfileMaster.City_ID = CityMaster.City_ID FULL OUTER JOIN StateMaster ON ProfileMaster.State_ID = StateMaster.State_ID where User_ID= '" + Session["USER_ID"] + "'", con);
            // da = new SqlDataAdapter("where User_ID='" + Session["USER_ID"] + "'", con);

            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                grvgeneral.DataSource = ds;
                grvgeneral.DataBind();
            }
            else
            {
                grvgeneral.DataSource = null;
                grvgeneral.DataBind();


            }

        }
        else
        {
            da = new SqlDataAdapter("SELECT ProfileMaster.*, StateMaster.State_name, CityMaster.City_name, CountryMaster.Country_name FROM  CountryMaster FULL OUTER JOIN ProfileMaster ON CountryMaster.Country_ID = ProfileMaster.Country_ID FULL OUTER JOIN CityMaster ON ProfileMaster.City_ID = CityMaster.City_ID FULL OUTER JOIN StateMaster ON ProfileMaster.State_ID = StateMaster.State_ID where User_ID= '" + Session["visitor"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                grvgeneral.DataSource = ds;
                grvgeneral.DataBind();
            }
            else
            {
                grvgeneral.DataSource = null;
                grvgeneral.DataBind();
            }

        }
    }
    void bindprofessional()
    {
        if (Session["visitor"] == "")
        {
            da = new SqlDataAdapter("Select * from professionalProfile where User_ID='" + Session["USER_ID"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dgvprofessionalinfo.DataSource = ds;
                dgvprofessionalinfo.DataBind();
            }
            else
            {
                dgvprofessionalinfo.DataSource = null;
                dgvprofessionalinfo.DataBind();

            }
        }
        else
        {
            da = new SqlDataAdapter("Select * from professionalProfile where User_ID='" + Session["visitor"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dgvprofessionalinfo.DataSource = ds;
                dgvprofessionalinfo.DataBind();
            }
            else
            {
                dgvprofessionalinfo.DataSource = null;
                dgvprofessionalinfo.DataBind();

            }
        }
    }
    void BindsocialProfile()
    {
        if (Session["visitor"] == "")
        {
            da = new SqlDataAdapter("Select * from SocialProfileMaster where User_ID='" + Session["USER_ID"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dgvsocialprofile.DataSource = ds;
                dgvsocialprofile.DataBind();
            }
            else
            {
                dgvsocialprofile.DataSource = null;
                dgvsocialprofile.DataBind();


            }
        }
        else
        {
            da = new SqlDataAdapter("Select * from SocialProfileMaster where User_ID='" + Session["visitor"] + "'", con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dgvsocialprofile.DataSource = ds;
                dgvsocialprofile.DataBind();
            }
            else
            {
                dgvsocialprofile.DataSource = null;
                dgvsocialprofile.DataBind();
            }
        
        }
    }
    protected void lbedit_Click(object sender, EventArgs e)
    {
        if (Session["edit"] == "General")
        {
            Response.Redirect("ProfileMaster_Form.aspx");
        
        }
        else if(Session["edit"] == "Social")
        {
            Response.Redirect("Social_Profile.aspx");
        }
        else if(Session["edit"] == "Professional")
        {
            Response.Redirect("ProfessionallyPersonal_Profile.aspx");
        }
        else if(Session["edit"] == "Personal")
        {
            Response.Redirect("ProfessionallyPersonal_Profile.aspx");
        }
        
    }
    protected void btnprofileMaster_Click(object sender, EventArgs e)
    {
        bindgeneralinfo();
       
        Session["edit"] = "General";
        grvgeneral.Visible = true;
        dgvpersonalinfo.Visible = false;
        dgvprofessionalinfo.Visible = false;
        dgvsocialprofile.Visible = false;
        btnprofessional.CssClass = "BtnNormal";
        btnprofileMaster.CssClass="BtnSelect";
        btnsocial.CssClass = "BtnNormal";
        btnpersonal.CssClass = "BtnNormal";


  }
    protected void btnsocial_Click(object sender, EventArgs e)
    {
        BindsocialProfile();
         
        Session["edit"] = "Social";
        grvgeneral.Visible = false;
        dgvpersonalinfo.Visible = false;
        dgvprofessionalinfo.Visible = false;
        dgvsocialprofile.Visible = true;
        btnprofessional.CssClass = "BtnNormal";
        btnprofileMaster.CssClass = "BtnNormal";
        btnsocial.CssClass = "BtnSelect";
        btnpersonal.CssClass = "BtnNormal";
    }
    protected void btnprofessional_Click(object sender, EventArgs e)
    {
        bindprofessional();
          
        Session["edit"] = "Professional";
         btnprofessional.CssClass = "BtnSelect";
        btnprofileMaster.CssClass = "BtnNormal";
        btnsocial.CssClass = "BtnNormal";
        btnpersonal.CssClass = "BtnNormal";
        grvgeneral.Visible = false;
        dgvpersonalinfo.Visible = false;
        dgvprofessionalinfo.Visible = true;
        dgvsocialprofile.Visible = false;
  

    }
    protected void btnpersonal_Click(object sender, EventArgs e)
    {
        bindpersonal();
            
        Session["edit"] = "Personal";
        btnprofessional.CssClass = "BtnNormal";
        btnprofileMaster.CssClass = "BtnNormal";
        btnsocial.CssClass = "BtnNormal";
        btnpersonal.CssClass ="BtnSelect";
        grvgeneral.Visible = false;
        dgvpersonalinfo.Visible = true;
        dgvprofessionalinfo.Visible = false;
        dgvsocialprofile.Visible = false;
        }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        lbedit.Visible = true;
    }
    protected void grvgeneral_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void lbresent_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        Session["visitor"] = lb.CommandArgument.ToString();
         bindgeneralinfo();
                BindsocialProfile();
                bindprofessional();
                bindpersonal();
                Label37.Visible = false;
                dlresent.Visible = false;
                
                DateTime dt = Convert.ToDateTime(System.DateTime.Now.ToString());
                da = new SqlDataAdapter("Select * from Visitor_Master where vistor_UserId='" + Session["USER_ID"] + "' and User_id='" + lb.CommandArgument.ToString() + "'", con);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    cmd = new SqlCommand("Update Visitor_Master Set Visit_date='" + dt + "' where vistor_UserId='" + Session["USER_ID"] + "' and User_id='" + lb.CommandArgument.ToString() + "' ", con);
                    cmd.ExecuteNonQuery();
                    Session["visitor"] = lb.CommandArgument.ToString(); 
                        
                    Response.Redirect("Profile_HomePage.aspx");

                }
                else
                {
                    cmd = new SqlCommand("Insert into Visitor_Master(User_id,vistor_UserId,Visit_date) values('" + lb.CommandArgument.ToString() + "','" + Session["USER_ID"] + "','" + dt + "')", con);
                    cmd.ExecuteNonQuery();
                    Session["visitor"] = lb.CommandArgument.ToString();
                    Response.Redirect("Profile_HomePage.aspx");
                }
    }
}
