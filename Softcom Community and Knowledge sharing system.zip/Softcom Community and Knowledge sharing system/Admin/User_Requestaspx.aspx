﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="User_Requestaspx.aspx.cs" Inherits="Admin_User_Requestaspx" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
            height: 88px;
        }
        .style5
        {
            font-size: x-large;
            text-align: right;
        }
        .style6
        {
            width: 184px;
            font-size: small;
           font-family: Verdana;
           text-align: left;
       }
        .style7
        {
            width: 136px;
            font-size: small;
                font-family: Verdana;
       }
        .style8
        {
            width: 100%;
        }
        .style9
        {
            width: 132px;
            text-align: right;
           font-size: small;
           font-family: Verdana;
       }
        .style10
        {
            width: 132px;
            text-align: right;
            height: 24px;
           font-size: small;
           font-family: Verdana;
       }
        .style11
        {
            height: 24px;
           font-size: small;
           font-family: Verdana;
       }
        .style12
        {
            text-align: center;
        }
        .style14
       {
           font-family: Verdana;
           font-size: small;
       }
    </style>
    </asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">

    <asp:GridView ID="grdadminuserrequest" runat="server" 
        AutoGenerateColumns="False" CellPadding="4" ForeColor="#333333" 
        GridLines="None">
        <RowStyle BackColor="#E3EAEB" />
        <Columns>
            <asp:TemplateField>
                <ItemTemplate>
                    <table class="style1">
                        <tr>
                            <td class="style7">
                                EmailId :-</td>
                            <td class="style6">
                                <asp:Label ID="lblemail_Id" runat="server" Text='<%# Eval("Email_ID") %>' 
                                    style="font-size: small; font-family: Verdana"></asp:Label>
                            </td>
                            <td class="style5" rowspan="2">
                                <asp:Button ID="btnmoreinfo" runat="server" 
                                    CommandArgument='<%# Eval("User_ID") %>' Height="24px" 
                                    onclick="btnmoreinfo_Click1" Text="More Information" Width="156px" 
                                    BackColor="#996633" />
                            </td>
                        </tr>
                        <tr>
                            <td class="style7">
                                Employer Id:-</td>
                            <td class="style6">
                                <asp:Label ID="lblempid" runat="server" Text='<%# Eval("Emp_ID") %>'></asp:Label>
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#7C6F57" />
        <AlternatingRowStyle BackColor="White" />
    </asp:GridView>
    <asp:DetailsView ID="dvmoreinfo" runat="server" AutoGenerateRows="False" 
        Height="50px" Width="393px" style="font-size: large" 
        onpageindexchanging="dvmoreinfo_PageIndexChanging" 
    BackColor="LightGoldenrodYellow" BorderColor="Tan" BorderWidth="1px" 
    CellPadding="2" ForeColor="Black" GridLines="None">
        <FooterStyle BackColor="Tan" />
        <PagerStyle BackColor="PaleGoldenrod" ForeColor="DarkSlateBlue" 
            HorizontalAlign="Center" />
        <Fields>
            <asp:TemplateField>
                <ItemTemplate>
                    <table class="style8">
                        <tr>
                            <td class="style10">
                                User Id:-</td>
                            <td class="style11">
                                <asp:Label ID="lbuseId" runat="server" Text='<%# Eval("User_ID") %>'></asp:Label>
                            </td>
                            <td class="style11">
                                &nbsp;</td>
                        </tr>
                        <tr>
                            <td class="style9">
                                First Name:-</td>
                            <td class="style14">
                                <asp:Label ID="lbfirstname" runat="server" Text='<%# Eval("First_name") %>'></asp:Label>
                            </td>
                            <td>
                                &nbsp;</td>
                        </tr>
                        <tr>
                            <td class="style9">
                                Middle Name :-</td>
                            <td class="style14">
                                <asp:Label ID="lbMiddlename" runat="server" Text='<%# Eval("Midle_name") %>'></asp:Label>
                            </td>
                            <td>
                                &nbsp;</td>
                        </tr>
                        <tr>
                            <td class="style9">
                                Last Name :-</td>
                            <td class="style14">
                                <asp:Label ID="lblastname" runat="server" Text='<%# Eval("Last_name") %>'></asp:Label>
                            </td>
                            <td>
                                &nbsp;</td>
                        </tr>
                        <tr>
                            <td class="style9">
                                Employer Id:-</td>
                            <td class="style14">
                                <asp:Label ID="lbemployer" runat="server" Text='<%# Eval("Emp_ID") %>'></asp:Label>
                            </td>
                            <td>
                                &nbsp;</td>
                        </tr>
                        <tr>
                            <td class="style9">
                                Email Id:-</td>
                            <td class="style14">
                                <asp:Label ID="lbemail_Id" runat="server" Text='<%# Eval("Email_ID") %>'></asp:Label>
                            </td>
                            <td>
                                &nbsp;</td>
                        </tr>
                        <tr>
                            <td class="style9">
                                User Type:-</td>
                            <td class="style14">
                                <asp:Label ID="lbusertype" runat="server" Text='<%# Eval("User_Type") %>'></asp:Label>
                            </td>
                            <td>
                                &nbsp;</td>
                        </tr>
                        <tr>
                            <td class="style12" colspan="3">
                                <asp:Button ID="btnApprove" runat="server" Text="Approved" 
                                    CommandArgument='<%# Eval("User_ID") %>' onclick="btnapproved_Click" 
                                    BackColor="#996633" />
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <asp:Button ID="btnnotapproved" runat="server" Height="22px" Text="Not Approved" 
                                    Width="102px" CommandArgument='<%# Eval("User_ID") %>' 
                                    onclick="btnnotapproved_Click" BackColor="#996633" />
                            </td>
                        </tr>
                    </table>
                </ItemTemplate>
            </asp:TemplateField>
        </Fields>
        <HeaderStyle BackColor="Tan" Font-Bold="True" />
        <EditRowStyle BackColor="DarkSlateBlue" ForeColor="GhostWhite" />
        <AlternatingRowStyle BackColor="PaleGoldenrod" />
    </asp:DetailsView>
</asp:Content>

