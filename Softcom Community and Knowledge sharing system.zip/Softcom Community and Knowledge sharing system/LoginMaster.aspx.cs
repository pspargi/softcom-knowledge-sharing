﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class LoginMaster : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;   
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["sckss"].ConnectionString);
        con.Open();
        if (!IsPostBack)
        {
            rblusertype.Focus();
        }
    }
    protected void btnsignin_Click(object sender, EventArgs e)
    {
        string str = "select * from LoginMaster where Email_ID='" + txtemailid.Text + "' and Password='" + txtpassword.Text + "' and User_Type='" + rblusertype.Text + "'";
        da = new SqlDataAdapter(str, con);
        ds = new DataSet();
        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            String flag = ds.Tables[0].Rows[0]["Active_Flag"].ToString();
            String dflag = ds.Tables[0].Rows[0]["Delete_Flag"].ToString();

            if (dflag == "True")
            {
                if (flag == "False")
                {
                    Session["USER_ID"] = ds.Tables[0].Rows[0]["User_ID"];
                    Session["visitor"] = "";
                    string str1 = "update  LoginMaster Set Active_Flag= 'True' where User_ID=" + Session["USER_ID"];
                    cmd = new SqlCommand(str1, con);
                    cmd.ExecuteNonQuery();
                    if (ds.Tables[0].Rows[0]["User_Type"].ToString() == "Admin")
                    {
                        Response.Redirect("~/Admin/Fetch_All_the_User.aspx");
                    }
                    else if (ds.Tables[0].Rows[0]["User_Type"].ToString() == "User")
                    {
                        Response.Redirect("~/User/Profile_HomePage.aspx");
                    }
                    else
                    {
                    }
                }
                else
                {
                    lblmsg.Text = "Your account is already in use";
                }
            }
            else
            {
                lblmsg.Text = "Your ID is Blocked by administrator";
            }

        }
        else
        {
            lblmsg.Text = "Incorrect Username or Password";
        }
        txtemailid.Text = "";
        txtpassword.Text = "";
        rblusertype.Focus();

    }
    protected void lnkforgottpassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Forgott_Password.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/RegistrationForm.aspx");
    }
}
