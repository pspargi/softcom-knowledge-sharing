﻿<%@ Page Language="C#" MasterPageFile="~/Admin/MasterPage.master" AutoEventWireup="true" CodeFile="Fetch_All_the_User.aspx.cs" Inherits="Admin_Fetch_All_the_User" %>


<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 54%;
        }
        .style2
        {
            text-align: center;
        }
        .style4
        {
            text-align: center;
            width: 65px;
        }
    </style>
    </asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td class="style2" colspan="2">
                </td>
        </tr>
        <tr>
            <td class="style4">
                User ID:-</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtuserid" runat="server" Enabled="False" Width="151px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style4">
                First Name</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtfnane" runat="server" Width="150px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style4">
                Midle Name</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtmname" runat="server" Width="150px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style4">
                Last Name</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtlname" runat="server" Width="149px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style4">
                :User_Type:-</td>
            <td style="text-align: justify">
                <asp:DropDownList ID="ddlusertype" runat="server" Height="16px" Width="86px">
                    <asp:ListItem></asp:ListItem>
                    <asp:ListItem>User</asp:ListItem>
                    <asp:ListItem>Admin</asp:ListItem>
                </asp:DropDownList>
            </td>
        </tr>
        <tr>
            <td class="style4">
                Email ID:-</td>
            <td style="text-align: justify">
                <asp:TextBox ID="txtemail_id" runat="server" Width="149px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style4">
                &nbsp;Emp_ID:-</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtempid" runat="server" Width="147px" 
                    style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style4">
                Password:-</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtpassword" runat="server" Width="146px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style2" colspan="2">
                <asp:Button ID="btnupdate" runat="server" onclick="btnUpdate" Width="58px" />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btncancel" runat="server" onclick="btncanel_Click" Text="Cancel" 
                    Width="66px" />
                &nbsp;</td>
        </tr>
        <tr>
            <td class="style2" colspan="2">
    <asp:GridView ID="dgvfetchuser" runat="server" Width="16px" CellPadding="4" 
                    ForeColor="#333333" GridLines="None">
        <RowStyle BackColor="#E3EAEB" />
        <Columns>
            <asp:TemplateField HeaderText="Edit">
                <ItemTemplate>
                    <asp:LinkButton ID="lbedit" runat="server" 
                        CommandArgument='<%# Eval("User_ID") %>' onclick="lbedit_Click">Edit</asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
            <asp:TemplateField HeaderText="Delete">
                <ItemTemplate>
                    <asp:LinkButton ID="lbDelete" runat="server" 
                        CommandArgument='<%# Eval("User_ID") %>' onclick="lbDelete_Click" Text="Delete"></asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
        <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
        <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
        <EditRowStyle BackColor="#7C6F57" />
        <AlternatingRowStyle BackColor="White" />
    </asp:GridView>
            </td>
        </tr>
    </table>
    </asp:Content>
