﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Admin_Fetch_All_the_User : System.Web.UI.Page
{
    SqlCommand cmd;
    SqlDataAdapter da;
    SqlConnection con;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["sckss"].ConnectionString.ToString());
        con.Open();
        if (!IsPostBack)
        {
          
            Bindgrid();        
        }
    }
    void Bindgrid()
    {
        da = new SqlDataAdapter("SELECT LoginMaster.User_ID, LoginMaster.User_Type, LoginMaster.Email_ID FROM LoginMaster INNER JOIN ProfileMaster ON LoginMaster.User_ID = ProfileMaster.User_ID", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dgvfetchuser.DataSource = ds;
            dgvfetchuser.DataBind();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
     

    }
    protected void lbedit_Click(object sender, EventArgs e)
    {
        btnupdate.Text = "Update";
        LinkButton lb = (LinkButton)sender;
        da = new SqlDataAdapter("SELECT LoginMaster.User_ID, LoginMaster.User_Type, LoginMaster.Emp_ID, LoginMaster.Email_ID, LoginMaster.Password,ProfileMaster.First_name,ProfileMaster.Midle_name,ProfileMaster.Last_name FROM LoginMaster INNER JOIN ProfileMaster ON LoginMaster.User_ID = ProfileMaster.User_ID where LoginMaster.User_ID='" + lb.CommandArgument.ToString() + "'", con);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            
            txtuserid.Text = lb.CommandArgument.ToString();
            txtfnane.Text = ds.Tables[0].Rows[0]["First_name"].ToString();
            txtmname.Text = ds.Tables[0].Rows[0]["Midle_name"].ToString();
            txtlname.Text = ds.Tables[0].Rows[0]["Last_name"].ToString();
           ddlusertype.SelectedItem.Text = ds.Tables[0].Rows[0]["User_Type"].ToString();
             txtempid.Text = ds.Tables[0].Rows[0]["Emp_ID"].ToString();
             txtemail_id.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
             txtpassword.Text= ds.Tables[0].Rows[0]["Password"].ToString();
             //ddlusertype.ClearSelection(); 
        }
    }
    protected void btnUpdate(object sender, EventArgs e)
    {
        if (btnupdate.Text == "Update")
        {
            cmd = new SqlCommand("Update LoginMaster Set User_Type='" + ddlusertype.Text + "',Emp_ID='" + txtempid.Text + "',Email_ID='" + txtemail_id.Text + "',Password='" + txtpassword.Text + "' where User_ID='" + txtuserid.Text + "'", con);
            cmd.ExecuteNonQuery();
            cmd = new SqlCommand("Update ProfileMaster Set First_name='" + txtfnane.Text + "',Midle_name='" + txtmname.Text + "',Last_name='" + txtlname.Text + "' where User_ID='" + txtuserid.Text + "'", con);
            cmd.ExecuteNonQuery();
            Bindgrid();
        }
        if (btnupdate.Text == "Delete")
        {
            cmd = new SqlCommand("Delete from LoginMaster where User_ID='" +txtuserid.Text+ "'", con);
            cmd.ExecuteNonQuery();
            cmd = new SqlCommand("Delete from ProfileMaster where User_ID='"+txtuserid.Text+"'", con);
            cmd.ExecuteNonQuery();
            Bindgrid();
        }
    }
    protected void btncanel_Click(object sender, EventArgs e)
    {
            txtuserid.Text ="";
            txtfnane.Text="";
            txtlname.Text = "";
            txtmname.Text = "";
            txtemail_id.Text = "";
            txtempid.Text = "";
            txtpassword.Text = "";
    }
    protected void lbDelete_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        lbedit_Click(sender, e);
        btnupdate.Text = "Delete";
        }
}
