﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="ImagecagetoryMaster.aspx.cs" Inherits="User_ImagecagetoryMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2" style="text-align: center">
                <h2>
                    Image Category Master</h2>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Image Category Name:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtImagecatname" runat="server" style="text-align: left"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">
                Image Category Description:</td>
            <td style="text-align: left">
                <asp:TextBox ID="txtImagecatdescr" runat="server"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:Button ID="btnSave" runat="server" onclick="btnsave_Click" Text="Save" 
                    BackColor="#695F4C" />
                <asp:Button ID="btncancel" runat="server" Text="Cancel" 
                    onclick="btnCancel_Click" BackColor="#695F4C" />
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdImageCategory" runat="server" AutoGenerateColumns="False" 
                    CellPadding="4" ForeColor="#333333" GridLines="None">
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkedit" runat="server" 
                                    CommandArgument='<%# Eval("Image_Cat_ID") %>' onclick="lbkedit_Click">Edit</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Delete">
                            <ItemTemplate>
                                <asp:LinkButton ID="lbkdelete" runat="server" 
                                    CommandArgument='<%# Eval("Image_Cat_ID") %>' onclick="lbkdelete_Click">Delete</asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Image_Cat_name" HeaderText="Image Category Name" />
                        <asp:BoundField DataField="Image_Cat_Description" 
                            HeaderText="Image Category Description" />
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
    </table>
</asp:Content>

