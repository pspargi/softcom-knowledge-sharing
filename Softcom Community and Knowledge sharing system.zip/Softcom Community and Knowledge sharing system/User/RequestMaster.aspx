﻿<%@ Page Language="C#" MasterPageFile="~/User/MasterPage.master" AutoEventWireup="true" CodeFile="RequestMaster.aspx.cs" Inherits="User_RequestMaster" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            width: 100%;
        }
        .style3
        {
            width: 459px;
            height: 92px;
        }
        .style12
        {
            text-align: left;
            width: 41px;
        }
        .style20
        {
            text-align: left;
            }
        .style9
        {
            text-align: left;
        }
        .style14
        {
            width: 287px;
            text-align: left;
        }
        .style15
        {
            height: 25px;
        }
        .style16
        {
            width: 38px;
            height: 25px;
            text-align: left;
        }
        .style19
        {
            height: 25px;
            width: 52px;
        }
        .style17
        {
            text-align: left;
            height: 25px;
            width: 41px;
        }
        .style18
        {
            height: 25px;
            width: 287px;
            text-align: left;
        }
        </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
        <tr>
            <td colspan="2">
                <h2 style="text-align: center">
                    Request Master</h2>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <asp:GridView ID="grdRequestMaster" runat="server" AutoGenerateColumns="False" 
                    style="margin-right: 0px" CellPadding="4" ForeColor="#333333" 
                    GridLines="None" >
                    <RowStyle BackColor="#E3EAEB" />
                    <Columns>
                        <asp:TemplateField>
                            <ItemTemplate>
                                <table class="style3">
                                    <tr>
                                        <td class="style7" colspan="4" rowspan="3">
                                            <asp:Image ID="Image1" runat="server" Height="100px" 
                                                ImageUrl='<%# Eval("Photo_file") %>' Width="100px" />
                                        </td>
                                        <td class="style12">
                                            Name:</td>
                                        <td class="style20">
                                            <asp:Label ID="lblfrstname" runat="server" style="text-align: left" 
                                                Text='<%# Eval("First_name") %>'></asp:Label>
                                            &nbsp;&nbsp;<asp:Label ID="lblmidlename" runat="server" style="text-align: left" 
                                                Text='<%# Eval("Midle_name") %>'></asp:Label>
                                            <asp:Label ID="lbllastname" runat="server" style="text-align: left" 
                                                Text='<%# Eval("Last_name") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style12">
                                            Address:</td>
                                        <td class="style9" style="text-align: left">
                                            <asp:Label ID="lbladdressline1" runat="server" style="text-align: left" 
                                                Text='<%# Eval("Address_line1") %>'></asp:Label>
                                            &nbsp;&nbsp;&nbsp;
                                            <asp:Label ID="lbladdressline2" runat="server" style="text-align: left" 
                                                Text='<%# Eval("Address_line2") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style12">
                                            Contact:</td>
                                        <td class="style14">
                                            <asp:Label ID="lblcontact" runat="server" style="text-align: left" 
                                                Text='<%# Eval("Phone_no") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style15">
                                            City</td>
                                        <td class="style15">
                                            <asp:Label ID="lblcity" runat="server" Text='<%# Eval("City_name") %>'></asp:Label>
                                        </td>
                                        <td class="style16">
                                            State</td>
                                        <td class="style19">
                                            <asp:Label ID="lblstate" runat="server" Text='<%# Eval("State_name") %>'></asp:Label>
                                            &nbsp;</td>
                                        <td class="style17">
                                            Country</td>
                                        <td class="style18">
                                            <asp:Label ID="lblcountry" runat="server" Text='<%# Eval("Country_name") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style7" colspan="4">
                                            &nbsp;</td>
                                        <td class="style12">
                                            Email Id</td>
                                        <td class="style9">
                                            <asp:Label ID="lblemailid" runat="server" Text='<%# Eval("Email_Id") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style7" colspan="5">
                                            <asp:Button ID="btnAccept" runat="server"
                                                Text="Accept" CommandArgument='<%# Eval("User_ID1") %>' 
                                                onclick="btnAccept_Click" BackColor="#999966" />
                                        </td>
                                        <td class="style9">
                                            <asp:Button ID="btnreject" runat="server"
                                                Text="Reject" CommandArgument='<%# Eval("User_ID1") %>' 
                                                onclick="btnreject_Click" BackColor="#999966" />
                                            <asp:Button ID="btnviewinfo" runat="server" Text='<%# Eval("User_ID1") %>' 
                                                BackColor="#999966" Visible="False" />
                                        </td>
                                    </tr>
                                </table>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#666666" ForeColor="White" HorizontalAlign="Center" />
                    <SelectedRowStyle BackColor="#C5BBAF" Font-Bold="True" ForeColor="#333333" />
                    <HeaderStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <EditRowStyle BackColor="#7C6F57" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
            </td>
        </tr>
        <tr>
            <td>
                &nbsp;</td>
            <td>
                &nbsp;</td>
        </tr>
    </table>
</asp:Content>

